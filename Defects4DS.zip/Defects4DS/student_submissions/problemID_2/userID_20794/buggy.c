#include<stdio.h>
#include<stdlib.h>

char a[1000];
int b[1000];
int main()
{
    int i=0, j=0, k=0, zan=0;
    gets(a);

    for(i=0; a[i]!='\0'; i++)
    {
        if(a[i]!=' ')
            a[j++] = a[i];
    }
    a[j] = '\0';

    for(i=0, j=0, k=0; a[i]!='\0'; i++)
    {
        if(!isdigit(a[i]))
        {
            b[j++] = atoi(a+k);
            b[j++] = a[i];
            k = 1 + i;
        }
    }
    b[j] = '\0';

    for(i=0; i<j; i++)
    {
        int shi=b[i];
        while(b[i+1]=='*' || b[i+1]=='/')
        {
            if(b[i+1]=='*')
                shi *= b[i+2];
            if(b[i+1]=='/')
                shi /= b[i+2];
            b[i] = 0;
            if(i!=0&&b[i-1]=='+')
                b[i+1] = '+';
            else if(i!=0&&b[i-1]=='-')
                b[i+1] = '-';
            b[i+2] = shi;
            i += 2;
        }
    }

    zan=b[0];
    for(i=0; i<j; i++)
    {
        if(b[i+1]=='+')
            zan += b[i+2];
        if(b[i+1]=='-')
            zan -= b[i+2];
        i++;
    }

    printf("%d", zan);

    return 0;
}

