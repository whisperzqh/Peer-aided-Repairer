#include <stdio.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
int main()
{char d[200],fuhao[200],ass[100];
int shuzi[200],a[100]={0},b[100],c[100];//
int changdu1,changdu2,changdu3,i1,i,j=0,k=0;
gets(d);
changdu1=strlen(d);
	for(i=0;i<changdu1&&d[i]!='=';i++)
		{	
			if (isdigit(d[i])&&isdigit(d[i+1]))
				{a[j]*=10;
				a[j]+=(d[i]-'0')*10;
				}
			if(isdigit(d[i])&&!(isdigit(d[i+1])))
				{a[j]+=d[i]-'0';
				j++;
				}
			if(d[i]=='+'||d[i]=='-'||d[i]=='*'||d[i]=='/')
				{fuhao[k]=d[i];k++; 
				}
		}

		for(i=0;i<k;i++)
		{if (fuhao[i]=='*' || fuhao[i]=='/' )
			{if (fuhao[i]=='*')
					{a[i]*=a[i+1];
			a[i+1]=a[i];
			}
			else
			{
			a[i]/=a[i+1];
			a[i+1]=a[i]; }
			for(j=i;j>=0;j--)
				{if (fuhao[j]=='+'||fuhao[j]=='-')
				break;
				else
				a[j]=a[i];
				}
			}
			
		}
		for(i=0;i<k;i++)
		{if (fuhao[i]=='+' || fuhao[i]=='-' )
			{for(j=i+1;j<k;j++)
				{if (fuhao[j]=='-'||fuhao[j]=='+')
					a[i+1]=a[j];}
			if (fuhao[i]=='+')
			a[0]+=a[i+1];
			else
			a[0]-=a[i+1];
			}
		}
		printf("%d",a[0]);
return 0;
}



