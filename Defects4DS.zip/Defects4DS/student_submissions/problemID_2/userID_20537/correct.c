#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	char s[1000],fuhao[1000],b[1000];
	int shuzi[1000]={0},a[1000]={0},i,j=0,k=0,i1=0,ans=0;
	gets(s);
	for(i=0;s[i]!='=';i++)
	{
		if((s[i]-'0'>=0)&&(s[i]-'0'<=9)&&((s[i-1]-'0'<0)||(s[i-1]-'0'>9)||(i==0)))
		{
			if((s[i+1]-'0'<0)||(s[i+1]-'0'>9))
			{
			shuzi[j]=s[i]-'0';
			j++;
			}
			if((s[i+1]-'0'>=0)&&(s[i+1]-'0'<=9))
			{
				if((s[i+2]-'0'>=0)&&(s[i+2]-'0'<=9))
				{
					if((s[i+3]-'0'<0)||(s[i+3]-'0'>9))
					{
					shuzi[j]=100*(s[i]-'0')+10*(s[i+1]-'0')+s[i+2]-'0';
					j++;
					}
					if((s[i+3]-'0'>=0)&&(s[i+3]-'0'<=9))
					{
					if((s[i+4]-'0'<0)||(s[i+4]-'0'>9))	
					{
					shuzi[j]=1000*(s[i]-'0')+100*(s[i+1]-'0')+10*(s[i+2]-'0')+s[i+3]-'0';
					j++;
					}
					if((s[i+4]-'0'>=0)&&(s[i+4]-'0'<=9))
					{
					shuzi[j]=10000*(s[i]-'0')+1000*(s[i+1]-'0')+100*(s[i+2]-'0')+10*(s[i+3]-'0')+s[i+4]-'0';
					j++;
					}
					}	
				}
				if((s[i+2]-'0'<0)||(s[i+2]-'0'>9))
				{
					shuzi[j]=10*(s[i]-'0')+s[i+1]-'0';
					j++;
				 } 
			}	
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/') 
		{
			fuhao[k]=s[i];
			k++;
		}
		fuhao[k]='\0';
	}
//

		for(i=0;i<=k;i++)
	{
		a[i1]=shuzi[i];
		while(fuhao[i]=='*'||fuhao[i]=='/') 
		{
			if(fuhao[i]=='*')
			a[i1]=a[i1]*shuzi[i+1];
			else
			a[i1]=a[i1]/shuzi[i+1];
			i++;
		}

		if(fuhao[i]=='+'||fuhao[i]=='-')
		{
			b[i1]=fuhao[i];
			i1++;
		}
	 } 

	 ans=a[0];
	 for(i=0;i<i1;i++)
	 {
	 	if(b[i]=='+')
	 	{
	 		ans=ans+a[i+1];
		 }
		 else
		 ans=ans-a[i+1];
	 }
	printf("%d",ans);
	 return 0;
}

