#include<stdio.h>
#include<string.h>
int main()
{
	char s1[200],s2[200]={'\0'};
	int s[200]={0};
	gets(s1);
	int i=0,j=0,sum=0,k=0,f=0;
	for(i=0;i<strlen(s1);i++)
	{
		if(s1[i]!=' ')
		{
			s2[j]=s1[i];
			j++;
		}
	}
	sum=s2[0]-'0';
	for(i=0;s2[i+1]>='0'&&s2[i+1]<='9';i++)
	{
		sum=sum*10+s2[i+1]-'0';
	}//
	i++;
	while(s2[i]=='*'||s2[i]=='/')
			{
					if(s2[i]=='*')
					{
						i++;
						k=s2[i]-'0';
						while(s2[i+1]>='0'&&s2[i+1]<='9')
						{
							k=k*10+s2[i+1]-'0';
							i++;
						}
						sum=sum*k;
						k=0;	
					}
					if(s2[i]=='/')
					{
						i++;
						k=s2[i]-'0';
						while(s2[i+1]>='0'&&s2[i+1]<='9')
						{
							k=k*10+s2[i+1]-'0';
							i++;
						}
					sum=sum/k;
						k=0;	
					}
					i++;
			}

	for(;i<strlen(s2);j++)//
	{
		
			if(s2[i]=='+')f=0;
			else f=1;
			i++;
			if(s2[i]>='0'&&s2[i]<='9')
			{
				s[j]=s2[i]-'0';
				while(s2[i+1]>='0'&&s2[i+1]<='9')
				{
					s[j]=s[j]*10+s2[i+1]-'0';
					i++;
				}// 
			
				i++;//
			}
			while(s2[i]=='*'||s2[i]=='/')
			{
					if(s2[i]=='*')
					{
						i++;
						k=s2[i]-'0';
						while(s2[i+1]>='0'&&s2[i+1]<='9')
						{
							k=k*10+s2[i+1]-'0';
							i++;
						}
						s[j]=s[j]*k;
						k=0;	
					}
					if(s2[i]=='/')
					{
						i++;
						k=s2[i]-'0';
						while(s2[i+1]>='0'&&s2[i+1]<='9')
						{
							k=k*10+s2[i+1]-'0';
							i++;
						}
						s[j]=s[j]/k;
						k=0;	
					}
					i++;
			}
		if(f=0)sum+=s[j];
		else sum-=s[j];		 
		}
	
printf("%d",sum);
	return 0;	
}		
		
		
	


	


