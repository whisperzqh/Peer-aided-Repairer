#include<stdio.h>
#include<string.h>
int main()
{
	char a[100],f[100],c[100],f1[50];
	int b[100],d[100],i,n,j,k=0,flag2=0,l,m=0,flag3=0,p=0,ans;
	gets(a);
	n=strlen(a);
	for(i=0,j=0;i<n;i++)
	{
		if(a[i]!=' ')
		{
			c[j]=a[i];
			j++;
		}
	}
	n=j;
	i=0;
	b[0]=0;
	 if(c[0]=='-')
    {
        for(i=1;c[i]!='+'&&c[i]!='-'&&c[i]!='*'&&c[i]!='/'&&c[i]!='=';i++)
        {
            b[0]=b[0]*10-(c[i]-'0');
        }
        k++;
    }
    for(;i<j;i++)
    {
        if(c[i]>='0'&&c[i]<='9'&&flag2==0)
        {
            b[k]=c[i]-'0';
            flag2=1;
        }
        else if(c[i]=='+'||c[i]=='-'||c[i]=='*'||c[i]=='/'||c[i]=='=')
        {
            flag2=0;
            k++;
        }
        else if(c[i]>='0'&&c[i]<='9'&&flag2==1)
        {
            b[k]=b[k]*10+c[i]-'0';
        }
    }
    for(i=1,l=0;i<j;i++)
    {
    	if(c[i]=='+'||c[i]=='-'||c[i]=='*'||c[i]=='/'||c[i]=='=')
    	{
    		f[l]=c[i];
    		l++;
		}
	}
	for(i=0;i<l;i++)
	{
		if(f[i]=='*')
		{
			if(flag3==1)
			d[m]=d[m]*b[i+1];
			else
			d[m]=b[i]*b[i+1];
			flag3=1;
		}
		else if(f[i]=='/')
		{
			if(flag3==1)
			d[m]=d[m]/b[i+1];	
			else
			d[m]=b[i]/b[i+1];
			flag3=1;
		}
		else if(f[i]=='+'||f[i]=='-'||f[i]=='=')
		{
			if(flag3==0)
			{
				d[m]=b[i];
			}
			m++;
			f1[p]=f[i];
			p++;
			flag3=0;
		}
	}
	ans=d[0];
	for(i=0;i<m-1;i++)
	{
		if(f1[i]=='+')
		{
			ans+=d[i+1];
		}
		else if(f1[i]=='-')
		{
			ans-=d[i+1];
		}
	}
	printf("%d",ans);
	return 0;
}

