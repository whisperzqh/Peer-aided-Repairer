#include<stdio.h>
#include<string.h>
#include<ctype.h>
#define MAX_N 500
int main()
{
    int i=0,j=0,k=0,z=0,m=0;
    char ori[MAX_N],operators[MAX_N],newop[MAX_N];
    int b[MAX_N]={0},c[MAX_N]={0};
    gets(ori);
    int sign=0;
    for(i=0;ori[i]!='\0';i++)
    {
        
        if(isdigit(ori[i]))
        {
            b[j] = b[j]*10+ori[i]-'0';
            if(!isdigit(ori[i+1]))
                j++;
        }
        else if (ori[i] == '*' || ori[i] == '/' || ori[i] == '+' || ori[i] == '-')
        {
            operators[k++] = ori[i];
        }
    }
    for(i=0;i<k;i++)
    {
        if(operators[i]=='*')
        {
            b[i+1] = b[i]*b[i+1];
            if (operators[i + 1] != '*' && operators[i + 1] != '/')
                c[z++] = b[i + 1];
        }
        else if ( operators[i] == '/')
        {
            b[i+1] = b[i]/b[i+1];
            if (operators[i + 1] != '*' && operators[i + 1] != '/')
                c[z++] = b[i + 1];     
        }
        else if(operators[i] == '+' || operators[i]=='-')
        {
            newop[m++] = operators[i];
            if(operators[i-1]!='*'&& operators[i-1]!='/')
                c[z++] = b[i];
        }
    }
    int n=i;
    if(m!=0)
    {
        for(i=0;i<m;i++)
        {
            if(newop[i]=='+')
                c[i+1] = c[i]+c[i+1];
            else
                c[i+1] = c[i]-c[i+1];
        }
        if(operators[n-1]=='+')
            printf("%d",c[m]+b[n]);
        else if (operators[n-1] == '-')
            printf("%d", c[m] - b[n]);
        else
            printf("%d",c[m]);
    }
    else
    {
        if (operators[n-1] == '+')
            printf("%d", b[i] + b[n-1]);
        else if (operators[n-1] == '-')
            printf("%d", b[i] - b[n-1]);
        else
            printf("%d",b[i]);
    }

    return 0;
}
//
//
//

