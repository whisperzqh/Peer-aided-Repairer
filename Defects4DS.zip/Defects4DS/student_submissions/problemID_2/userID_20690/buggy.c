#include<stdio.h>
#include<string.h>
#include<ctype.h>
int cal(int,int,char);


int main()
{
	char read[500],sign[500];
	int num[500],num2[500];
	int i,j,k,count=0,temp=0;
	gets(read);
	for(i=j=k=0;read[i]!='\0';i++)
	{
		if(isdigit(read[i]))
		temp=temp*10+read[i]-'0';
		else
		{
			sign[k++]=read[i];
			if(temp!=0)
			{
				num[j++]=temp;
				temp=0;
			}
		}
		
	}
	count=j;
	sign[k]='\0';
	
	if(count==1)
	{
		printf("%d",num[0]);
		return 0;
	}
	
	for(i=j=0;sign[i]!='\0';i++)
	{
		if(sign[i]!=' ')
		sign[j++]=sign[i];
	}
	sign[j]='\0';
	
	for(i=j=0;sign[i]!='\0';)
	{
		temp=0;
		if(sign[i]=='*'||sign[i]=='/')
		{
			temp=cal(num[i],num[i+1],sign[i]);
			i++;
			count--;
			//printf("%d\n",temp);
			while(sign[i]=='*'||sign[i]=='/')
			{
				temp=cal(temp,num[i+1],sign[i]);
				i++;
				count--;
				//printf("%d\n",temp);
			}
			num2[j++]=temp;
			temp=0;
		}
		else if(i==0) num2[j++]=num[i++];
		else if(sign[i-1]!='*'&&sign[i-1]!='/')
		num2[j++]=num[i++];
		else
		i++;
		
	}
	num2[j+1]=num[i+1];
	
	for(i=j=0;sign[i]!='\0';i++)
	{
		if(sign[i]=='+'||sign[i]=='-')
		sign[j++]=sign[i];
	}
	sign[count-1]='\0';
	//puts(sign);
	for(i=0;sign[i]!='\0';i++)
	//printf("%d\n",num2[i+1]);
	//printf("\n\n\n");
	
	if(count==1)
	{
		printf("%d",num[0]);
		return 0;
	}
	temp=num2[0];
	for(i=0;sign[i]!='\0';i++)
	temp=cal(temp,num2[i+1],sign[i]);
	printf("%d",temp);
	
	
} 


int cal(int a,int b,char c)
{
	if(c=='+')
	return a+b;
	if(c=='-')
	return a-b;
	if(c=='*')
	return a*b;
	if(c=='/')
	return a/b;
}



