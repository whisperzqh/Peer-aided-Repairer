#include<stdio.h>
#include<string.h>
int main()
{
	char a[1024],fu[1024],b[1024],fu1[1024];
	int i,sum[1024]={0},n,t,j=0,p,q=0,w=0,z=0,sum1[1024];
	gets(b);
	n=strlen(b);
	for(i=0;i<n;i++)
	{
		if(b[i]!=' ')
		{
		    a[j]=b[i];
			j++;	
		}
	}
	for(i=0;i<j;)
	{
		if(a[i]<='9'&&a[i]>='0')
		{
			for(t=1;a[i+t]<='9'&&a[i+t]>='0';t++)
			{
				continue;
			}
			for(p=i;p<i+t;p++)
			{
				sum[q]=sum[q]*10+a[p]-'0';
			}
			q++;
			i=i+t;
			continue;
		}
		if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='=')
		{
			fu[w]=a[i];
			w++;
			i++;
		}
	}
	for(i=0,j=0;i<w;i++)
	{
		if(fu[i]=='+'||fu[i]=='-'||fu[i]=='=')
		{
			sum1[j]=sum[i];
			fu1[j]=fu[i];
			j++;
		}
		if(fu[i]=='*')
		{
			sum[i+1]=sum[i]*sum[i+1];
		}
		if(fu[i]=='/')
		{
			sum[i+1]=sum[i]/sum[i+1];
		}}
		z=sum1[0];
		for(i=0;i<strlen(fu1);i++)
		{
			if(fu1[i]=='+')
			{
				z=z+sum1[i+1];
			}
			if(fu[i]=='-')
			z=z-sum1[i+1];
		}
		
	
	printf("%d",z);
	return 0;
	
}

