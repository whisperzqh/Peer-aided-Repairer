#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
char a[2000];
int b[2000];
int main()
{
    int i,j,k,m,s=0;
    gets(a);
    for(i=0,j=0;a[i]!='\0';i++)
     {
      if(a[i]!=' ')
        a[j]=a[i],j=j+1;
     }
     a[j]='\0';
     k=0;
    for(i=0,j=0;a[i]!='\0';i++)
    {
        if(!isdigit(a[i]))
        {
            b[j]=atoi(a+k);
            j=j+1;
            b[j]=a[i];
            j=j+1;
            k=i+1;
        }
    }

    for(i=1;b[i]!='=';i=i+2)
    {
        m=0;
        if(b[i]=='*')
        {
            m=b[i+1];
            b[i+1]=m*b[i-1];
            b[i-1]=0;
            b[i]='+';
        }
        if(b[i]=='/')
        {
            m=b[i+1];
            b[i+1]=b[i-1]/m;
            b[i-1]=0;
            b[i]='+';
        }
    }
    s=b[0];
    for(i=1;b[i]!='=';)
    {
        if(b[i]=='+') s+=b[i+1];
        if(b[i]=='-') s-=b[i+1];
        i=i+2;
    }
    printf("%d",s);
    return 0;
}

