#include <stdio.h>
#include <ctype.h>
#include <string.h>
int main()
{
	char s[10000],f[10000];
	int i,i1,i2,n[10000],a=0,ans,l,flag=0;
	gets(s);
	
	if(s[0]=='-')
	{
	flag=1; 
	for(i=0;s[i]!='\0';i++)
	s[i]=s[i+1];
	}
	
	for(i=0,i1=0;s[i]!='\0';i++)
	{
		if(s[i]!=' ')
		s[i1++]=s[i];			
	}
	if(i1!=0)
	s[i1]='\0';
	
	
	for(i=0,i1=0,i2=0;s[i]!='\0';i++)
	{
		if(isdigit(s[i])!=0)
		a=a*10+s[i]-'0';
		
		
		if(isdigit(s[i])==0)
		{
		f[i2++]=s[i];
		n[i1++]=a;
		a=0;}
	}
	if(i2!=0)
	f[i2]='\0';
	if(i1!=0)
	n[i1]='\0';
	l=i1;
	
	if(flag==1)
	n[0]=-1*n[0];
	
	for(i=0,i1=0;f[i]!='\0';i++)
	{
		if(f[i]=='*')
		{	
			
			n[i+1]=n[i]*n[i+1];
			n[i]=0;
		}
		else if(f[i]=='/')
		{
			
			n[i+1]=n[i]/n[i+1];
			n[i]=0;
		}
		else f[i1++]=f[i];
	}
	
	
	for(i=0,i1=0;i<l;i++)
	{
		if(n[i]!=0)
		n[i1++]=n[i];
	}
	l=i1;
	
	
	
	for(i=0,ans=n[0],i1=1;i<l;i++)
	{
		if(s[i]=='+')
		ans+=n[i1++];
		else if(s[i]=='-')
		ans-=n[i1++];
	}
	printf("%d",ans);
	return 0;
 } 

