#include<stdio.h>
#include<ctype.h> 
#include<string.h>
char s[3000000];
int num[3000000];
char c[3000000];
int main()
{
    gets(s);
    int i,j=1,k,l=0,m=0,sum=0;
    for(i=0,k=0;s[i]!='\0';i++){
    	if(s[i]!=' ') s[k++]=s[i];
	} 
	s[k]='\0';
	for(i=0;i<k;i++){
		if(!(isdigit(s[i]))) c[j++]=s[i];
	}
	c[j]='\0';
	if(j==2){
		for(i=0;i<k-1;i++) sum=10*sum+s[i]-'0';
		printf("%d",sum) ;
	}
	else{
		m=0;
		for(i=0;i<k;i++){
			if(isdigit(s[i])) {
				sum=sum*10+s[i]-'0';
			}
			else{
				num[m++]=sum;sum=0;
			}
		}
		sum=0;
		for(i=0;i<m;i++){
			if(c[i+1]=='*'&&c[i]!='*'&&c[i]!='/'){
				sum=num[i]*num[i+1];l=i;
			}
			if(c[i+1]=='*'&&(c[i]=='*'||c[i]=='/')){
				sum*=num[i+1];
			}
			if(c[i+1]=='/'&&(c[i]=='*'||c[i]=='/')){
				sum/=num[i+1];
			}
			if(c[i+1]=='/'&&c[i]!='*'&&c[i]!='/'){
				sum=num[i]/num[i+1];l=i;
		}
			if((c[i+1]=='+'||c[i+1]=='-')&&(c[i]=='+'||c[i]=='-')){
				num[l]=sum;
			}
			if((c[i+1]=='=')&&(c[i]=='*'||c[i]=='/')){
				num[l]=sum;
			}
		}
		sum=0;
		for(i=0;i<m;i++){
			if(c[i+1]=='+') sum+=num[i+1];
			if(c[i+1]=='-') sum-=num[i+1];
		}
		sum+=num[0];
		printf("%d",sum);
		
	}
    
	return 0;
  
 } 

