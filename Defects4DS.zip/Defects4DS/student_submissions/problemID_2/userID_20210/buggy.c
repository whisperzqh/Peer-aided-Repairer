#include <stdio.h>
#include <string.h>

int l1, l2, ans, i, j, k, l, a[1000], aa[1000];
char b[1000], bb[1000], s[1000];
int main()
{
    gets(s);
    for(i=0, j=0, k=0;s[i]!='=';i++)
    {
        if(s[i]>='0'&&s[i]<='9')
        {   a[j]=s[i];
            while(s[i+1]>='0'&&s[i+1]<='9')
            {
                a[j]=a[j]*10+s[i+1];
                i++;
            }
            j++;
        }
        else if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/')
        {
            b[k]=s[i];
            k++;
        }
    }
    for(i=0, l=0;i<=k;i++)
    {
        aa[l]=a[i];
        while(b[i]=='*'||b[i]=='/')
        {
            if(b[i]=='*')
            aa[l]*=a[i+1];
            else if(b[i]=='/')
                aa[l]/=a[i+1];
            i++;
        }
        if(b[i]=='+'||b[i]=='-')
        {
            bb[l]=b[i];
            l++;
        }
    }
    ans=aa[0];
    for(i=0;i<=l;i++)
    {
        if(bb[i]=='+')
            ans+=aa[i+1];
        else if(bb[i]=='-')
            ans-=aa[i+1];
    }
    printf("%d", ans);
return 0;
}

