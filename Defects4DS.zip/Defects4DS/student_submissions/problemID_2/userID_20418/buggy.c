//
#include<stdio.h>
#include<string.h> 
#include<ctype.h>
int main()
{	
	int number[1000]={0},cnumber[1000];
	char sign[1000],s[2000],csign[1000];
	int i,j=0,k=0,i1=0,ans=0;
	gets(s);
	for(i=0;s[i]!='=';i++)
	{
		if(isdigit(s[i]))
		{
			while(isdigit(s[i]))
			{
				number[j]=number[j]*10+s[i]-'0';
			i++;
			}
			j++;i--;
		}
		
		else
		{
			sign[k]=s[i];
			k++;
		}
	}
	
	for(i=0;i<j;i++)
	{
		cnumber[i1]=number[i];
		while(sign[i]=='*'||sign[i]=='/')
		{
			if(sign[i]=='*')
			{
				cnumber[i1]*=number[i+1];
			}
			else 
				cnumber[i1]/=number[i+1];
			i++;	
		}
		if(sign[i]=='+'||sign[i]=='-')
		{
			csign[i1]=sign[i];
			i1++;
		}
	}
	for(i=0;i<i1;i++)
	{
		if(csign[i]=='+')
			cnumber[i+1]=cnumber[i]+cnumber[i+1];
		else
			cnumber[i+1]=cnumber[i]-cnumber[i+1];	
	}
	printf("%d",cnumber[i]);
 } 



