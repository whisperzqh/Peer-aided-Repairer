#include<stdio.h>
#include<math.h>
#include<string.h>
#include<ctype.h>
char c[100];
int i,j=0,k=0,lenb,sum=0,a[100],b[100];
int main()
{
	for(i=0;i<100;i++)
      {a[i]=-6;
       b[i]=-6;}
gets(c);
lenb=strlen(c);
for(i=0;i<lenb;i++)   //
{
	if(c[i]=='+')
	{a[j]=-1;
	  j++;} 
	if(c[i]=='-')
	{a[j]=-2;
	  j++;}
	if(c[i]=='*')
	{a[j]=-3;
	 j++;}
	if(c[i]=='/')
	{a[j]=-4;
	  j++;}
	if((c[i]<='9') && (c[i]>='0'))//
	{ 

	     a[j]=c[i]-'0';
		 for(k=0;k<(lenb-i);k++)  //
	     {
	     	if((c[i+k+1]<='9') && (c[i+k+1]>='0')) //
	     	{a[j]=10*a[j]+(c[i+k+1]-'0');}
	     	else
			  {goto tiao1;}
		 }
	tiao1:i=i+k;
	j++;
	}
}
//printf("%d %d %d %d %d %d %d %d %d %d %d %d %d %d \n",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13]);
for(j=0;a[j]!=-6;j++)   
{
	if(a[j]==-3)
	{a[j+1]*=a[j-1];//
	 a[j-1]=-5; 
	 a[j]=-5;}
	if(a[j]==-4)
	{
		a[j+1]=a[j-1]/a[j+1];
		a[j-1]=-5;
		a[j]=-5;
	}
}
//printf("%d %d %d %d %d %d %d %d %d %d %d %d %d %d \n",a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8],a[9],a[10],a[11],a[12],a[13]);
k=0;
for(j=0;a[j]!=-6;j++)
{if(a[j]!=-5)
    {b[k]=a[j];
     k++;}
}
//printf("%d %d %d %d %d %d %d\n",b[0],b[1],b[2],b[3],b[4],b[5],b[6]);
sum=b[0];
for(j=0;b[j]!=-6;j++)
{
	if(b[j]==-1)
	{
	  sum+=b[j+1];
	  //
	}
	if(b[j]==-2)
	{sum-=b[j+1];
	//
    }
}
printf("%d",sum);
  return 0;
}



