#include<string.h>
#include<stdio.h>
int main()
{
	int i=0,j=0;
	char first[10000];
    long long sign[10000];
    long long sign_[10000];
	int s=0;
	long long number[10000];
	int b=1;
	long long pl=1;
	long long sum=0;
	gets(first);
	while(i<strlen(first))
	{
		if(first[i]!=' ')
		{
			first[j]=first[i];
			j++;
		}
		i++;
	}
	i=0;
	first[j]='\0';
	while(i<j)
	{
		if((first[i]<'0') || (first[i]>'9'))
		{
			sign[s]=i;
			s++;
		}
		i++;
	}
	i=0;
	if((first[0] == '+') || (first[0] == '-'))
	{
		number[0]=0;
	}
	else
	{
		i=sign[0]-1;
		while(i>=0)
		{
			pl=10*pl;
			number[0]=pl*(first[i]-'0')+number[0];
			i--;
		}
		number[0]=number[0]/10;
	}
	pl=1;
	while(b<s)
	{
		i=sign[b]-1;
		while(i>sign[b-1])
		{
			pl=10*pl;
			number[b]=pl*(first[i]-'0')+number[b];
			i--;
		}
		pl=1;
		number[b]=number[b]/10;
		b++;
	}
	i=0;
	while(i<s)
	{
		if(first[sign[i]]=='*') 
		{
			number[i+1]=number[i]*number[i+1];
		}
		else if(first[sign[i]]=='/')
		{
			number[i+1]=number[i]/number[i+1];
		}
		i++;
	}

	i=0;
	j=0;
	sum=number[0];
	while(i<s)
	{
		if((first[sign[i]]=='+') || (first[sign[i]] =='-'))
		{
			sign_[j]=i;
			j++;
		}
		i++;
	}
	sign_[j]=s-1;
	i=0;
	while(i<j)
	{
		if(first[sign[sign_[i]]]=='+')
		{
			sum=sum+number[sign_[i+1]];
		}
		if(first[sign[sign_[i]]]=='-')
		{
			sum=sum-number[sign_[i+1]];
		}
		i++;
	}
	printf("%lld",sum);
	return 0;
}

