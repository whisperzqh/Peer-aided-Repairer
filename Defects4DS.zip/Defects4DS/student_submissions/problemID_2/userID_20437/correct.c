#include<stdio.h>
#include<math.h>
#include<string.h>
void delete_char(char str[],char target)
{
	int i,j;
	for(i=j=0;str[i]!='\0';i++)
    {
		if(str[i]!=target)
		{
			str[j++]=str[i];
		}
	}
	str[j]='\0';
}
int main()
{char s[100001],a[10001],c[10001],x=' ';
int i,b[10001],flag=-1,j,y=0,sum=0,z=0;
gets(s);
delete_char(s,x);
for(i=0;i<=strlen(s)-1;i++)
{
    if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'||s[i]=='=')
    {
       for(j=0;j<=i-flag-2;j++)
       {
           a[j]=s[flag+1+j];
       }
       a[j]='\0';
       b[y]=atoi(a);
       c[y]=s[i];
       y=y+1;
       flag=i;
    }
}
for(i=0;i<=y-2;i++)
{
    if(c[i]=='*')
    {
        b[i+1]=b[i]*b[i+1];
        b[i]=0;
        if(i==0)c[i]='+';
        else if(c[i-1]=='+')
            c[i]='+';
        else if(c[i-1]=='-')
            c[i]='-';
    }
    else if(c[i]=='/')
    {
        b[i+1]=b[i]/b[i+1];
        b[i]=0;
        if(i==0)c[i]='+';
        else if(c[i-1]=='+')
            c[i]='+';
        else if(c[i-1]=='-')
            c[i]='-';
    }
}
z=b[0];
for(i=0;i<=y-2;i++)
{
    if(c[i]=='-')
        z=z-b[i+1];
    else if(c[i]=='+')
        z=z+b[i+1];
}
printf("%d",z);
return 0;
}

