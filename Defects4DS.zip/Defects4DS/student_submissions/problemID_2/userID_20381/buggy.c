#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h> 
void delete1(char str[],char c)
{
   int i,j;
   for(i=j=0;str[i]!='\0';i++)
   {
   	if(str[i]!=c)
   	str[j++]=str[i];
   }
   	str[j]='\0';
	return;	
}
char ito(int n,char skt[])
{
	int count = n;
	int i = 0;
	if (count < 0)//
	{
		n = -n;
	}
	while (n > 0)
	{
		skt[i++] = n % 10 + '0';//
		n /= 10;
	}
	if (count < 0)
	{
		skt[i++] = '-';
	}
	skt[i] = '\0';
	int lo=0,hi=0,t;
	while(skt[hi]!='\0')
	hi++;
	for(hi--;hi>lo;lo++,hi--)
	{
		t=skt[lo];
		skt[lo]=skt[hi];
		skt[hi]=t;
	}
	return;
}
int find(char st[])
{
	
	int i,j,n=0,n1=0,n2=0,k,t;
	char *p,std[100],*q;
	int flag=1;
	for(i=0;st[i]!='\0';i++)
	{
		if(st[i]=='+'||st[i]=='-'||st[i]=='*'||st[i]=='/') 
		flag =0;
	}
	if(flag==1)
	{
	    i=0;
		while(isdigit(st[i]))
			{
				n=n*10+(st[i]-'0');
				i++;
			}
			return n;
	}
	for(i=0;st[i]!='\0';i++)
	{
		if(st[i]=='+')
		{
			p=&st[i+1];
			q=&st[0];
			for(j=0;*(p+j)!='\0';j++)
			{
				std[j]=*(p+j);
			}
			std[j]='\0';
			while(isdigit(*q))
			{
				n=n*10+(*q-'0');
				q++;
			}	
			return n+find(std);
		}
		if(st[i]=='-')
		{
			p=&st[i+1];
			q=&st[0];
			for(j=0;*(p+j)!='\0';j++)
			{
				std[j]=*(p+j);
				if(*(p+j)=='+')
		     	{
			    std[j]='-';
			    }
		        if(*(p+j)=='-')
		        {
			    std[j]='+';
			    }
			}
			std[j]='\0';
			while(isdigit(*q))
			{
				n=n*10+(*q-'0');
				q++;
			}
			return n-find(std);
		}
		if(st[i]=='*')
		{
			p=&st[i+1];
			q=&st[0];
			while(isdigit(*q))
			{
				n1=n1*10+(*q-'0');
				q++;
			}while(isdigit(*p))
			{
				n2=n2*10+(*p-'0');
				p++;
			}
			n=n1*n2;
			p=&st[i+1];
			q=&st[0];
			j=0;
			while(isdigit(*(p+j)))
			j++;
			for(k=j+1,t=0;*(p+k)!='\0';k++,t++)
			{
				std[t]=*(p+k);
			}
			if(*(p+j)=='\0')
			return (n1*n2);
			else if(*(p+j)=='+')
			return (n1*n2)+find(std);
			else if(*(p+j)=='-')
			return (n1*n2)-find(std);
			else if(*(p+j)=='*')
			{
			char stc[100],std1[2]="*";
			ito(n,stc);
			strcat(stc,std1);
			strcat(stc,std);
			return find(stc);
			}
			else if(*(p+j)=='/')
			{
			char stc[100],std1[2]="/";
			ito(n,stc);
			strcat(stc,std1);
			strcat(stc,std);
			return find(stc);
			}
		}
		if(st[i]=='/')
		{
			p=&st[i+1];
			q=&st[0];
			while(isdigit(*q))
			{
				n1=n1*10+(*q-'0');
				q++;
			}while(isdigit(*p))
			{
				n2=n2*10+(*p-'0');
				p++;
			}
			n=n1/n2;
			p=&st[i+1];
			q=&st[0];
			j=0;
			while(isdigit(*(p+j)))
			j++;
			for(k=j+1,t=0;*(p+k)!='\0';k++,t++)
			{
				std[t]=*(p+k);
			}
			if(*(p+j)=='\0')
			return (n1/n2);
			else if(*(p+j)=='+')
			return (n1/n2)+find(std);
			else if(*(p+j)=='-')
			return (n1/n2)-find(std);
			else if(*(p+j)=='*')
			{
			char stc[10],std1[2]="*";
			ito(n,stc);
			strcat(stc,std1);
			strcat(stc,std);
			return find(stc);
			}
			else if(*(p+j)=='/')
			{
			char stc[100],std1[2]="/";
			ito(n,stc);
			strcat(stc,std1);
			strcat(stc,std);
			return find(stc);
			}
		}
	}
}
int main()
{
	char c[100];
	gets(c);
	delete1(c,' ');
	delete1(c,'=');
	printf("%d",find(c));
}

