#include<stdio.h>
#include<string.h>
int main()
{
	char a[1000000];
	int n,m,ans,i=0,j=0,k=0,b[100001],c[100001];
	gets(a);
	n=strlen(a);
	while(i<n)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			if(i>=1)
			{
				if(a[i-1]>='0'&&a[i-1]<='9')
				{
					j--;
					b[j]=b[j]*10+a[i]-'0';
					i++;
					j++;
					continue;
				}
			}
			b[j]=a[i]-'0';
			j++;
			i++;
			continue;
		}
		switch (a[i]){
        case '+':b[j]=-1;j++;  break;
        case '-':b[j]=-2;j++;  break;
        case '*':b[j]=-3;j++;  break;
        case '/':b[j]=-4;j++;  break;
        default:break;
    	}
    	if(a[i]=='=')
    		break;
    	i++;
	}
	m=j;
	j=0;
	while(j<=m)
	{
		if(b[j+1]==-3)
		{
			b[j+2]=b[j]*b[j+2];
			j=j+2;
			continue;
		}
		else if(b[j+1]==-4)
		{
			b[j+2]=b[j]/b[j+2];
			j=j+2;
			continue;
		}
		else
		{
			c[k]=b[j];
			k++;
			j++;
		}
	}
	m=k;
	j=0;
	while(j<=m)
	{
		if(c[j+1]==-1)
		{
			c[j+2]=c[j]+c[j+2];
			j=j+2;
			continue;
		}
		else if(c[j+1]==-2)
		{
			c[j+2]=c[j]-c[j+2];
			j=j+2;
			continue;
		}
		else
		{
			ans=c[j];
			break;
		}
	}
	printf("%d",ans);
	
	return 0;
}

