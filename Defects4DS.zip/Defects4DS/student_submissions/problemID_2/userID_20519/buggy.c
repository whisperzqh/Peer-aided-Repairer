#include<stdio.h>
#include<string.h>
#include<ctype.h>

char s[0x7ffff] , s2[0x7ffff];
int  number1[0x7ffff] = {0} , number2[0x7ffff] = {0};
char symbol1[0x7ffff] , symbol2[0x7ffff];


int main()
{ 
	gets(s);
	int i , j = 0 ,k = 0, ans = 0;
	int i1 = 0 , cnt = 0;
	for(i = 0;s[i] != '=';i++){
		if(s[i] != ' '){
			s2[j] = s[i];
			j++;
		}
	}
	
	j = 0;
	
	for(i = 0;i <= strlen(s2);i++){
		if(isdigit(s2[i])){
			number1[j]*=10; 
			number1[j]+=s2[i]-'0';
		}
		else{
			j++;
			symbol1[k] = s2[i];
			k++;
		}
	}
	
	if(symbol1[0] == '\0'){
		for(i = 0;i < j;i++){
			printf("%d" , number1[i]);
		}
	}
	
	else{
	
	for(i = 0;i<k;i++)
	{
		if(i < 0) 
		i += 1;
		
		if(symbol1[i] == '*')
		{
			number1[i] = number1[i] * number1[i + 1];
			for(j = i + 2;j <= 99;j++)
			{
				number1[j - 1] = number1[j];
			}
			
			for(j = i;;j++)
			{
				if(symbol1[j] == '\0')
					break;
					
				symbol1[j] = symbol1[j + 1]; 
			}
			i -= 1;
		}
		
		else if(symbol1[i] == '/')
		{
			number1[i] = number1[i] / number1[i + 1];
			for(j = i + 2;j <= 99;j++)
			{
				number1[j - 1] = number1[j];
			}
			
			for(j = i;;j++)
			{
				if(symbol1[j] == '\0')
					break;
					
				symbol1[j] = symbol1[j + 1]; 
			}
			i -= 1;
		}
	}
 	
	 
	 /*for(i = 0 , x = 0;i < k;i++){
		if((symbol1[i] == '*') || (symbol1[i] == '/')){
		number2[i1] = number1[x];
		while((symbol1[i] == '*')|| (symbol1[i] == '/')){
			if(symbol1[i] == '*' ){
			number2[i1] *= number1[++x];
			x++;
			if(symbol1[i+1] != '*' && symbol1[i+1] != '/')
			i1++;
		}
			else{
			number2[i1] /= number1[++x];
			x++;
			if(symbol1[i+1] != '*' && symbol1[i+1] != '/')
			i1++;
		}
		i++;
		}
	i--;
	}
		else {
			symbol2[h] = symbol1[i];
			number2[i1] = number1[x];
			h++;
			if(symbol1[i+1] != '*' && symbol1[i+1] != '/') 
			i1++;
		}
	}*/
	ans = number1[0];
	for(i = 0;number1[i] != 0;i++){
		cnt++;
	}
	for(i = 0;i < cnt;i++){
		if(symbol1[i] == '+')
		ans += number1[i+1];
		else if(symbol1[i] == '-')
		ans -= number1[i+1];
	}
	printf("%d" , ans);
}
	return 0;
}

