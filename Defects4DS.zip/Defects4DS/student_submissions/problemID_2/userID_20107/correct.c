#include<stdio.h>
#include<string.h>

int cal(int,int,char);

int main(){
	int a;
	char c;
	int b;
	char op;
	int flag=0;
	scanf("%d %c",&a,&c);
	while(scanf("%d %c",&b,&op)!=EOF)
	{
	
		while((op=='*'||op=='/'))
		{
			int m;
			char op2;
			if(c=='/'&&flag==0){
				b=a/b;
				flag=1;
			}
			scanf("%d %c",&m,&op2);
			b=cal(b,m,op);
			op=op2;
		}
			if(op=='+'||op=='-'||op=='=')
			{
				if(flag==0)
			{
			b=cal(a,b,c);
			c=op;}
			else
			{
				c=op;
				flag=0;
			}
			a=b;
		    }
	}
	printf("%d\n",a);
	
}

int cal(int n,int m,char op)
{
	if(op=='+')
	return n+m;
	else if(op=='-')
	return n-m;
	else if(op=='*')
	return n*m;
	else if(op=='/')
	return n/m;
	else if(op=='=')
	return m;
	
}

