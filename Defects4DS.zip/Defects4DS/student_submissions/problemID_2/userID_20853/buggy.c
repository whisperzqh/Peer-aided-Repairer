#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
int main()
{
	char s[100];
	gets(s);
	int shu[60]={0};
	char fu[60]={0};
	int lens=strlen(s);
	for(int i=0,j=0;i<lens;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		shu[j]=shu[j]*10+s[i]-'0';
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'||s[i]=='=')
		{
			fu[j]=s[i];
			j++;
		}
		if(s[i]=='=')
		break;
	}
	int lenfu=strlen(fu);
	int ji[60]={0};
	char jiajian[60]={0};
	for(int p=0,q=0;p<lenfu;p++)
	{
		
		ji[0]=shu[0];
		if(fu[p]=='*')
		{
		ji[q]=ji[q]*shu[p+1];
		}
		if(fu[p]=='/')
		ji[q]=ji[q]/shu[p+1];
		if(fu[p]=='+'||fu[p]=='-')
		{jiajian[q]=fu[p];
		ji[q+1]=shu[p+1];
		q++;
		}
	}
	int he=ji[0];
	int lenjia=strlen(jiajian);
	for(int x=0;x<lenjia;x++)
	{
		if(jiajian[x]=='+')
		he=he+ji[x+1];
		if(jiajian[x]=='-')
		he=he-ji[x+1];
	}
	printf("%d",he);
	return 0;
 } 

