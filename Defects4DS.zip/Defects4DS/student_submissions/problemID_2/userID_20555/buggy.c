#include<stdio.h>
int jisuan(int a,char op,int b);
int shuzi();
char zifu();

int shuzi()
{
	int number;
	scanf(" %d",&number);
	return number;
}

char zifu()
{
	char op;
	scanf(" %c",&op);
	return op;
}

int jisuan(int a,char op,int b)
{
	int ans;
	if(op=='+')
	ans=a+b;
	else if(op=='-')
	ans=(a-b);
	else if(op=='*')
	ans=a*b;
	else 
	ans=a/b;
	return ans;
}

int main()
{
	int a[5],d;
	char b[5],c;
	a[1]=shuzi();
	b[1]=zifu();
	if(b[1]!='=')
	a[2]=shuzi();
    
	while(b[1]!='=')
	{
	
	if(b[1]=='*'||b[1]=='/')
	 {
		a[1]=jisuan(a[1], b[1], a[2]);
		b[1]=zifu();
		if(b[1]!='=')
	    a[2]=shuzi();
       
	 } 
	 else
	 {	
	   c=zifu();
	    if(c=='+'||c=='-')
		{
	      	a[1]=jisuan(a[1],c, a[2]);
	      	b[1]=c;
	      	a[2]=shuzi();
		}
		else if(c=='=')
		{
			a[1]=jisuan(a[1], b[1], a[2]);
			b[1]=c;
		
		}
		else
		{
			d=shuzi();
			a[2]=jisuan(a[2],c,d);
		
		}
	 }
	 }
	 printf("%d\n",a[1]);
	 return 0;
} 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

