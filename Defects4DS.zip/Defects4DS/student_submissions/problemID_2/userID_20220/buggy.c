#include<stdio.h>
#include<string.h>
int main()
{
    int a[2048],sum1=0,sum=0,i,x=1,y=0,t=0,u=1;
    char s[2048],r[10000];
    gets(r);
        for(i=0;i<=2047;i++){a[i]=0;}
    for(i=0;i<strlen(r);i++){
        if((r[i]>='0')&&(r[i]<='9')) {a[x]=a[x]*10+(int)(r[i])-48;}
        else {
            if(r[i]!=' '){x++;y++;s[y]=r[i];}
        }
    }
    if(y==1) printf("%d",a[1]);
    else {for(i=1;i<y;i++){
        if(s[i]=='+'){
            if(t==0){sum=sum+u*a[i];u=1;}
            else if(t==1){sum=sum+sum1*a[i];t=0;u=1;}
            else {sum=sum+sum1/a[i];t=0;u=1;}
        }
        else if(s[i]=='-'){
            if(t==0){sum=sum+u*a[i];u=-1;}
            else if(t==1){sum=sum+sum1*a[i];t=0;u=-1;}
            else {sum=sum+sum1/a[i];t=0;u=-1;}
        }
        else if(s[i]=='*'){
            if(t==0){sum1=u*a[i];t=1;}
            else if(t==1){sum1=sum1*a[i];}
            else {sum1=sum1/a[i];t=1;}
        }
        else if(s[i]=='/'){
             if(t==0){sum1=u*a[i];t=2;}
            else if(t==1){sum1=sum1*a[i];t=2;}
            else {sum1=sum1/a[i];}
        }
     }
     if(t==0) sum=sum+a[i]*u;
     else if(s[i-1]=='*') sum=sum+u*sum1*a[i];
     else sum=sum+u*sum1/a[i];
     printf("%d",sum);}
    return 0;
}

