#include <stdio.h>
#include <ctype.h>
void nospace(char str[])
{
    int i,j;
    for(i=j=0;str[i]!='\0';i++)
        if(str[i] !=' ')
        str[j++]=str[i];
    str[j]='\0';
}//
int compare(char lastcal,char nowcal)
{
    if((lastcal=='+'||lastcal=='-')&& (nowcal=='*' || nowcal=='/') )
        return -1;
    else if((lastcal=='*'||lastcal=='/') && (nowcal=='+'|| nowcal=='-'))
        return 1;
    else
        return 0;
}//
int deal(int n1,char x,int n2)
{
    if(x=='+')
        return n1+n2;
    if(x=='*')
        return n1*n2;
    if(x=='-')
        return n1-n2;
    if(x=='/')
        return n1/n2;
}//
int main(void)
{
    int tmp=0,flag=0,i=0,nownum,nowcal,lastnum=0,lastcal=0,numrank=0,numtail=0,calrank=0,caltail=0,result;
    int num[255];char cal[255];
    char str[255];

    gets(str);
    nospace(str);//

    while(str[i] !='\0')
    {
        if(isdigit(str[i]))
            tmp=tmp*10+str[i]-'0';//
        if(str[i]=='+'||str[i]=='-'||str[i]=='*'||str[i]=='/'||str[i]=='=')
            {
                num[numrank++]=tmp;
                cal[calrank++]=str[i];
                tmp=0;
            //

        if(calrank>(caltail+1) && compare(cal[calrank-2],cal[calrank-1])==0)
        {
            num[numrank-2]=deal(num[numrank-2],cal[calrank-2],num[numrank-1]);
            numrank--;//
            cal[calrank-2]=cal[calrank-1];
            calrank--;//
        }//ͬ

        if(calrank>(caltail+1) && compare(cal[calrank-2],cal[calrank-1])==1)
        {
            num[numrank-2]=deal(num[numrank-2],cal[calrank-2],num[numrank-1]);
            numrank--;//
            cal[calrank-2]=cal[calrank-1];
            calrank--;
        }//

        if(str[i]=='=')
        {
            calrank-=2;numrank--;
            while(calrank>=caltail)
            {
                num[numtail+1]=deal(num[numtail],cal[caltail],num[numtail+1]);
                printf("numrank: %d,  calrank:%d",numrank,calrank);
                numtail++;caltail++;
            }
        }

            }
        i++;
    }
printf("%d",num[numtail]);


    return 0;
}

