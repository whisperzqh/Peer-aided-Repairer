#include <stdio.h>
#include <string.h>
int chengchu (int a,int b,char c)
{
	if (c=='*')return a*b;
	else return a/b;
}
int main ()
{
	long long int a[1050]={0},i,j,sum=0;
	char cc[1050],c[1050];
	
	gets(cc);
	
	for(i=0,j=0;i<strlen(cc);i++)
	{
		if(cc[i]>='0'&&cc[i]<='9')
		{
			a[j]=a[j]*10+cc[i]-48;
		}
		else if(a[j]!=0)j++;
	}
	
	for(i=0,j=0;cc[i]!='=';i++)
	{
		if(cc[i]=='+'||cc[i]=='-'||cc[i]=='*'||cc[i]=='/')c[j++]=cc[i];
	}
	for (i=0;i<strlen(c);i++)
	{
		if(c[i]=='-')a[i+1]=-a[i+1];
		if(c[i]=='*'||c[i]=='/')
		{
			a[i+1]=chengchu(a[i],a[i+1],c[i]);
			a[i]=0;
		}
	}
	for (i=0;i<1050;i++)sum+=a[i];
	printf("%lld",sum);
	return 0;
	
}

