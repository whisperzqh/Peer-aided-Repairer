#include<stdio.h>
#include<string.h>

int main(){
	char s1[500],s[500]={'\0'},sim[300];
	char ms[300];
	gets(s1);
	int num[300]={0},res[300]={0},i=0,j=0,k=0,r,m=0;
	int ans=0;
	j=0;
	for(i=0;s1[i]!='\0';i++){
		if(s1[i]!=' '){
			s[j]=s1[i];
			j++;
		}
	} 
	i=j=0;
	while(s[i]!='\0'){
		num[j]=0;
		if(s[i]>='0'&&s[i]<='9'){
			while(s[i]>='0'&&s[i]<='9'){
				num[j]=num[j]*10+s[i]-'0';
				i++;
			}
			j++;
		}
		else i++;
	}  //
	
	for(i=0;s[i]!='\0';i++){
		if(s[i]!=' '&&(s[i]<'0'||s[i]>'9')){
			sim[k]=s[i];
			k++;
		}
	} //
	
	if(sim[0]=='='){
			ans+=num[0];
			printf("%d",ans);
		}
	r=0;
	for(k=0;sim[k]!='\0';k++){
		res[r]=num[k];
		if(sim[k]=='*'||sim[k]=='/'){
			for(i=k;sim[i]=='*'||sim[i]=='/';i++){
				if(sim[i]=='*') res[r]=res[r]*num[i+1];
				else if(sim[i]=='/') res[r]=res[r]/num[i+1];
				else break;
			}
			k=i;
		}
		if(sim[k]=='+'||sim[k]=='-'||sim[k]=='='){
			ms[m]=sim[k];
			m++;
		}
		r++;
	}
//
	
	ans=res[0];
	for(m=0;ms[m]!='\0';m++){
		if(ms[m]=='+'){
			ans+=res[m+1];
		}
		if(ms[m]=='-'){
			ans-=res[m+1];
		}
		if(ms[m]=='='){
			break;
		}
	} 
	printf("%d",ans);
	
}

