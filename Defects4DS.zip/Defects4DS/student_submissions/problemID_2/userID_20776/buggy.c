#include<stdio.h> 
#include<string.h>
#define N 100010
int szcl(char s[],int i)//
{
	int k;
	k=s[i]-'0';
	i++;
	for(;'0'<=s[i]&&s[i]<='9';i++)
	{
		k=10*k+s[i]-'0';
	}
	return k;
}
//int pd(char m);
int main()
{
	char s[N],s2[N];
	int sz[N]={0};
	gets(s);
	int i,j,jg,k,m;
	/*for(i=0;i<strlen(s)&&s[i]!='=';i++)//
	{
		if(s[i]==' ')
		{
			for(j=i;j<strlen(s);j++)
			{
				s[j]=s[j+1];
			}
		}
	}*/
	for(i=0,j=0;s[i]!='\0';i++) {
		if(s[i]!=' '){
			s[j++]=s[i];
		}
	}
	s[j]='\0';
//	printf("@@@%s\n",s);
	
	for(i=0,j=0,k=0;i<strlen(s);i++)//
	{	
		//printf("&&%d %c \n",i,s[i]);
		if('0'<=s[i]&&s[i]<='9')
		{
			 
			sz[j]=szcl(s,i);
			for(;'0'<=s[i]&&s[i]<='9';i++);
			j++;
			i--; 
		}
		else
		{	
			s2[k]=s[i];
			//printf("^^^%c\n",s2[i]);
			k++;
		}
	}
//	printf("##");
	for(i=0;i<strlen(s)/2;i++) {
//		printf("%d ",sz[i]);
	}
//	printf("\n");
//	printf("###");
	for(i=0;i<strlen(s)/2;i++) {
		printf("%c ",s2[i]);
	}
//	printf("\n");
	//
	//
	k=strlen(s)/2;
	for(i=0;i<k;i++)
	{
	 	if(s2[i]=='*')
	 	{
	 		sz[i]=sz[i]*sz[i+1];
	 		for(m=i+1;m<k;m++)
	 		{
	 			sz[m]=sz[m+1];
	 			s2[m-1]=s2[m];
			 }
			 //s2[k]='=';	
			 k--;
			 i--;
		 }else if(s2[i]=='/')
	 	{
	 		sz[i]=sz[i]/sz[i+1];
	 		for(m=i+1;m<k;m++)
	 		{
	 			sz[m]=sz[m+1];
	 			s2[m-1]=s2[m];
			 }
			 //s2[k]='=';	
			 k--;
			 i--;
		 }
	  } 
//	printf("!!");
	for(i=0;i<k;i++) {
		printf("%d ",sz[i]);
	}
//	printf("\n");
//	printf("!!!");
	for(i=0;i<k;i++) {
		printf("%c ",s2[i]);
	}
//	printf("\n");
	//
	for(i=0;i<k;i++)
	{
	 	if(s2[i]=='-')
	 	{
	 		sz[i]=sz[i]-sz[i+1];
	 		for(m=i+1;m<=k;m++)
	 		{
	 			sz[m]=sz[m+1];
	 			s2[m-1]=s2[m];
			 }
			 //s2[k]='=';	
			 k--;
			 i--;
		 }else if(s2[i]=='+')
	 	{
	 		sz[i]=sz[i]+sz[i+1];
	 		for(m=i+1;m<=k;m++)
	 		{
	 			sz[m]=sz[m+1];
	 			s2[m-1]=s2[m];
			 }
			 //s2[k]='=';	
			 k--;
			 i--;
		 }
	} 
	  printf("%d",sz[0]);
	return 0;
}
/*int szcl(char s[],int i)//
{
	int k;
	k=s[i]-'0';
	i++;
	for(;pd(s[i]);i++)
	{
		k=10*k+s[i]-'0';
	}
	return k;
}*/ 
/*int pd(char m)
{
	int k=0;
	if(m<='9'&&m>='0')
	k=1;
	return k;
}*/

