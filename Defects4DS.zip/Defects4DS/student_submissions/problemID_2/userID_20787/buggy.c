#include<stdio.h>
#include<string.h>
#define jia 1
#define jian 2
#define cheng 3
#define chu 4

void result(char a[])
{//
	int num=0,i,j=0,b[100][2]={0};
	int re[100]={0},flag=0;
	for(i=0;i<strlen(a);i++)
	{
		if(a[i]=='-')
		{
			num++;
			b[j][0]=flag;
			b[j++][1]=jian;
			flag=0;
		 } 
		if(a[i]=='+')
		{
			num++;
			b[j][0]=flag;
			b[j++][1]=jia;
			flag=0;
		} 
		if(a[i]=='*')
		{
			num++;
			b[j][0]=flag;
			b[j++][1]=cheng;
			flag=0;
		 } 
		 if(a[i]=='/')
		{
			num++;
			b[j][0]=flag;
			b[j++][1]=chu;
			flag=0;
		 } 
		 if(a[i]=='=')
		{
			num++;
			b[j++][0]=flag;
			flag=0;
		 } 
		if(a[i]>='0'&&a[i]<='9') 
		{
			flag=flag*10+a[i]-'0';
		}
	}
	i=0;
	for(j=0;j<num;j++)
	{
		if(b[j][1]==jian) 
		{
			b[j+1][0]=-b[j+1][0];
			re[i++]=b[j][0];
		}
		if(b[j][1]==jia) re[i++]=b[j][0];
		if(b[j][1]==cheng) 
		{
			b[j+1][0]*=b[j][0];
			if(b[j+1][1]==jia||b[j+1][1]==jian||b[j+1][1]==0)
			{
				re[i++]=b[++j][0];
				if(b[j][1]==jian)	b[j+1][0]=-b[j+1][0];
				if(b[j][1]==0) break;
			}
		}
		if(b[j][1]==chu)
		{//
			b[j+1][0]=b[j][0]/b[j+1][0];
			if(b[j+1][1]==jia||b[j+1][1]==jian||b[j+1][1]==0) 
			{
				re[i++]=b[j+1][0];
				if(b[j+1][1]==jian)	b[j+2][0]=-b[j+2][0];
				if(b[j+1][1]==0) break;
			}
		}
		if(b[j][1]==0) re[i++]=b[j][0];
	}
	int sum=0;
	for(j=0;j<i;j++) sum+=re[j];
	printf("%d",sum);
}
int main()
{
	char a[100],b[100];
	gets(a);
	int l=strlen(a);
	int i,j=0;
	for(i=0;i<l;i++)
	{
		if(a[i]!=' ')	b[j++]=a[i];
	}
	b[j]='\0';
	result(b);
	return 0;
}

