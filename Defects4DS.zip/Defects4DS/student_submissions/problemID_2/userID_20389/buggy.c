#include<stdio.h>
#include<string.h>
#include<math.h>
#include<ctype.h>
int main()
{
    int num[105]= {0}, m=0, n=0;
    int sub[50] = {1};
    int b=0;
    int ans=0;
    char sign[105]= {0},fuhao[105]={0};
    char st[205] = {0};
    scanf("%s",st);

    for(int i=0; st[i]!='\0' ; i++)
    {
        if(st[i]>='0' && st[i]<='9')
            num[m] = num[m]*10 + (st[i]-'0');
        else
        {
            sign[n++] = st[i];
            m++;


        }
    }

    for(int k=0,a=0; k<n; k++)
    {
        if( sign[k] == '+'|| sign[k] == '-'||sign[k] == '=')
        {
            sub[a] = num[k];
            fuhao[b++] = sign[k];
            a++;
        }
        else if(sign[k] == '*')
        {
            sub[a] = num[k]*num[k+1];
            num[k+1] = sub[a];
        }
        else if(sign[k] == '/')
        {
            sub[a] = num[k]/num[k+1];
            num[k+1] = sub[a];
        }

    }

ans=sub[0];


    for(int k=0; k<b; k++)
    {
        if(fuhao[k] == '-')
        {
            ans=ans-sub[k+1];


        }
        else
        {
            ans=ans+sub[k+1];

        }
    }

    printf("%d\n",ans);
    return 0;
}

