#include<stdio.h>
#include<string.h>
char a[10000];
char b[10000];
int c[10000];
char d[10000];
int e[10000];
char f[10000];
int main()
{
    int i,j,k,l=0,sum;
    gets(a);
    for(i=0,k=0;a[i-1]!='=';i++,k++)
    {
            while(a[i]==' ')
                i++;
            b[k]=a[i];
    }
    for(i=0,j=0,k=0;b[i]!='=';i++)
    {
       if(b[i]=='+'||b[i]=='-'||b[i]=='*'||b[i]=='/')
       {
       d[k++]=b[i];
       j++;}
        else
                c[j]=c[j]*10+b[i]-'0';
    }
    for(i=0;i<=k;i++)
    {
        if(d[i]=='+'||d[i]=='-')
        e[l++]=c[i];
        else
        {
            e[l]=c[i];
            for(;d[i]=='*'||d[i]=='/';i++)
            {
                if(d[i]=='*')
                    e[l]*=c[i+1];
                else
                    e[l]/=c[i+1];
            }
            l++;
        }
    }

            sum=e[0];
    for(i=0,k=0;i<l;i++)
    {
        if(d[k++]=='-')
            sum-=e[i+1];
        if(d[k++]=='+')
            sum+=e[i+1];
    }
    printf("%d",sum);
    return 0;
    }

