#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
int real[2000],temp[1000];
char a[2000];
int main()
{

    int sum=0;
    int i,j,k,l,m=0,n=0,len1,flag=0;
    gets(a);
    len1=strlen(a);
    for(i=0,k=0; i<len1; i++)
    {
        if(isspace(a[i]))
            continue;
        else if(a[i]=='=')
            break;
        else if(a[i]=='*')
        {
            real[k++]=-1;
            flag++;
        }
        else if(a[i]=='/')
        {
            real[k++]=-2;
            flag++;
        }
        else if(a[i]=='+')
        {
            real[k++]=-3;
            flag++;
        }
        else if(a[i]=='-')
        {
            real[k++]=0;
            flag++;
        }
        else
        {
            for(j=0; isdigit(a[i+j]); j++);
            for(l=0; l<j; l++)
                real[k]=real[k]*10+a[i+l]-'0';
            k++;
            i=i+j-1;

        }

    }
    if(flag==0)
    {
        printf("%d\n",real[0]);
        return 0;
    }
    
    for(i=0,j=0;i<k;i++)
    {
    	if(real[i]==-1)
    	{
    		j--;
    		for(m=0;real[i+2*m]==-1;m=m+1);
    		for(n=1;n<m+1;n++)
    		temp[j]*=real[i+2*n-1];
    		j++;
    		i=i+2*n-3;
		}
		else if(real[i]==-2)
		{
			j--;
    		for(m=0;real[i+2*m]==-2;m=m+1);
    		for(n=1;n<m+1;n++)
    		temp[j]/=real[i+2*n-1];
    		j++;
    		i=i+2*n-3;
		}
		else
		temp[j++]=real[i];
	}
	sum=temp[0];
	    for(i=0; i<j; i++)
    {

        if(temp[i]==-3)
        {
            sum=sum+temp[i+1];
            i++;
        }
        else if(temp[i]==0)
        {
            sum=sum-temp[i+1];
            i++;
        }
    }
    printf("%d",sum);
    return 0;
}

