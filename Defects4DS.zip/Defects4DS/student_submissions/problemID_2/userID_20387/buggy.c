#include<stdio.h>
#include<string.h>

int main()
{
	int a1,a2,r,flag=0;
	char c1='\0',c2='\0';
	scanf("%d",&a1);
	r=a1;
	while(1){
		if(flag==0){
		scanf(" %c",&c1);
		if(c1=='=')
		break;
		scanf("%d",&a1);
		}
		if(c1=='*')
			r*=a1;
		else if(c1=='/')
			r/=a1;
		else{
			scanf(" %c",&c2);
			scanf("%d",&a2);
			if(c2=='*'||c2=='/'){
				flag=1;
				if(c2=='*')
				a1*=a2;
				else
				a1/=a2;
			}
			else if(c2=='+'||c2=='-'){
				if(c1=='+')
				r+=a1;
				else
				r-=a1;
				flag=0;
				a1=a2;c1=c2;
			}
			else{
				if(c1=='+')
				r+=a1;
				else
				r-=a1;
				break;
			}
		}
		
	}
	printf("%d",r);
	return 0;
}

