#include<stdio.h>
#include<string.h>
char s[10000],c[10000],c1[10000];
int n[10000],n1[10000];
int i,j,k,l,i1,j1,res;
int main()
{
	gets(s);
	for(i=0,l=0;s[i]!='=';i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			n[j]=s[i]-'0';
			while(s[i+1]>='0'&&s[i+1]<='9')
            {
            	n[j] = n[j]*10+(s[i+1]-'0');
            	i++;
			}
			j++;
		}
	    else if(s[i]=='+') c[l++] = s[i];
		else if(s[i]=='-') c[l++] = s[i];
		else if(s[i]=='*') c[l++] = s[i];
		else if(s[i]=='/') c[l++] = s[i];
    }
	for(i1=0,j1=0,i=0;i<j;i++)
	{
		n1[i1] = n[i];
		while(c[i]=='*'||c[i]=='/')
		{
			if(c[i]=='*')
			n1[i1] = n1[i1]*n[i+1];
			else n1[i1] = n1[i1]/n[i+1];
			i++;
		}
		if(c[i]=='+'||c[i]=='-') c1[j1++] = c[i];
		i1++;
	}
	for(i=0,res=n1[0];i<i1;i++)
	{
		if(c1[i]=='+') res+=n1[i+1];
		else if(c1[i]=='-') res-=n1[i+1];
	}
	printf("%d",res);
	return 0;
}



