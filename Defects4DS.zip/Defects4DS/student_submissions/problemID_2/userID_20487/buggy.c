#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	char b[500],bb[500];
	int c[500]={0},cc[500]={0};
	int i,i1=0,j=0,k=0;
	int ans;
	
	while(b[k-1]!='=')
	{
		scanf("%d %c",&c[j],&b[k]);
		j++;
		k++;
	}
	for(i=0;i<=k;i++)
	{
		cc[i1]=c[i];
		while(b[i]=='*'||b[i]=='/')
		{
			if(b[i]=='*')cc[i1]*=c[i+1];
			else cc[i1]/=c[i+1];
			i++;
		}
		if(b[i]=='+'||b[i]=='-')
		{
			bb[i1]=b[i];
			i1++;
		}
	}
	ans=cc[0];
	for(j=0;j<i1;j++)
	{
		if(bb[j]=='+')ans+=cc[j+1];
		else if(bb[j]=='-')ans-=cc[j+1];
	}
	printf("%d",ans);
	return 0;
}

