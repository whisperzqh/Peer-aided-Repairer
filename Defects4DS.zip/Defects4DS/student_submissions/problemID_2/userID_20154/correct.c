#include<stdio.h>
int shu()
{
    int a;
    scanf(" %d",&a);
    return a;
}
int fuhao()
{
    char b;
    scanf(" %c",&b);
    return b;
}
int jisuan(int a1, int a2, int a3, char b1,char b2)
{
	
if (b1=='=')
    printf("%d",a1);
if(b1!='=')
{   
	if(b1=='*')
	{   
		a1=a1*a2;
		b1=fuhao();
		a2=shu();
		jisuan(a1,a2,a3,b1,b2);
	}
	if(b1=='/')
	{
		a1=a1/a2;
		b1=fuhao();
		a2=shu();
		jisuan(a1,a2,a3,b1,b2);
	}
	if(b1=='+'||b1=='-')
	{
		b2=fuhao();
		if(b2=='*')
		{
		a3=shu();
		a2=a2*a3;
		jisuan(a1,a2,a3,b1,b2);
	    }
		else if(b2=='/')
		{
		a3=shu();
		a2=a2/a3;
		jisuan(a1,a2,a3,b1,b2);
	    }
	    else if(b2=='=')
	    {
	    	if (b1=='+')
	    	{
	    		a1=a1+a2;
	    		printf("%d",a1);
			}
			if (b1=='-')
			{
				a1=a1-a2;
				printf ("%d",a1); 
			}
		}
		else if(b1=='+')
		{
		a1=a1+a2;
		a2=shu();
		b1=b2;
		jisuan(a1,a2,a3,b1,b2);
	    }
		else if(b1=='-')
		{
		a1=a1-a2;
		a2=shu();
		b1=b2;
		jisuan(a1,a2,a3,b1,b2);
	   }
	}
}
}
main()
{
int a1,a2,a3,a4,a5;
scanf("%d",&a1);
char b1;
b1=fuhao();
a2=shu();
char b2,b3,b4,b5;

jisuan(a1,a2,a3,b1,b2);

}

