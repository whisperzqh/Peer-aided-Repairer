#include<stdio.h>
#include<string.h>
#include<ctype.h>
char s[10000],op[10000],b[10000];
int num[10000],a[10000];
int main()
{
int i,j=0,n,t=0,count=0,m=0,sum;
gets(s);
    for(i=0;s[i]!='=';i++)
    {
        if(isdigit(s[i]))
        {
            n=0;
            if(isdigit(s[i+1]))
            {
                for(n=0;s[i]>='0'&&s[i]<='9';i++)
                {
                n=10*n+(s[i]-'0');
                }
                num[j]=n;
                j++;
            }
            else
            {
             num[j]=s[i]-'0';
            j++;
            }
        }
        else if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/')
        {
        op[t]=s[i];
        t++;
        }
    }
    count=j-1;
    for(i=0;i<count;i++)
    {
        if(op[i]=='+'||op[i]=='-')
        {
        a[m]=num[i];
        b[m]=op[i];
        m++;
        }
        else
        {
            if(op[i]=='*')
            {
            num[i+1]=num[i]*num[i+1];
            }
            if(op[i]=='/')
            {
            num[i+1]=num[i]/num[i+1];
            }
        }
    }
    a[m]=num[count];
    sum=a[0];
    for(i=0;i<m;i++)
    {
    if(b[i]=='+') sum=sum+a[i+1];
    if(b[i]=='-') sum=sum-a[i+1];
    }
    printf("%d",sum);

}

