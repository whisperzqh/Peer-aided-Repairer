#include<stdio.h>
char a1,a2;
int b1,b2,b3;
int main() {

	scanf("%d",&b1);
	scanf("%c",&a1);
	while(a1==' '){
		scanf("%c",&a1);
	}
	if(a1=='='){
		printf("%d",b1);
		return 0;
		}
	scanf("%d",&b2);
	scanf("%c",&a2);
	while(a2!='='){
		while(a2==' '){
		scanf("%c",&a2);
	}	
		if(a2=='=')
		break;
		scanf("%d",&b3);
		if(a2=='*'&&(a1=='+'||a1=='-'))
		b2=b2*b3;
		else if(a2=='/'&&(a1=='+'||a1=='-')){
			b2=b2/b3;
		}
		
		else{
			if(a1=='*')
			b1=b1*b2;
			else if(a1=='/')
			b1=b1/b2;
			else if(a1=='+')
			b1=b1+b2;
			else 
			b1=b1-b2;
			
			b2=b3;
			a1=a2;
			
		}
		scanf("%c",&a2);
	}
	if(a1=='*')
	b1=b1*b2;
	else if(a1=='/')
	b1=b1/b2;
	else if(a1=='+')
	b1=b1+b2;
	else 
	b1=b1-b2;
	

	printf("%d",b1);
	
		}


