#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

#define _max(x,y) (x)>(y)?(x):(y)
#define _min(x,y) (x)<(y)?(x):(y)
#define _swap(x,y) x^=y,y^=x,x^=y

int calt(int a, int b, char c);
int rnum();
char rop();

int main()
{
	 int num, a[105];
	 char op, b[105];
	 scanf("%d",&a[0]);
	 b[0]=rop(); 
	 if(b[0]!='=')
	 a[1]=rnum();
	 while(b[0]!='=')
	 {
	 if(b[0]=='+'||b[0]=='-')
	 {
	 	op=rop();
	 	if(op=='+'||op=='-'||op=='=')
	 	{
	 		a[0]=calt(a[0],a[1],b[0]);
	 		b[0]=op; 
	 		if(op!='=')
			a[1]=rnum();
		}
		else if(op!='=')
		{
			num=rnum();
			a[1]=calt(a[1],num,op);
		 } 
		 else b[0]=op;
	}
	 else 
	 {
	  a[0]=calt(a[0],a[1],b[0]);
	  b[0]=rop();
	  if(b[0]!='=')
	  a[1]=rnum();
	 }
	 } 
	printf("%d\n", a[0]);

	return 0;
}


int calt(int a, int b, char c)
{
	int i;
	if(c=='+' ) i=a+b;
	if(c=='-' ) i=a-b;
	if(c=='*' ) i=a*b;
    if(c=='/' ) i=a/b;
    return i;
}   

int rnum(int a)
{
 int num;
 scanf(" %d",&num);
 return num;
}

char rop()
{
	char op; 
	scanf(" %c",&op);
    return op;
}
 

