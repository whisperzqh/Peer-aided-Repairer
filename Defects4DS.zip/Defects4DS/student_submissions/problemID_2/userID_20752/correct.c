#include<stdio.h>
#include<ctype.h>
#include<string.h>
int trans(char a)
{
    if(isdigit(a))//
    return a-'0';
    return a;
}
int anlys(int a,char b,int c)//
{
    if(b=='+')
        return a+c;
    if(b=='-')
        return a-c;
    if(b=='*')
        return a*c;
    if(b=='/')
        return a/c;
    return 0;
}




int main()
{
    char inpu[1025],temp[1025],p[1000];//
    int i,j=0,q[1000]={0},k=0,num[1000];
    gets(inpu);
        for(i=0,j=0;inpu[i]!='\0';i++)
                if(inpu[i]!=' ')
        {
            temp[j]=inpu[i];//
            j++;
        }
        temp[j]='\0';
    for(i=0;temp[i]!='\0';i++)//
        {
            num[i]=trans(temp[i]);
            //printf("%d  ",num[i]);//
        }
        //puts(temp);
    for(i=0,j=0,k=0;temp[i]!='=';i++)//
    {
        if((temp[i]=='+')||(temp[i]=='-')||(temp[i]=='*')||(temp[i]=='/'))
        {
            p[j]=temp[i];
            //printf("%c",p[j]);
            j++;
        }
        else
        {
            for(;(num[i+1]<=9)&&(num[i+1]>=0);i++)
                num[i+1]=10*num[i]+num[i+1];
            q[k]=num[i];
            //printf("%d",q[k]);
            k++;
        }
    }
    p[j]='=';
    p[j+1]='\0';
    //puts(p);
    //printf("%d\n",q[1]);//
    //printf("%d\n",num[2]);//
    for(i=0;p[i]!='\0';i++)//
    {

        if(p[i]=='*'||p[i]=='/')
        {
            q[i+1]=anlys(q[i],p[i],q[i+1]);
            //printf("%d",q[i+1]);
            q[i]=0;
            p[i]='+';
            if(p[i-1]=='-')
                p[i]='-';
        }
    }
    //printf("%c\n",p[0]);
    //for(i=0;p[i]!='\0';i++)
        //printf("%d ",q[i]);
    for(i=0;p[i]!='\0';i++)//
        q[i+1]=anlys(q[i],p[i],q[i+1]);
    //for(i=0;p[i]!='\0';i++)
        //printf("%d ",q[i]);
    printf("%d\n",q[i-1]);
    return 0;
}

//
//

