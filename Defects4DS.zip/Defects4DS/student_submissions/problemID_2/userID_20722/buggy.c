#include<stdio.h>

int main()
{
 char s[1026];
 int i,j;
 gets(s);
 for(i=0,j=0;s[i]!='\0';i++)
   if(s[i]!=' ')
		{
			s[j]=s[i];
   			j++;
		}
   s[j]='\0';
   int a[200]={0};
	int b[200]={0},g=0,c;
	char yunsuan[100],yunsuan2[100];
  	i=0;
  	j=0;
  for(i=0;s[i]!='\0';i++)
{
	  while((s[i]>='0')&&(s[i]<='9'))
	{
		a[j]=a[j]*10+s[i]-'0';
		i++;
	}
	yunsuan[j]=s[i];
	j++;
}
   	j-=1;
for(i=0;i<=j;i++)
  	{
  	 if((yunsuan[i]=='+')||(yunsuan[i]=='-'))
  	 {
  	 	yunsuan2[g]=yunsuan[i];
  	 	if(b[g]==0)
  	 	b[g]=a[i];
  	 	g++;
	   }
	
  	  if(yunsuan[i]=='*')
  			{
  		    	c=a[i+1];
  		    	a[i+1]=a[i]*c;
  		    	b[g]=a[i+1];
  		    }
	if(yunsuan[i]=='/')
  			{
  		    	c=a[i+1];
  		    	a[i+1]=a[i]/c;
  		    	b[g]=a[i+1];
  		    }
    }

    int res=0;
    res=b[0];
    for(i=0;i<g;i++)
  	{
  	 if(yunsuan2[i]=='-')
  		res-=b[i+1];
	 if(yunsuan2[i]=='+')
		res+=b[i+1];
    }
    printf("%d",res);
return 0;
}


