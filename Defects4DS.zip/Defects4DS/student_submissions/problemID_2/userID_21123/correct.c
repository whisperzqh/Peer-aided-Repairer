#include<stdio.h>
#include<string.h>
int f(int a,int b,char c);
char fuhao();
int shuzi();
  int main()
   {
   	int a[2],c;
	char fuhao1,fuhao2;
	a[0]=shuzi();
	fuhao1=fuhao();
	if(fuhao1!='=')
	{
		a[1]=shuzi();
	}
	while(fuhao1!='=')
   	{
   		
   		if(fuhao1=='/'||fuhao1=='*')
   		{
   		a[0]=f(a[0],a[1],fuhao1);
   		fuhao1=fuhao();
   		if(fuhao1!='=')
   		{
   			a[1]=shuzi();
		   }
		   }
   		
   		else
   		{
   		   fuhao2=fuhao();
			if(fuhao2=='='||fuhao2=='+'||fuhao2=='-')	
			{
				a[0]=f(a[0],a[1],fuhao1);
				fuhao1=fuhao2;
				if(fuhao1!='=')
				{
				a[1]=shuzi();
				}
			}
   			
   			else if(fuhao2=='*'||fuhao2=='/')
   			{
   			    c=shuzi();
   				a[1]=f(a[1],c,fuhao2);
   				
			   }
			   else
			   
   			fuhao1=fuhao2;
		   }
	   }
   	 printf("%d",a[0]);
   	
   	return 0;
   }
      int f(int a,int b,char c)
       {
       	int sum=0;
       	if(c=='+')
       	{sum=a+b;
		   }
		   if(c=='-')
       	{sum=a-b;
		   }
		   if(c=='/')
       	{sum=a/b;
		   }
		   if(c=='*')
       	{sum=a*b;
		   }
		   return (sum);
	   }
     
     char fuhao()
        {
        	char fuhao;
        	while(scanf("%c",&fuhao),fuhao==' '){
			}
        	return (fuhao);
		 } 
     
     int shuzi()
          {
          	int shuzi;
          	scanf("%d",&shuzi);
          	return (shuzi);
          	
		  }
     
     
     
     
     
     
     
     
     

