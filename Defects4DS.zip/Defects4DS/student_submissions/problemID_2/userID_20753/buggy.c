#include<stdio.h>
char a[100],b[100];
int n[100],m[100];
int main()
{
	gets(a);
	int i=0,j=0,k=0,l=0,p=0,flag=0,sum=0;
	for(i=0,j=0,k=0;a[i]!='=';i++)
	{
		if(a[i]==32)
		continue;
		else if(a[i]<='9'&&a[i]>='0')
		{
			if(i>0&&a[i-1]<='9'&&a[i-1]>='0') 
			n[j-1]=n[j-1]*10+a[i]-'0';
			else
			{
				n[j]=a[i]-'0';
				j++;
			}
		}
		else
		{
			b[k]=a[i];k++;
		 } 
	}
	for(i=0,j=0;i<k;i++){
		if(b[i]=='-')
		n[i+1]=-n[i];
	}
	for(i=0,j=0;i<k;i++)
	{
		if(b[i]=='*'||b[i]=='/'){
		     for(i=i;b[i]=='*'||b[i]=='/';i++)
		     {
			    if(b[i]=='*')
			    n[i+1]=n[i]*n[i+1];
			    else if(b[i]=='/')
		  	    n[i+1]=n[i]/n[i+1];
		    }
		    m[j]=n[i];j++;flag=1; 
	    }
	    else if(b[i]=='+'||b[i]=='-'){
	    	m[j]=n[i];j++;flag=1;
		}
	}
	if(b[k-1]=='+'||b[k-1]=='-'){
	m[j]=n[k];j++;	
	}
	if(flag==0)
	printf("%d",n[0]);
	else
	{
		for(i=0;i<j;i++)
		sum+=m[i];
		printf("%d",sum);
	}
	return 0;
}

