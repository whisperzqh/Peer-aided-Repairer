#include <stdio.h>
#include <string.h>
char ch[10000],si[10000],ch_1[10000];
int num[10000],ans[100000],si_1[100000];
int main(){
	int i,j=0,k=0,q=0,t,T=0,i_1=0,i_2=0,i_3=0,i_4=0,bt,end,le;
	gets(ch_1);
	le=strlen(ch_1);
	for(i=0;i<le;i++){
		if(ch_1[i]!=' '){
			ch[q]=ch_1[i];
			q++;
		}
	}
	for(i=0;ch[i]!='=';i++){
		if(ch[i]==' ') 
			le--;
		if(ch[i]<='9'&&ch[i]>='0'){
			t=ch[i]-'0';
			T=10*T+t;
			while(ch[i+1]<='9'&&ch[i+1]>='0'&&i+1<le){
				t=ch[i+1]-'0';
				T=10*T+t;
				i++;
			}
			num[j]=T;
			T=0;
			j++;
		}
		else{
			si[k]=ch[i];
			k++;
		}
	}
	for(i_2=0;i_2<=k;i_2++){
		if(i_1<=j){
		bt=num[i_1];
		while(si[i_2]!='+'&&si[i_2]!='-'&&i_2<=k)
		{
			if(si[i_2]=='*'){
				bt=bt*num[i_1+1];
			}
			if(si[i_2]=='/'){
				if(i_1+1>j)
					break;
				else	
					bt=bt/num[i_1+1];
			}
			i_1++;
			i_2++;
		}
		if(si[i_2]=='+')
			si_1[i_4]=1;
		if(si[i_2]=='-')
			si_1[i_4]=0;
		ans[i_3]=bt;
		i_1++;
		i_3++;
		i_4++;
	}
	}
	end=ans[0];
	for(i=0;i<i_4;i++){
		if(si_1[i]==1)
		end=end+ans[i+1];
		else
		end=end-ans[i+1];
	}
	printf("%d\n",end);
	return 0;
	
} 

