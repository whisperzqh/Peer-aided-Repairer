#include<stdio.h>
int s[1000];
int f[1000];
void qianyi(char y[],int i)
{
	for(;y[i]!='=';i++)
	y[i]=y[i+1];
	y[i]='\0';
}
int houdu(char y[],int i)
{
	int sum=0;
	for(;(y[i]>='0')&&y[i]<='9';i++)
	{
		sum=sum*10+y[i]-'0';
	}
	return sum;
}
int main()
{
	char y[10000];
	gets(y);
	int i,j=1,k=0;
	for(i=0;y[i]!='=';i++)
	{
		if(y[i]==' ')
		qianyi(y,i);
	 } 
	if(y[0]=='-')
	s[0]=houdu(y,1);
	else
	s[0]=houdu(y,0);
	for(i=1;y[i]!='=';i++)
	{
		if(!((y[i]<='9')&&(y[i]>='0')))
		{
			s[j]=houdu(y,i+1);
			if(y[i]=='+')
			f[k]=1;
			if(y[i]=='-')
			f[k]=2;
			if(y[i]=='*')
			f[k]=3;
			if(y[i]=='/')
			f[k]=4;
			j++;
			k++;
		}
	}
	for(i=0;i<1000;i++)
	{
		if(f[i]>2)
		{
		if(f[i]==3)
		{
			s[i]=s[i]*s[i+1];
		}
		if(f[i]==4)
		s[i]=s[i]/s[i+1];
		for(j=i+1;j<999;j++)
			{
				s[j]=s[j+1];
			}
		for(j=i;j<999;j++)
		{
			f[j]=f[j+1];
		}
		i--;
	}
	}
	for(i=0;i<1000;i++)
	{
		if(f[i]>0)
		{
		if(f[i]==1)
		{
			s[i]=s[i]+s[i+1];
		}
		if(f[i]==2)
		s[i]=s[i]-s[i+1];
		for(j=i+1;j<999;j++)
			{
				s[j]=s[j+1];
			}
		for(j=i;j<999;j++)
		{
			f[j]=f[j+1];
		}
		i--;
	}
	}
	printf("%d",s[0]);
	return 0;
 } 

