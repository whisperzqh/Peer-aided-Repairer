#include<stdio.h>
int main()
{
	int num1,num2,n=0,i=0;
	char p1='+',p2,p3;
	while(p1=='*'||p1=='/'||p1=='+'||p1=='-')
	{
		scanf("%d %c",&num1,&p2);
		while(p2=='*'||p2=='/')
		{
			scanf("%d %c",&num2,&p3);
		    if(p2=='*')
		    {
			  num1*=num2;
			  p2=p3;
		    }   
		    else if(p2=='/')
		    {
			  num1/=num2;
			  p2=p3;
    	    }
        }
		if(p1=='+')
		{
			n+=num1;
			p1=p2;
		}
		 else if(p1=='-')
		{
			n-=num1;
			p1=p2;
		}
	}
	printf("%d",n);
	return 0;
}

