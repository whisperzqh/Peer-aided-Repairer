#include <stdio.h>

int main()

{
    int a,b,s=0;
    char x,y,z='+';

    while(z!='=')
    {
        scanf("%d%c",&a,&x);

        while(x=='*'||x=='/')
        {
            scanf("%d%c",&b,&y);

            if(x=='*')
                a=a*b;
            if(x=='/')
                a=a/b;
            x=y;
        }

        if(z=='+')
            s=s+a;
        if(z=='-')
            s=s-a;
        z=x;
    }

    printf("%d",s);
    return 0;
}

