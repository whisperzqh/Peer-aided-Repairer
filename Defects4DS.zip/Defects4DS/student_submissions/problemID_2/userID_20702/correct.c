#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
int jieguo(char *p,int a);
int main()
{
 char s[500];
 scanf("%[^\n]",s);
 int n = strlen(s)-1;
 printf("%d\n",jieguo(s,n)); 
 return 0; 
}
int jieguo(char* s,int n) {
    int shujv[n], top = 0;
    char fuhao = '+';
    int num = 0;
    for (int i = 0; i< n; i++) {
        if (isdigit(s[i])) {
            num = num *10 +(s[i] - '0');
        }
        if (s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'||i==n-1) {
            switch (fuhao) {
            	case '*':
                    shujv[top-1] *= num;
                    break;
                case '/':
                    shujv[top-1] /= num;
					break;
                case '+':
                    shujv[top++] = num;
                    break;
                case '-':
                    shujv[top++] = -num;              
            }
            fuhao = s[i];
            num = 0;
        }
    }
    int jg = 0;
    for(int i= 0; i<top; i++) {
        jg +=shujv [i];
    }
    return jg;
}

