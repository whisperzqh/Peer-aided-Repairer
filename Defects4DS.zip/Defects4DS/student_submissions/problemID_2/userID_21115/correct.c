#include<stdio.h>
#include<string.h>
#include<ctype.h> 
char str1[100000],a[100000],b[100000];
int r[100000];
int main()
{
	
	gets(str1);
	int j=0,m=0,n=0;
	for(int i=0;i<strlen(str1);i++){
		if(isspace(str1[i])) continue;
		a[j++]=str1[i];
	}
	a[j]='\0'; //
	
	for(int i=0;i<strlen(a);i++){
		if(a[i]>='0'&&a[i]<='9')
		  r[m]=r[m]*10+a[i]-'0';
		if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/') //
		{
			
			b[n]=a[i];
			m++; n++;
		}
	}
	
	for(int i=0;i<=n;i++){
		if(b[i]=='*'){
			r[i+1]=r[i]*r[i+1];
			r[i]=0;
			if(b[i-1]=='-') b[i]='-';
			else b[i]='+';
		}                     //
		else if(b[i]=='/' ){
			r[i+1]=r[i]/r[i+1];
			r[i]=0;
			if(b[i-1]=='-') b[i]='-';
			else b[i]='+';
		}
	}
	int ans=r[0];
	for(int i=0;i<=n;i++){
		if(b[i]=='+'){           //
			ans += r[i+1];
		}
		else if(b[i]=='-'){
			ans -= r[i+1];
		}
	}
	
	printf("%d",ans); 
	return 0;
	
}

