#include <stdio.h>
#include <string.h>
#include <math.h>
char S[10000];
char s[10000];
int con1[10000];
char con2[10000];
int cont1[10000];
char cont2[10000];
int main()
{
	gets(S);
	int i,j=0;
	int m=0,n=0;
	for(i=0;i<strlen(S);i++)
	if(S[i]!=' '&&S[i]!='=') s[j++]=S[i];
	j=0;
	for(i=0;i<strlen(s);i++)
	{
		int temp=0;
		if(s[i]>='0'&&s[i]<='9')
		{	
			temp=s[i]-'0';
			while(s[i+1]>='0'&&s[i+1]<='9')
			{
			i++;
			temp=temp*10+s[i]-'0';
			}
			con1[m++]=temp;
		}
		else con2[n++]=s[i];		
	}
	cont1[0]=con1[0];
	int p=0,q=0;
	for(i=0;i<n;i++)
	{
		if(con2[i]=='*')
		{
			cont1[p]*=con1[i+1]; 
		}
		else if(con2[i]=='/')
		{
			cont1[p]/=con1[i+1];
		}
		else 
		{
			
			cont1[++p]=con1[i+1];
			cont2[q++]=con2[i];
		}
	}
	
	int ans=cont1[0];
	for(i=1;i<=strlen(cont2);i++)
	{
		if(cont2[i-1]=='+') ans+=cont1[i];
		if(cont2[i-1]=='-') ans-=cont1[i];
	}
	printf("%d",ans);
	return 0;
}

