#include<math.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define ll long long
int i=0,j=0,k=0;
char s[10010],ss[10010],sign[10010],l=-1;
int pos=0,num[10010],a=0,ans=0;
int* p=num;
int main(){
	gets(ss);
	for(i=0;i<strlen(ss);++i){
		if(ss[i]==' ')
			continue;
		s[pos++]=ss[i];
	}
	pos=0;
	for(i=0;i<strlen(s);++i){
		int cmp=s[i]-'0';
		if(cmp>9||cmp<0){
			num[++pos]=a;
			sign[pos]=s[i];
			a=0;
			continue;
		}
		a*=10;
		a+=cmp;
	}
	for(i=1;i<pos;++i){
		if(sign[i]=='+'||sign[i]=='-'){
			p=num+i+1;
			continue;
		}
//		printf("%d\n",p-num);
		if(sign[i]=='/'){
			*p/=num[i+1];
		}
		if(sign[i]=='*'){
			*p*=num[i+1];
		}
	}
//	for(i=1;i<=pos;++i)
//		printf("%d:%d %c\n",i,num[i],sign[i]);
	ans+=num[1];
	for(i=1;i<=pos;++i){
		if(sign[i]=='+')
			ans+=num[i+1];
		if(sign[i]=='-')
			ans-=num[i+1];
//		printf("%d\n",ans);
	}
	printf("%d",ans);
	return 0; 
}

