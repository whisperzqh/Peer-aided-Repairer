#include <stdio.h>
#include<string.h>
int yun(int x,char y,int z){
	if(y=='+'){
		return x+z;
	}else if(y=='-'){
		return x-z;
	}else if(y=='*'){
		return x*z;
	}else{
		return x/z;
	}
}

int main(){
	char a[200],b[100];
	int c[100],d[100];
	int i=0,j=0,k=0,ji=0;
	for(i=0;i<100;i++){
		c[i]=0;
		d[i]=0;
	}
	for(i=0;i<100;i++) b[i]='\0';
	gets(a);
	for(i=0;a[i]!='=';i++){
		if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'){
			b[j++]=a[i];
			k++;
			ji++;
		}else if(a[i]>='0'&&a[i]<='9'){
			c[k]=c[k]*10+a[i]-'0';
		}
	}
	for(i=0,j=0,k=0;i<ji;i++){  // 
		if(b[i]=='+'||b[i]=='-'){
			d[k++]=c[j++];
		}
		else if(b[i]=='*'||b[i]=='/'){
			c[j+1]=yun(c[j],b[i],c[j+1]);
			j++;
			if(i==ji-1) d[k]=c[j];
		}
	}
	for(i=0,j=0;i<ji;i++){
		if(b[i]=='+'||b[i]=='-'){
			d[0]=yun(d[0],b[i],d[j+1]);
			j++;
		}
	}
	if(ji==0) printf("%d",c[0]);
	else printf("%d",d[0]);
	return 0;
} 

