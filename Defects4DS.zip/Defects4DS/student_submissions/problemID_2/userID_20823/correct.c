#include<stdio.h>
#include<string.h>
int main()
{
	char  a[2000], b[2000], f1[1000], f2[1000];
	int s1[1000], s2[1000];
	int i, j, m, n, k, c, d;
	fgets(a, 1000, stdin);
	for(i = 0,j = 0;i < strlen(a); i ++){
		if(a[i] != ' '){
		b[j] = a[i];	
		j ++;
		}
		
	}
	for(i = 0,j = 0,c = 0,d = 0;i < strlen(b);i ++){
		if(b[i]=='+'||b[i]=='-'||b[i]=='*'||b[i]=='/'||b[i]=='='){
			f1[j] = b[i];
			j++;
		}
		if(b[i] >= '0' && b[i] <= '9'){
			for(m = 1;m <= 10;m ++){
				if(b[i + m] >= '0' && b[i + m] <= '9')
					continue;
				else
					break;
				}
			for(n = m - 1,k = 1;n >= 0;n --){
				d = (b[i + n]-'0')* k + d;
				k = k * 10;
			}
			s1[c] = d;
			d=0;
			c ++;			
			
		i = i + m - 1;
	 	}
	}
	for(i = 0,j = 0; i <= strlen(f1); i ++){
		if(f1[i] == '+' || f1[i] == '-' || f1[i] == '='){
			f2[j] = f1[i];
			s2[j] = s1[i];
			j ++;
		}
		if(f1[i] == '*'){
			s1[i + 1] = s1[i] * s1[i + 1];
		}
		if(f1[i] == '/'){
		 	s1[i + 1] = s1[i] / s1[i + 1];
		}
	}
	int result;
	result = s2[0];
	for(i = 0;i <= strlen(f2); i ++){
		if(f2[i] == '+'){
			result = result + s2[i + 1];
		}
		if(f2[i] == '-'){
			result = result - s2[i + 1];
		}
	}
	printf("%d",result);
return 0;
}

