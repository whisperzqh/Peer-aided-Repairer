#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define ULL unsigned long long

#define MaxUnsignedInt 4294967295
#define MaxInt 2147483647
#define MinInt -2147483648
#define MaxUnsignedLong 4294967295
#define MaxLong 2147483647
#define MinLong -2147483648
#define MaxLongLong 9223372036854775807
#define MinLongLong -9223372036854775808
#define MaxUnsignedLongLong 18446744073709551615
#define PI 3.1415926
#define eps 1e-6

#define _max(x,y) (x)>(y)?(x):(y)
#define _min(x,y) (x)<(y)?(x):(y)
#define _swap(x,y) x^=y,y^=x,x^=y
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define ULL unsigned long long

#define MaxUnsignedInt 4294967295
#define MaxInt 2147483647
#define MinInt -2147483648
#define MaxUnsignedLong 4294967295
#define MaxLong 2147483647
#define MinLong -2147483648
#define MaxLongLong 9223372036854775807
#define MinLongLong -9223372036854775808
#define MaxUnsignedLongLong 18446744073709551615
#define PI 3.1415926
#define eps 1e-6

#define _max(x,y) (x)>(y)?(x):(y)
#define _min(x,y) (x)<(y)?(x):(y)
#define _swap(x,y) x^=y,y^=x,x^=y

int main()
{
    int i,j,k;
    int num[10000],res[10000];
    char s[10000],sign[10000];
    memset(num,0,sizeof(num));    
    memset(res,0,sizeof(res)); 
	scanf("%s",s);   
//    gets(s);
    
    for( i=0,j=0;s[i]!='\0';i++ ) //
    {
    	if( s[i]!=' ' )
    	{
    		s[j++]=s[i];
		}
	}
	s[j]='\0';
//	printf("%s",s);
	
	for( i=0,j=0;s[i]!='\0';i++ )     //
	{
		if( isdigit(s[i]) )
		{
			num[j]=s[i]-'0'+num[j]*10;
		}
		else
		{
			sign[j++]=s[i];
		}
	}
	sign[j]='\0';
//	printf("%s",sign);
//	for( i=0;i<j;i++ ) printf("%d ",num[i]);
//	printf("\n%d",num[1]);
//	printf("\n");
//	for( i=0;sign[i]!='\0';i++ ) printf("%c ",sign[i]); 
	
	res[0]=num[0];
//	cur=num[0];
	for( j=0,k=0;sign[j]!='\0';j++ )    //
	{
		if( sign[j]=='/' )
		{
			res[k]/=num[j+1];
//			res[k]=num[j];
			sign[j]=" ";
		}
		else if( sign[j]=='*' )
		{
			res[k]*=num[j+1];
//			res[k]=num[j];
			sign[j]=" ";
		}
		else if( sign[j]=='+' || sign[j]=='-' )
		{
			res[++k]=num[j+1];
		}
	}
//	printf("\n");
//	for( i=0;i<k;i++ ) printf("%d %d\n",i,res[i]);
	
	for( i=0,j=0,k=0;sign[j]!='=';j++ )
	{
		if( sign[j]=='+' )
		{
			res[0]+=res[k+1];
			k++;
		}
		else if( sign[j]=='-' )
		{
			res[0]-=res[k+1];
			k++;
		}
	}
	
	printf("%d",res[0]);
	
	return 0;
}





























