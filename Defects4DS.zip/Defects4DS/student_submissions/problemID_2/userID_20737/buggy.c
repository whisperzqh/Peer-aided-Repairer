#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define _fl float
#define _db double
#define _ll long long
#define _udb unsigned double
#define _ull unsigned long long

#define _fr(i, a, b) for(i = a; i <= b; i++)
#define _fr2(i, a, b) for(i = a; i >= b; i--)

#define MaxUnsignedInt 4294967295
#define MaxInt 2147483647
#define MinInt -2147483648
#define MaxUnsignedLong 4294967295
#define MaxLong 2147483647
#define MinLong -2147483648
#define MaxLongLong 9223372036854775807
#define MinLongLong -9223372036854775808
#define MaxUnsignedLongLong 18446744073709551615
#define PI 3.1415926
#define eps 1e-6
int jisuan(int,char,int);
int main()
{char c;
int downshu=0,upshu=1,num=0;
char downchar='+',upchar='*';
while(downchar!='='){
	c=getchar();
	if(c==' ')continue;
	if(isdigit(c)){
		num=10*num+c-'0';
		continue;
		
	}
	if(c=='*'||c=='/'){
		upshu=jisuan(upshu,upchar,num);
		upchar=c;
	}
	if(c=='+'||c=='-'||c=='=')
	{num=jisuan(upshu,upchar,num);
	downshu=jisuan(downshu,downchar,num);
	downchar=c;
	upshu=1;
	upchar='*';
	}
	num=0;
}
printf("%d",num);
return 0;
}
int jisuan(int a1,char sign,int a2){
	switch(sign){
		case '+':
			return a1+a2;
		case '-':
			return a1-a2;
		case '*':
			return a1*a2;
		case '/':
			return a1/a2;
		default:
			return -1;
	}
}

