#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#define LL long long
#define epd 1e-8
#define Pi 3.1415926
#define lluborder 18446744073709551615
/*inline int read(){
 int x=0,f=1;char ch = getchar();
 while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
 while(ch>='0'&&ch<='9'){
  printf("x:%d ch:%c\n",x,ch);
  x=(x<<3)+(x<<1)+ch-'0';
  ch=getchar();
  
 }
 return x*f;
}*/

int main()
{
	char s[80];
     
        int i,j,sum=0;
        gets(s);
        for(i=j=0;s[i]!='\0';i++)
        {
            if(s[i]!=' ')
            	s[j++]=s[i];
        }
        s[j]='\0';   //
    puts(s);
    
    int len,flag=0;
    len=strlen(s);
    int x=0,f=1,g=1,temp=1;
    for(i=0;s[i]!='=';i++){
    	if(s[i]>='0'&&s[i]<='9'){
    		x=0;
		    while(s[i]>='0'&&s[i]<='9'){
	  			//printf("x:%d s[i]:%c\n",x,s[i]);
	  			x=(x<<3)+(x<<1)+s[i]-'0'; 
	  			i++;
			}
			i--;
			if(flag==1){
				temp/=x;
				flag=0;
				g=1;
			}
			else{
			temp*=x;
			g=1;
			}
			//printf("%d,%d\n",x,temp);
		}//
    	 if(s[i]<'0'||s[i]>'9'){
			if (s[i]=='+'){
			sum+=temp*f;
			temp=1;
			f=1;
			}
			
			else if(s[i]=='-'){
			sum+=temp*f;
			temp=1;
			f=-1;
			}
			
			else if(s[i]=='*'){
			g=temp;	
			}
			
			else if(s[i]=='/'){
			g=temp;	
			flag=1;
			}
			//printf("%c\n",s[i]);   //
		}
	}
	sum+=(temp*f);
	printf("%d\n",sum);
    return 0;
}


