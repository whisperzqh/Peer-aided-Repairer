#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<ctype.h>
int main()
{
	char s1[105],s2[105],fu[105],jia[105];
	int a[105]={0},b[105]={0};
	gets(s1);
	int i;
	int j=0,m=0,n=0,q=0,s=0;
	int len;
	for(i=0;i<strlen(s1);i++)
	{
		if(s1[i]!=' ') s2[j++]=s1[i];
	}
	for(j=0;j<strlen(s2);j++)
	{
		if(!(s2[j]>='0'&&s2[j]<='9')) fu[m++]=s2[j];
		else
		{ 
		for(i=j;s2[i]>='0'&&s2[i]<='9';i++) 
		{
		a[q] = a[q]*10+s2[i]-'0';
		}
		q++;
		i--;
		}
	}
	for(j=0;j<strlen(fu);j++)
	{
		if(fu[j]=='*') 
		{
		a[j+1]=a[j]*a[j+1];
		a[j]=-1;
		}
		else if(fu[j]=='/')
		{
		a[j+1]=a[j]/a[j+1];
		a[j]=-1;
		}
	}
	for(j=0;j<strlen(fu);j++)
	if(a[j]!=-1) b[s++]=a[j];
	for(j=0;j<strlen(fu);j++)
	{
		if(fu[j]=='+'||fu[j]=='-') jia[n++]=fu[j];
	}
	int sum=b[0];
	for(i=0;i<strlen(jia);i++)
	{
		if(jia[i]=='+') sum+=b[1+i];
		else sum-=b[i+1];
	}
	printf("%d",sum);
}

