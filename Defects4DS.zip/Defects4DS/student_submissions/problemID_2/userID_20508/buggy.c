#include<stdio.h>
#include<string.h>
#include<ctype.h>
#define N 1024 
char s0[N],s[N];
char op[512],q=0;
int digit[512],p=0;
int level,top,result;

void deletes(char s0[],char s[])
{
	int i,j,len=strlen(s0);
	for(i=0,j=0;i<len;i++)
	    if(s0[i]!=' ')
	        s[j++]=s0[i];
	s[j]='\0';
}

int isoperator(char c)
{
	if(c=='+'||c=='-'||c=='*'||c=='/')
	    return 1;
	return 0;
}

int getrank(char c)
{
	if(c=='+'||c=='-')
	    return 1;
	if(c=='*'||c=='/')
	    return 2;
}

int calculate(char c,int a,int b)
{
	int r;
	switch(c)
	{
		case '+':r=b+a;break;
		case '-':r=b-a;break;
		case '*':r=b*a;break;
		case '/':r=b/a;break;
	}
	return r;
}

int main()
{
	gets(s0);
	deletes(s0,s);
	int i,len=strlen(s);
	for(i=0;i<len-1;i++)
	{
		if(isdigit(s[i]))
		{
			if(p>0&&isdigit(s[i-1]))
			{
				p--;
				digit[p]=10*digit[p]+s[i]-'0';
				p++;
			}
			else
			{
				digit[p]=s[i]-'0';
				p++;
			}
		}
		else if(isoperator(s[i]))
		{
			if(q==0)
			{
				op[q]=s[i];
				q++;
			}
			else
			{
				level=getrank(s[i]); 
				top=getrank(op[q-1]);
				if(level>top)
				{
					op[q]=s[i];
					q++;
				}
				else 
				{
					while(level<=top)
					{
						result=calculate(op[q-1],digit[p-1],digit[p-2]);
						digit[p-2]=result;
						p--;
						q--;
						op[q]='\0';
						if(q>0)
						    top=getrank(op[q-1]);
						else
						    break;
					}
					op[q]=s[i];
					q++;
				}
			}
		}
	}
	while(q>=0)
	{
		result=calculate(op[q-1],digit[p-1],digit[p-2]);
		p--;
		q--;
	}
	printf("%d\n",result);
} 

