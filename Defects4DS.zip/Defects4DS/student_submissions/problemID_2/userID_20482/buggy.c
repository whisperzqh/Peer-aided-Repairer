#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
#include<time.h>
#include<assert.h>
#define LL	long long
#define ULL unsigned long long
#define arrN(x) (sizeof(x)/sizeof(x[0]))
#define eps	1e-10
#define inf 9223372036854775807L
#define X   0x7fffffff
#define	max(a,b)	( (a) > (b) ) ? (a) : (b)
#define	min(a,b)	( (a) < (b) ) ? (a) : (b)
char s[500],t[500],o[500];
int n[500];
int r,l,i,j,k,x,flag,cntN,cntO,temp;
char c;	
char* p;
void ridSpc(int r){
	while(i<r){
		if(s[i]!=' '){
			t[j]=s[i];
			j++;
		}
		i++;
	}
}
void getNumOp(int l){
	int pos=0,dgt;
	for(i=0,k=0,x=0;i<l;i++){
		if(isdigit(t[i])){
			t[i]-='0';
		}
		else{
			for(j=i-1,dgt=1;j>=pos;j--,dgt=i-j){
				temp=t[j];
				while(--dgt){
					temp*=10;
				}
				n[k]+=temp;
			}
			k++;
			pos=i+1;
			o[x++]=t[i];
		}
	}
	cntN=k;
	cntO=x;
	
}
int main()
{
//	freopen("in.txt","r",stdin);
	gets(s);
	r=strlen(s);
	
	ridSpc(r);
	l=strlen(t);
	getNumOp(l);
	
/*	for(i=0;i<cntN;i++){
	printf("%d%c",n[i],o[i]);	
	}//*/
	
	//
	if(cntN==1){
		printf("%d",n[0]);
		return 0;
	}

	//
	for(i=0;o[i]!='=';i++){
		if(o[i]=='*'){
			n[i+1]*=n[i];
		}
		else if(o[i]=='/'){
			n[i+1]=n[i]/n[i+1];
		}
	}
	//
	flag=0;
	for(i=0;;i++){
		if(o[i]=='+'){
			i++;
			while(o[i]=='*'||o[i]=='/')	i++;
			n[i]+=n[flag];
			flag=i;
			i--;
		}
		if(o[i]=='-'){
			i++;
			while(o[i]=='*'||o[i]=='/')	i++;
			n[i]=n[flag]-n[i];
			flag=i;
			i--;
		}
		if(o[i]=='='){
			flag=i;	break;
		}
	}
	printf("%d",n[flag]);
	return 0;
}




