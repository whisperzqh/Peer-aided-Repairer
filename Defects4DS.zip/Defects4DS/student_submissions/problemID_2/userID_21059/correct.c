#include<stdio.h>

int main()
{
	char s[1000],c[1000];int i,t,sum,a[1000]={0};
	gets(s);
	for(i=0,t=0;s[i]!='\0';i++)
	{
		if(s[i]<='9'&&s[i]>='0') 
		{
			a[t]=a[t]+s[i]-'0';if(s[i+1]<='9'&&s[i+1]>='0') a[t]*=10;
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='='||s[i]=='*'||s[i]=='/') 
		{
			c[t]=s[i];t++;
		}
	}
	for(i=0;i<t;i++)
	{
		if(c[i]=='-') a[i+1]=-a[i+1];
	}
	for(i=0;i<t;i++)
	{
		if(c[i]=='*')
		{
			a[i+1]=a[i]*a[i+1];a[i]=0;
		}
		if(c[i]=='/')
		{
			a[i+1]=a[i]/a[i+1];a[i]=0;
		}
	}
	for(i=0;i<t;i++)
	{
		sum+=a[i];
	}
	printf("%d",sum);
}

