#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<time.h>
#define eps 1e-8
int main()
{
	int l,i,j,m,n,flag,p,q,r,l2,l3,result;
	char str[2000],str2[2000],op[2000],op2[2000];
    int num[1000],num2[1000];
	gets(str);
	l=strlen(str);
	for(i=0,j=0;i<l;i++){
		if(str[i]!=' '){ 
		str2[j]=str[i];
		j++;}
	}
	l=strlen(str2);
	for(i=0,m=0,n=0;i<l;i++){
		if(str2[i]=='+'||str2[i]=='-'||str2[i]=='*'||str2[i]=='/'||str2[i]=='='){
			op[m]=str2[i];
			m++;
		}
		if(str2[i]<=57&&str2[i]>=48) {
			for(flag=1;flag<20;flag++){
				if(str2[i+flag]<=57&&str2[i+flag]>=48)
					continue;
				q=0,r=1;
				for(p=flag;p>0;p--){
					q=q+(str2[i+p-1]-'0')*r;
					r=r*10;
				}
				num[n]=q;
				n++;
				i=i+flag-1;
				break;
				if(str2[i+flag]>57||str2[i+flag]<48)
					break;
			}
		}
	}
	l2=strlen(op);
	for(m=0,n=0;m<=l2;m++){
		if(op[m]=='*')
		num[m+1]=num[m]*num[m+1];
		if(op[m]=='/')
		num[m+1]=num[m]/num[m+1];
		if(op[m]=='+'||op[m]=='-'||op[m]=='='){
			num2[n]=num[m];
			op2[n]=op[m];
			n++;
		}
	}
	l3=strlen(op2);
	result=num2[0];
	for(m=0;m<l3;m++){
		if(op2[m]=='+')
		result+=num2[m+1];
		if(op2[m]=='-')
		result-=num2[m+1];
	}
	printf("%d",result);
	return 0;
}


