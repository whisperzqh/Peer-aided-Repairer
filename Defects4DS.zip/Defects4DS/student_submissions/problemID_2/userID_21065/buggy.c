#include <stdio.h>
#include <ctype.h>
#include <string.h>

#define N 1000

char s[N],p[N],q[N];
long long num[N]={0},pm[N]={0},m=0,n=0;
char ch[N]={0},cc[N]={0};

long long calculate(char ch[],long long num[]);
int tonum(char ch);

int main()
{
	char ch[5];
	int flag,i,j;
	int l=0,r=0;
	int num_pm=0,num_cc=0;
	int k=0,wei=0,di=1;
	long long result;
	gets(s);
	
	for(i=0,j=0;i<strlen(s);i++)
	    if(s[i]!=' ')
	       p[j++]=s[i];
	p[j]='\0';
	for(i=0;i<strlen(p);i++)
	{
		wei=0,di=1;
		while(isdigit(s[i]))
			i++;
		r=i-1;    wei=r-l;
		for(j=wei;j>=0;j--)
	    {
	     	num[m] += tonum(s[l+j])*di;
	    	di *= 10;
	    }
		if(s[i]!='=')
		{
			m++;    l=i+1;
		    ch[n]=s[i];
		    n++;
		} 
		else
			result=calculate(ch,num);
	} 
	printf("%lld",result);
	return  0;      
}

int tonum(char ch)
{
	switch(ch)
	{
		case '9':return 9;
		case '8':return 8;	
		case '7':return 7;
		case '6':return 6;
		case '5':return 5;
		case '4':return 4;
		case '3':return 3;
		case '2':return 2;
		case '1':return 1;
		case '0':return 0;
	}
}

long long calculate(char ch[],long long num[])
{
	int i=0,j=0;
	int p=0,q=0;
    for(i=0;i<=n;)
    {
    	if(ch[i]=='+'||ch[i]=='-')
    	{
    		pm[p++]=num[i];
    		cc[q++]=ch[i];
    		i++;
		}
    	else if(ch[i]=='*'||ch[i]=='/')
    	{
    		while(ch[i]=='/'||ch[i]=='*')
        	{
    		    if(ch[i]=='/')
    		    {
    		    	num[i+1]=num[i]/num[i+1];
    		    	i++;
				}
				else
    		    {
    		    	num[i+1]=num[i]*num[i+1];
    		    	i++;
				}
	    	}
		}
		else
		    break;
	}
	pm[p]=num[i];
	for(i=0;i<q;i++)
	{
		if(cc[i]=='+')
		   pm[i+1]=pm[i]+pm[i+1];
		else
		   pm[i+1]=pm[i]-pm[i+1];
	}
	return pm[i];	
}

