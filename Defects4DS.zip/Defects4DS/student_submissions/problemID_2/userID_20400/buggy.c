#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
int main()
   {
    int count1=0,count2=0,a[200]={0},ls,i,j,k=1,l=1,ans;
	char s[200],b[200];
	gets(s);
	ls=strlen(s);
	for(i=j=0;i<ls;i++)
	if(s[i]!=' ') s[j++]=s[i];
	for(i=0;i<j;i++)
	{
		if(!isdigit(s[i]))
		{
			b[l]=s[i];
			l++;
			if(s[i]=='+'||s[i]=='-')
			count1++;
			if(s[i]=='*'||s[i]=='/')
			count2++;
		}
		if(isdigit(s[i]))
		{
			a[k]=a[k]*10+s[i]-'0';
			if(!isdigit(s[i+1]))
			k++;
		}
	}
	for(i=1;i<l;i++)
	{
		if(b[i]=='*')
		{
			a[i+1]=a[i]*a[i+1];
			a[i]=0;
			b[i]='+';
		}
		if(b[i]=='/')
		{
			a[i+1]=a[i]/a[i+1];
			a[i]=0;
			b[i]='+';
		}	
	}
	ans=a[1];
	for(i=1;i<l;i++)
	{
		if(b[i]=='+')
		ans+=a[i+1];
		if(b[i]=='-')
		ans-=a[i+1];
	}
	printf("%d",ans);
    return 0;
   }


