#include <stdio.h>
#include <math.h>
#include <stdlib.h> 
#include <ctype.h>
#include <string.h> 
#include <time.h>
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define LEN 1000

int calculate(int x,int y,char ch){
	switch(ch){
		case '+':{
			return x+y;
		}
		case '-':{
			return x-y;
		}
		case '*':{
			return x*y;
		}
		case '/':{
			return x/y;
		}
	}
}

char* strchr2(char *str,char ch1,char ch2){
	char *p1=strchr(str,ch1);
	char *p2=strchr(str,ch2);
	if(p1==NULL)
		return p2;
	if(p2==NULL)
		return p1;
	return min(p1,p2);
}

char* strreplace(char *dest,char *src,char *start,char *end){
	int src_len=strlen(src);
	strcpy(start,src);
	for(int j=start-dest+src_len;j<end-dest;j++)
		dest[j]=' ';
	return dest;
}

void reverse(char A[]){
	char *p1,*p2,temp;
	for(p1=A,p2=p1+strlen(A)-1;p1<p2;p1++,p2--){
		temp=*p1;
		*p1=*p2;
		*p2=temp;
	}
	return;
}

void integer_to_string(int src,char *dest){
	int i=0,src_is_negative=0;
	if(src==0){
		strcpy(dest,"0\0");
		return;
	}
	if(src<0){
		src*=-1;
		src_is_negative=1;
	}
	while(src){
		dest[i++]=src%10+'0';
		src/=10;
	}
	if(src_is_negative)
		dest[i++]='-';
	dest[i]='\0';
	reverse(dest);
	return;
} 

int main(){
	char str[LEN],str_ans_tmp[LEN];
	char *p_value1=str,*p_value2=str;
	int value1=0,value2=0,ans_tmp=0;
	gets(str);
	int priority=1;
	while(priority<=2){
		while(1){
			p_value2 = (priority==1)?strchr2(p_value1+1,'*','/'):strchr2(p_value1+1,'+','-');
			if(p_value2==NULL)
				break;
			char ch=*p_value2;
			p_value1=p_value2-1;
			while(isdigit(*(p_value1-1))||isspace(*(p_value1-1)))
			p_value1--;		//
			if(str[0]=='-'){
				p_value1--;
				value1*=-1;
			}
			sscanf(p_value1,"%d",&value1);
			p_value2++;
			sscanf(p_value2,"%d",&value2);
			while(isdigit(*(p_value2+1))||isspace(*(p_value2+1)))
				p_value2++;		//
			ans_tmp=calculate(value1,value2,ch);
			integer_to_string(ans_tmp,str_ans_tmp);
			strreplace(str,str_ans_tmp,p_value1,p_value2);
		}
		p_value1=str;
		priority++;
	}
	int unprinted=1;
	for(int i=0;isdigit(str[i]);i++){
		printf("%c",str[i]);
		unprinted=0;
	}
	if(unprinted)
		printf("0");
	return 0;
}

