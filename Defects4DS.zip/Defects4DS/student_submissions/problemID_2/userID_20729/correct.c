#include <stdio.h>
#include <string.h>
int main()
{
	int i,j,k=0,l,num[10000],ans[10000],t=0,sum,len;
	char math[10000],c[10000];
	gets(math);
	len=strlen(math);
	for(i=0;i<len;i++)
	{
		if(math[i]=='+'||math[i]=='-'||math[i]=='*'||math[i]=='/')
		{
			c[k]=math[i];
			k++;
		}
	}
	c[k]='\0';
	k=0;
	for(i=0;i<len;i++)
	{
		if(math[i]=='+'||math[i]=='-'||math[i]=='*'||math[i]=='/'||math[i]==' ')
		continue;
		else
		{
			t=math[i]-'0';
			for(j=i+1;math[j]!='=';j++)
			{
				if(math[j]=='+'||math[j]=='-'||math[j]=='*'||math[j]=='/'||math[j]==' ')
				break;
				else
				t=10*t+(math[j]-'0');
			}
		}
		num[k]=t;
		k++;
		t=0;
		i=j;
    }
    if(strlen(c)==0)
    {
    	for(i=0;i<len-1;i++)
    	if(math[i]==' ')
    	continue;
    	else
    	printf("%c",math[i]);
	}
    else
    {
     {
    	k=0;
     }
    for(i=0;i<strlen(c);i++)
	{
		if(c[i]=='+'||c[i]=='-')
		{
			t=num[i];
		}
		if(c[i]=='*'||c[i]=='/')
		{
			for(j=i;c[j]!='\0';j++)
			{
				if(c[j]=='*'||c[j]=='/')
				continue;
			    else
			    break;
			}
			t=num[i];
			for(l=i;l<=j-1;l++)
			{
				if(c[l]=='*')
				t=t*num[l+1];
				if(c[l]=='/')
				t=t/num[l+1];
			}
			i=j;
		}
		ans[k]=t;
		k++;
	}
	if(c[strlen(c)-1]=='+'||c[strlen(c)-1]=='-')
	{
		ans[k]=num[strlen(c)];
	}
	k=1;
	sum=ans[0];
	for(i=0;c[i]!='\0';i++)
	{
		if(c[i]=='*'||c[i]=='/')
		continue;
		if(c[i]=='+')
		{
			sum=sum+ans[k];
			k++;
		}
		if(c[i]=='-')
		{
			sum=sum-ans[k];
			k++;
		}
	}
	printf("%d",sum);
    }
}


