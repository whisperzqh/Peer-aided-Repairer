#include<stdio.h>
#include<string.h>
int main()
{
	char a[128]={0},a1[128]={0};
	char b[128]={0};
	int c[128]={0},i,j,k,l,s=0;
	gets(a);
	for(i=0,j=0;i<strlen(a);i++){
		if(a[i]!=' '){
			a1[j]=a[i];
			j++;
		}
	}
	for(i=0,j=0,k=0;i<strlen(a1);i++){
		if(a1[i]=='+'||a1[i]=='-'||a1[i]=='*'||a1[i]=='/'){
			b[j]=a1[i];
			j++;
		}
		else if(a1[i]>='0'&&a1[i]<='9'&&a1[i+1]>='0'&&a1[i+1]<='9'){
			c[k]=c[k]*10+a1[i]-48;
		}
		else if(a1[i]>='0'&&a1[i]<='9'&&(a1[i+1]<'0'||a1[i+1]>'9')){
			c[k]=c[k]*10+(a1[i]-48);
			k++;
		}
	}
	for(i=0;i<strlen(b);i++){
		if(b[i]=='-'){
			c[i+1]=-c[i+1];
		}
		else if(b[i]=='*'){
			c[i+1]=c[i+1]*c[i];
			c[i]=0;
		}
		else if(b[i]=='/'){
			c[i+1]=c[i]/c[i+1];
			c[i]=0;
		}
	}
	for(i=0;i<(strlen(b)+1);i++){
		s+=c[i];
	}
	printf("%d",s);

	return 0;
}

