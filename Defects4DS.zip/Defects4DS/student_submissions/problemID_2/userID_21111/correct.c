#include<stdio.h>
#include<string.h>
#include<stdlib.h>



int main()
{
    char str[1005];
    char temp[100];
    long long num[100] = {0};
    char sign[100];
    int i, j = 0, k = 0, l = 0;
    gets(str);
    for (i = 0; i < strlen(str)-1; i++)
    {
        if (str[i] >= '0' && str[i] <= '9')
        {
            temp[j] = str[i];
            while (str[i+1] >= '0' && str[i+1] <= '9')
            {
                j++;
                temp[j] = str[i+1];
                i++;
            }
            j = 0;
            num[k] = atoll(temp);
            memset(temp, 0, sizeof(temp));
            k++;
        }
        else if (str[i] == '+' || str[i] == '-' || str[i] == '*' || str[i] == '/')
        {
            sign[l] = str[i];
            l++;
        }
    }
    sign[l] = '\0';

    for (i = 0; sign[i] != '\0'; i++)
    {
        if (sign[i] == '*')
        {
            num[i] *= num[i+1];
            j = i;
            while (j < strlen(sign))
            {
                sign[j] = sign[j+1];
                num[j+1] = num[j+2];
                j++;
            }
            i--;

        }
        else if (sign[i] == '/')
        {
            num[i] = num[i] / num[i+1];
            j = i;
            while (j < strlen(sign))
            {
                sign[j] = sign[j+1];
                num[j+1] = num[j+2];
                j++;
            }
            i--;
        }


    }

    for (i = 0; sign[i]!='\0'; i++)
    {
        if (sign[i] == '+')
        {
            num[i] += num[i+1];
            j = i;
            while (j < strlen(sign))
            {
                sign[j] = sign[j+1];
                num[j+1] = num[j+2];
                j++;
            }
            i--;

        }
        else if (sign[i] == '-')
        {
            num[i] -= num[i+1];
            j = i;
            while (j < strlen(sign))
            {
                sign[j] = sign[j+1];
                num[j+1] = num[j+2];
                j++;
            }
            i--;
        }
    }
    printf("%lld", num[0]);

    return 0;
}

