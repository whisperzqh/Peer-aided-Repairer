#include<stdio.h>
#include<ctype.h>
int main()
{
	char a[10007];
	gets(a);
	int i,j=0,k=0;
	int shu[5003]={0},fu[5004]={0};
	for(i=0;a[i]!='=';i++)
	{
		if(a[i]==' ')
			continue;	
		else if(isdigit(a[i]))
		{
			if(isdigit(a[i-1]))
			{
				shu[j]=shu[j]*10+a[i]-'0';		
			}
			else
			{
				shu[j]=a[i]-'0';
			} 
			if(isdigit(a[i+1])<=0)
			j++;	
		}
		else
		{
			if(a[i]=='+')
			fu[k]=1;
			if(a[i]=='-')
			fu[k]=2;
			if(a[i]=='*')
			fu[k]=3;
			if(a[i]=='/')
			fu[k]=4;
			k++;
		}	
	}
	if(fu[0]==0)
	{
		for(i=0;a[i]!='=';i++)
		{
			printf("%c",a[i]);
		}
    }
	else
	{
		for(i=0;i<k;i++)
		{
			if((fu[i]==3)||(fu[i]==4))
			{
				shu[i+1]=fu[i]==3?shu[i]*shu[i+1]:shu[i]/shu[i+1];
				shu[i]=0;
				fu[i]=(i==0)?1:fu[i-1];
			}
		}
		int sum=shu[0];
		for(i=0;i<k;i++)
		{
			sum=(fu[i]==1)?sum+shu[i+1]:sum-shu[i+1];
		}
		printf("%d",sum);
	}
	return 0;
	
	
}

