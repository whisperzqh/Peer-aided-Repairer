#include<stdio.h>
int main()
{
	char func1,func2,func3;
	int num1,num2,num3;
	func1 = '+';
	num1 = 0;
	while(func1!='='){
	   scanf("%d %c",&num2,&func2);
		while(func2=='*'||func2=='/'){
			scanf("%d %c",&num3,&func3);
			if(func2=='*')
	   			{	
	   			num2*=num3;
	   			func2 = func3;
	   			}
	 			else if(func2=='/')
	            {
	   			num2/=num3;
	            func2 = func3;
	   			}
    	}
		if(func1=='+')
	   {
	   num1+=num2;
	   func1 = func2;
	   }
	 else if(func1=='-')
	   {
	   num1-=num2;
	   func1 = func2;
	   }
    }
	printf("%d",num1);
	return 0;
}
	   

