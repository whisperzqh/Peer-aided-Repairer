#include<stdio.h>
#include<string.h>

int shu[100];
char fu[100];
char s[100];
int p[4] = {0};

int main()
{
	int i,j,k = 0,l = 0;
	int f = 0;
	
	gets(s);
	
	for(i = 0;i < strlen(s);i++)
	{
		if(s[i] >= '0' && s[i] <= '9')
		{
			f += 1;
			p[f] = s[i] - '0';
		}
		
		else if(s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/' || s[i] == '=')
		{
			switch(f)
			{
				case 1:
					{
						shu[k++] = p[1];
						break;
					}
				case 2:
					{
						shu[k++] = p[1] * 10 + p[2];
						break;
					}
				case 3:
					{
						shu[k++] = p[1] * 100 + p[2] * 10 + p[3]; 
						break;
					}	
			}
			
			p[1] = 0;
			p[2] = 0;
			p[3] = 0;
			f = 0;
			
			fu[l++] = s[i];
		}
	}
	
	for(i = 0;fu[i] != '=';i++)
	{
		if(i < 0) 
			i += 1;
		
		if(fu[i] == '*')
		{
			shu[i] = shu[i] * shu[i + 1];
			for(j = i + 2;j <= 99;j++)
			{
				shu[j - 1] = shu[j];
			}
			
			for(j = i;;j++)
			{
				if(fu[j] == '=')
					break;
					
				fu[j] = fu[j + 1]; 
			}
			i -= 1;
		}
		
		else if(fu[i] == '/')
		{
			shu[i] = shu[i] / shu[i + 1];
			for(j = i + 2;j <= 99;j++)
			{
				shu[j - 1] = shu[j];
			}
			
			for(j = i;;j++)
			{
				if(fu[j] == '=')
					break;
					
				fu[j] = fu[j + 1]; 
			}
			i -= 1;
		}
	}
	
	for(i = 0;fu[i] != '=';i++)
	{
		if(i < 0) 
			i += 1;
		
		if(fu[i] == '+')
		{
			shu[i] = shu[i] + shu[i + 1];
			for(j = i + 2;j <= 99;j++)
			{
				shu[j - 1] = shu[j];
			}
			
			for(j = i;;j++)
			{
				if(fu[j] == '=')
					break;
					
				fu[j] = fu[j + 1]; 
			}
			i -= 1;
		}
		
		if(fu[i] == '-')
		{
			shu[i] = shu[i] - shu[i + 1];
			for(j = i + 2;j <= 99;j++)
			{
				shu[j - 1] = shu[j];
			}
			
			for(j = i;;j++)
			{
				if(fu[j] == '=')
					break;
					
				fu[j] = fu[j + 1]; 
			}
			i -= 1;
		}
	}
	
	printf("%d",shu[0]);
}

