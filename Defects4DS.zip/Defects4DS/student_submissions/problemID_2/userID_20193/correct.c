#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
int main (){
	char a[1002]="\0",b[1002]="\0";
	int shu[100]={0};
	char fu[100]="\0";
	gets(a);
	int i=0,j=0,k=0,m=0;
	for(i=0;i<strlen(a);i++){
		if(!isspace(a[i])) b[m++]=a[i];
	}
	for(i=0;i<strlen(b);i++){
		if(!(b[i]>='0'&&b[i]<='9'))
		fu[j++]=b[i];
		else {
			for(i;b[i]>='0'&&b[i]<='9';i++){
			shu[k]=shu[k]*10+b[i]-'0';
			}
			k++;
			i--;
		}
	}
		for(i=0;i<strlen(fu);i++){
			if(fu[i]=='*'){
				shu[i+1]=shu[i]*shu[i+1];
				shu[i]=-1;
			}
			else if(fu[i]=='/'){
				shu[i+1]=shu[i]/shu[i+1];
				shu[i]=-1;
			}
		}	
		
		j=0,k=0;
		char fu1[100]="\0";
		int shu1[100]={0};
		for(i=0;i<strlen(a);i++){
			if(shu[i]!=-1) shu1[j++]=shu[i];
			if(fu[i]=='+'||fu[i]=='-') fu1[k++]=fu[i];
		}
		int sum=shu1[0];
		for(i=0;i<strlen(fu1);i++){
			if(fu1[i]=='+') sum=sum+shu1[i+1];
			else sum-=shu1[i+1];
		}
		printf("%d\n",sum);
}
