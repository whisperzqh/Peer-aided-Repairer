#include<stdio.h>
#include<string.h>
char s[100005],op[100005];
int num[100005],tot;
int main()
{
	scanf("%s",s);int len=strlen(s);int pos=0;
	for(int i=0;i<len;i++) if(s[i]!=' ') s[pos++]=s[i];s[pos]='\000';
	len=pos;int temp=0;int i=0;
	while(s[i]<='9'&&s[i]>='0') temp=temp*10+s[i++]-'0';
	for(;i<len;)
	{
		if(s[i]=='*'||s[i]=='/')
		{
			int pd;if(s[i]=='*') pd=0;else pd=1;
			int ss=0;i++;
			while(s[i]<='9'&&s[i]>='0') ss=ss*10+s[i++]-'0';
			if(!pd) temp=temp*ss;
			else temp=temp/ss;
		}
		else if(s[i]=='+'||s[i]=='-')
		{
			num[++tot]=temp;temp=0;
			op[tot]=s[i++];
			while(s[i]<='9'&&s[i]>='0') temp=temp*10+s[i++]-'0';
		}
		else if(s[i]=='=')
		{
			num[++tot]=temp;break;
		}
	}
	int ans=num[1];
	for(int i=2;i<=tot;i++)
	if(op[i-1]=='+') ans+=num[i];
	else ans-=num[i];
	printf("%d",ans);
}

