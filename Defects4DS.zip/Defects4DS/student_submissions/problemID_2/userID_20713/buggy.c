#include <stdio.h>
#include <string.h>
int main()
{
    char a[10000],d[10000];
    int i,n,b=1,sum = 0,j=0,c[10000]={0},m=0;
    gets(a);
    n=(int)strlen(a);
    for (i=0; i<=n-1; i++)
    {
        if (a[i]!=' ')
        {
            a[j++]=a[i];
        }
    }
    a[j]='\0';

    if (a[0]!='-')
    {
        for (i=0; i<=n-1; i++)
            {
                if (a[i]>='0'&&a[i]<='9')
                {
                    c[m]=c[m]*10+a[i]-'0';
                }
                else
                {
                    m++;
                }
            }
        d[0]='+';
        j=1;
        for (i=0; i<=n+1; i++)
        {
            if (a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='=')
            {
                d[j++]=a[i];
            }
        }
        d[j]='\0';
    }
    else
    {
        for (i=1; i<=n-1; i++)
            {
                if (a[i]>='0'&&a[i]<='9')
                {
                    c[m]=c[m]*10+a[i]-'0';
                }
                else
                {
                    m++;
                }
            }
        j=0;
        for (i=1; i<=n+1; i++)
        {
            if (a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/'||a[i]=='=')
            {
                d[j++]=a[i];
            }
        }
        d[j]='\0';
    }
    j=0;
    for (i=1; i<=n/2+1; i++)
    {
        b=1;
        if (d[i]=='-'||d[i]=='+'||d[i]=='='||d[i]=='\0')
        {
            b=b*c[j];
            for (m=j; m<=i; m++)
            {
                if (d[m]=='*')
                {
                    if (c[m]==0)
                    {
                        b=0;
                        break;
                    }
                    else
                        b=b*c[m];
                    
                }
                if (d[m]=='/'&&c[m]!=0)
                {
                    b=b/c[m];
                    
                }
            }
            if (d[j]=='-')
            {
                sum=sum-b;
                
            }
            if (d[j]=='+')
            {
                sum=sum+b;
                
            }
            j=i;
        }
    }
    
    printf("%d\n",sum);
    return 0;
}

