#include<stdio.h>
int main()
{
	int x1,x2,res;
	char sg0,sg1,sg2;
	res=0,sg0='+';
	while(1){
		scanf("%d%c",&x1,&sg1);
		while(sg1=='*'||sg1=='/'){
			scanf("%d%c",&x2,&sg2);
			if(sg1=='*') x1*=x2;
			else if(sg1=='/') x1/=x2;
			sg1=sg2;
		}
		if(sg0=='+') res+=x1;
		else if(sg0=='-') res-=x1;
		if(sg1=='='){
			printf("%d\n",res);
			break;
		}
		sg0=sg1;
	}
	return 0;
}

