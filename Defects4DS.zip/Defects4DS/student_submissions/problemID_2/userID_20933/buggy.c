#include<stdio.h>

int main()
{
	long long x1,x2;
	long long sum=0;
	char y1,y2;
	char a='+';
	
	while(a!='=')
	{
		scanf("%lld %c",&x1,&y1);
		while(y1=='*'||y1=='/')
		{
			scanf("%lld %c",&x2,&y2); 
			if(y2=='*')
			{
				x1*=x2;
				y1=y2;
			}	
			else
			{
				x1/=x2;
				y1=y2;
			}
		}
		if(y1=='+')
			sum+=x1;
		
		else if(y1=='-')
			sum-=x1;
	}
	printf("%lld",sum); 
	return 0;
}

