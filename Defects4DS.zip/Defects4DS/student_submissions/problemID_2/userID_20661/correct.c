#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int a[1010],b[1010],c=0,d,t,i,ans=0;
	char inp[1010],s[1010],s2[1010];
	gets(inp);
	d=0;
	t=0;
	for(i=0;inp[i]!='=';i++)
	{
		if('0'<=inp[i]&&inp[i]<='9')
			if('0'<=inp[i-1]&&inp[i-1]<='9')
			{
				a[t-1]=a[t-1]*10+inp[i]-'0';
			}
			else 
			{
				a[t]=inp[i]-'0';
				t++;
 			}
 		else if(inp[i]=='+'||inp[i]=='-'||inp[i]=='*'||inp[i]=='/')
 		{
 			s[d]=inp[i];
			d++;	
		}
	}
	for(i=0;i<t;i++)
	{
		b[c]=a[i];
		while(s[i]=='*'||s[i]=='/')
		{
			if(s[i]=='*')
				b[c]*=a[i+1];
			else
				b[c]/=a[i+1];
			i++;
		}
		if(s[i]=='+'||s[i]=='-')
		{
			s2[c]=s[i];
			c++;
		}	
	}
	ans=b[0];
	for(i=0;i<c;i++)
	{
		if(s2[i]=='+')
			ans+=b[i+1];
		else
			ans-=b[i+1];
	}
	printf("%d",ans);
	return 0;
}

