#include<stdio.h>
#include<string.h>
#include<ctype.h>

int i,i1=0,i2=0,k1=0,k2=0,amount,num1[10000],num2[10000],ans;
char str[1000],sym1[10000],sym2[10000];

int main()

{
    gets(str);
    for(i=0;str[i]!='=';i++)
    {
        if(isdigit(str[i]))
        {
            num1[i1]=str[i]-'0';
            while(isdigit(str[i+1]))
            {
                num1[i1]=num1[i1]*10+str[i+1]-'0';
                i++;
            }
            i1++;
        }
        else if(str[i]=='+'||str[i]=='-'||str[i]=='*'||str[i]=='/')
        {
            sym1[k1]=str[i];
            k1++;
        }
    }
    
    for(i=0;i<=k1;i++)
    {
        num2[i2]=num1[i];
        while(sym1[i]=='*'||sym1[i]=='/')
        {
            if(sym1[i]=='*')
            {
                num2[i2]*=num1[i+1];
            }
            else
            {
                num2[i2]/=num1[i+1];
            }
            i++;
        }
        if(sym1[i]=='+'||sym1[i]=='-')
        {
            sym2[k2]=sym1[i];
            k2++;
        }
        i2++;
    }
    
    ans = num2[0];
    
    for(i=0;i<k2;i++)
    {
        if(sym2[i]=='+')
        {
            ans+=num2[i+1];
        }
        else if(sym2[i]=='-')
        {
            ans-=num2[i+1];
        }
    }
    printf("%d",ans);
    return 0;
}

