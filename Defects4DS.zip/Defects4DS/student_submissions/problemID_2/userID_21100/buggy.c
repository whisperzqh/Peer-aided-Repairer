#include<stdio.h>
#include<string.h>

void xspace(char *s);

int main()
{
	char s[1000],m='+';
	int i,j;
	int temp=1,temp2=0,sum=0;

	gets(s);
	xspace(s);
	
	for(i=0;s[i]>0;i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			temp2=temp2*10+s[i]-'0';
			if(m=='-') temp2=-temp2;
		}
		else
		{
			if(s[i]=='+'||s[i]=='-'||s[i]=='=')
			{
				if(m=='*') sum+=(temp*temp2);
				else if(m=='/') sum+=(temp/temp2);
				else sum+=temp2;
				temp=1; temp2=0;
				m=s[i];
			}
			else if(s[i]=='*'||s[i]=='/')
			{
				if(m=='*') temp*=temp2;
				else if(m=='/') temp/=temp2;
				else temp=temp2;
				m=s[i]; temp2=0;
			}
		}
	}
	printf("%d",sum);
	return 0;
}

void xspace(char*s)
{
	int i,j;
	for(i=0,j=0;s[i]>0;i++)
	{
		if(s[i]!=32) s[j++]=s[i];
	}
	s[j]=0;
	return;
}

