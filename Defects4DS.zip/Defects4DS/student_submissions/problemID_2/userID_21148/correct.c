#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
char str[128],cal[128];
int res[128];
int mth(char ,int ,int );
int main()
{
	int i,j,k,l,len,lenc,c1=0,c2=0,ten=1,ans=0,cnt=0,x,flag=1;
	int num[128]={0},leap[128]={0},sgn[128]={0};
	gets(str);
	for(i=0;i<strlen(str);i++){
		if(str[i]==' '){
			for(j=i;j<strlen(str)-1;j++){
				str[j]=str[j+1];
			}
			str[strlen(str)-1]='\0';
		}
	}
	len=strlen(str);
	for(i=0;i<len;i++){
		if(str[i]=='*'||str[i]=='/'){
			cal[c1]=str[i];
			c1++;
			leap[i]=1;
			for(j=i-1;j>=0;j--){
				if(str[j]<'0'||str[j]>'9'){
					if(str[j]=='*'||str[j]=='/'){
						sgn[c1-1]=1;
						flag=0;
					}
					break;
				}
				else{
					leap[j]=1;
				}
			}
			ten=1;
			if(flag){
				for(k=i-1;k>j;k--){
    				num[c2]+=(str[k]-'0')*ten;
	    			ten*=10;
		    	}
			    ten=1;
	    		c2++;
		   	}
		   	flag=1;
			for(j=i+1;j<len;j++){
				if(str[j]<'0'||str[j]>'9'){
					break;
				}
				else{
					leap[j]=1;
				}
			}
			for(k=j-1;k>i;k--){
				num[c2]+=(str[k]-'0')*ten;
				ten*=10;
			}
			ten=1;
			c2++;
		}
	}
	lenc=strlen(cal);
	for(i=0,j=0,k=0;k<lenc;i++,j++,k++){
		if(sgn[k]){
			res[j-1]=mth(cal[k],res[j-1],num[i+1]);
			j--;
		}
		else{
			res[j]=mth(cal[k],num[i],num[i+1]);
		}
		if(sgn[k+1]==0){
			i++;
		}
	}
	if(leap[0]){
		ans=res[0];
		j=0;
		cnt++;
	}
	else{
		for(i=0;i<len;i++){
			if(str[i]<'0'||str[i]>'9'){
				break;
			}
		}
		j=i;
		ten=1;
		for(i=j-1;i>=0;i--){
			ans+=(str[i]-'0')*ten;
			ten*=10;
		}
	}
	for(i=j;i<len;i++){
		if(str[i]=='+'||str[i]=='-'){
			if(leap[i+1]){
				ans=mth(str[i],ans,res[cnt]);
				cnt++;
			}
			else{
				for(k=i+1;str[k]>='0'&&str[k]<='9';k++){
					;
				}
				l=k;
				ten=1;
				x=0;
				for(k=l-1;k>i;k--){
					x+=(str[k]-'0')*ten;
					ten*=10;
				}
				ans=mth(str[i],ans,x);
			}
		}
		else{
			continue;
		}
		if(str[i]=='='){
			break;
		}
	}
	printf("%d",ans);
	return 0; 
}
int mth(char a,int b,int c)
{
	int d;
	switch(a){
		case '+':d=b+c;
		break;
		case '-':d=b-c;
		break;
		case '*':d=b*c;
		break;
		case '/':d=b/c;
		break;
	}
	return d;
}

