#include <stdio.h>
#include <string.h> 
#include <math.h>
char s[100],fu[100];
int a[100];
int main()
{
	int i=0,j=0,k=0;
	gets(s);
	for(i=0;s[i]!='=';i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
		  a[j]=s[i]-'0';
		  while(s[i+1]>='0'&&s[i+1]<='9')
		  {
		  	a[j]=a[j]*10+s[i+1]-'0';
		  	i++;
		  }
		  j++;
		}
		if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/')
		{
		  fu[k]=s[i];
		  k++;	
		}
	 } 
	 if(fu[0]=='\0')
	 {
	 	printf("%d",a[0]);
	 }
	 else
	 {
	    for(k=0;k<strlen(fu);k++)
	    {
	 	   if(fu[k]=='*')
	 	   {
	 	      a[k]=a[k]*a[k+1];
		      a[k+1]=a[k];
		    }
		   if(fu[k]=='/')
		   {
			   a[k]=a[k]/a[k+1];
			   a[k+1]=a[k];
		   }
	    }
	    for(j=0;j<strlen(fu);)
	    {
	    	while(fu[j]=='*'||fu[j]=='/')
	    	{
	    		j++;
			}
	 	   k=j;
	 	   
	 	   if(fu[j]=='+')
	 	   {
	 		   while(fu[k+1]=='*'||fu[k+1]=='/')
	 		   {
	 			   k++;
			    }
			   a[j]=a[j]+a[k+1];
			   a[k+1]=a[j];
			   j=k+1; 
		    }
		    if(fu[j]=='-')
		    {
		 	   k=j;
		 	   while(fu[k+1]=='*'||fu[k+1]=='/')
		 	   {
		 		   k++;
			    }
			    a[j]=a[j]-a[k+1];
			    a[k+1]=a[j];
			    j=k+1; 
		    }
	    }
	   int n=strlen(fu);
	   printf("%d",a[n]);
   }
	return 0;
 } 

