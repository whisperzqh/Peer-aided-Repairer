/*#include<stdio.h>
#include<string.h>
int main()
{
	int shu=0,wei=0,lenxian=0,lenhou=0,p=0;
	char a[50]={0};
	int i,j,k=0;
	char b[200],xian[100]={0},hou[100]={0};
	gets(b);
	//
	for(i=0;b[i]!='=';i++){
		if(b[i]<='9'&&b[i]>='0'){
		//	printf("shu\n");
			shu=shu*10+b[i];
		}
		else if(b[i]<'0'||b[i]>'9'){
		//	printf("fuhao\n");
			//
			//
			if(shu!=0){
				a[wei++]=shu;
			    shu=0;
			}
			//
			if(b[i]=='+'||b[i]=='-'){
				hou[k++]=b[i];
				lenhou++;
			}
			//
			else if(b[i]=='*'||b[i]=='/'){
				xian[k++]=b[i];
				lenxian++;
			}
		}
	}
	int w;
	a[wei++]=shu;
	printf("here %d %d \n",wei,k); 
	for(i=0;i<wei;i++){
		printf("shi%d \n",a[i]-'0');
	}
	//
//	printf("wei=%d,k=%d ",wei,k);
//	printf("zifudaxiao%d %d \n",lenxian,lenhou);
/*	for(i=0;i<=lenxian;i++){
		printf("%c ",xian[i]);
	}
	for(i=0;i<=lenhou;i++){
		printf("%c ",hou[i]);
	}*/
/*	for(i=0;i<lenxian;i++){
		if(xian[i]=='*'){
		//	printf("%d %d %d",a[i]-48,a[i-p]-48,a[i+1-p]-48);
		//	printf(" %d,%d ",i+1-p,wei-i);
		    printf("%d %d ",a[i-p]-'0',a[i+1-p]-'0');
		
			a[i]=(a[i-p]-'0')*(a[i+1-p]-'0')+48;
		//	printf("cheng");
		printf("%d %d  %d %d %d",i-p,a[i-p]-'0',a[i]-'0',i+1-p,a[i+1-p]-'0');
		printf(" %d\n",a[i]-'0');
			
	//	printf("shu %d,%d \n",a[i+1-p],a[wei-i]);
			for(j=i+1-p;j<wei-i-1;j++){
				a[j]=a[j+1];
				printf("jin %d %d ",j,a[j]-'0');
			}
		for(j=0;j<=3;j++){
				printf("%dshu",a[j]-'0');
			}
			p++;
		}
		//
	/*	for(w=1;2*w<wei;w++){
		printf("\nA%d %d \n",w,a[w]-'0');
	}*/
/*		else if(xian[i]=='/'){
				p++;
			a[i]=a[i]/a[i+1];
		//	printf("chu");
			for(j=i+1;j<=wei-i;j++){
				a[j]=a[j+1];
		//		printf("jin");
			}
		}
	}
	p=0;
	for(i=0;i<lenhou;i++){
		if(hou[i]=='+'){
			a[i]=a[i]+a[i+1];
		//	printf("jia");
			for(j=i+1;j<=wei-i;j++){
				a[j]=a[j+1];
		//		printf("jin");
			}
		}
		else if(hou[i]=='-'){
			a[i]=a[i]-a[i+1];
		//	printf("jian");
			for(j=i+1;j<=wei-i;j++){
				a[j]=a[j+1];
		//		printf("jin");
			}
		}
	}
	printf("%d",a[i+1-p]-'0');
	return 0;
}*/

//
#include<stdio.h>
#include<string.h>
int main()
{
	int a[100]={0},i,j=0,k=0,len,n=0,p=0,l=0;
	char b[100],c[100]={0};
	gets(b);
	len=strlen(b); 
	for(i=0;i<len;i++){
		if(b[i]<='9'&&b[i]>='0'){
			n=n*10+b[i]-'0';
		}
		else if(b[i]!=' '){
			l++;
			p=1;
			a[j++]=n;
			n=0;
			c[k++]=b[i];
			if(k==3&&j==3){
				k=2;  j=2;
				if((c[0]=='+'||c[0]=='-')&&(c[1]=='*'||c[1]=='/')){
				    if(c[1]=='*'){
				    	a[1]=a[1]*a[2];
				    	a[2]=0;
					}
					else if(c[1]=='/'){
						a[1]=a[1]/a[2];
						a[2]=0;
					}
					c[1]=c[2];
				}
				else {
					if(c[0]=='*'){
						a[0]=a[0]*a[1];
					}
					else if(c[0]=='/'){
						a[0]=a[0]/a[1];
					}
					else if(c[0]=='+'){
						a[0]=a[0]+a[1];
					}
					else if(c[0]=='-'){
						a[0]=a[0]-a[1];
					}
					a[1]=a[2];
					a[2]=0;
					c[0]=c[1];
					c[1]=c[2];
				}
		}
	}
}
if(l==1){
	printf("%d\n",a[0]);
}
else {
	if(c[0]-'0'==0){
	printf("%d\n",n);
}
else{
	if(c[0]=='*'){
		
	printf("%d\n",a[0]*a[1]);
}
else if(c[0]=='/'){
	printf("%d\n",a[0]/a[1]);
}
else if(c[0]=='+'){
	printf("%d\n",a[0]+a[1]);
}
else if(c[0]=='-'){
	printf("%d\n",a[0]-a[1]);
}
}
}
	return 0;
}

