#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main ()
{
	int num[1005] = {0}, i = 1, j, flag[1005] = {0}, t, result;
	char r, x[1005];
	r = getchar();
	while (r != '=')
	{
		if (r >= '0' && r <= '9')
		{
			num[i] *= 10;
			num[i] += (r - '0');
		}
		else
		{
			if (r == ' ')
				;
			else
			{
				x[i] = r;
				i ++;
			}
		}
		r = getchar();
	}
	t = i - 1;
	if (t == 0)
	{
		printf ("%d", num[1]);
		return 0;
	}
	for (i = 1;i <= t;i ++)
	{
		if (x[i] == '*')
		{
			num[i] *= num[i + 1];
			num[i + 1] = num[i];
			result = num[i];
			flag[i] = 1;
		}
		if (x[i] == '/')
		{
			num[i] /= num[i + 1];
			num[i + 1] = num[i];
			result = num[i];
			flag[i] = 1;
		}
	}
	for (i = 1;i <= t;i ++)
	{
		if (x[i] == '+')
		{
			j = i + 1;
			while (flag[j] != 0)
				j ++;
			num[i] += num[j];
			num[j] = num[i];
			result = num[i];
		}
		if (x[i] == '-')
		{
			j = i + 1;
			while (flag[j] != 0)
				j ++;
			num[i] -= num[j];
			num[j] = num[i];
			result = num[i];
		}
	}
	printf ("%d", result);
	return 0;
}

