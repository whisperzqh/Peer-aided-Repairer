#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main()
{
    int a,b,c;
    char l,m,n;

   
    a = 0;
    l= '+';
     do{
        scanf("%d  %c",&b,&m);    
      
        
       do {
            scanf("%d  %c",&c,&n);
            if(m=='*')
                b *= c;
            else if(m=='/')
                b /= c;
            m = n;    
        }
		while(m=='/' || m=='*');
       
        if(l=='+')
            a += b;
        else if(l=='-')
            a -= b;
        l = m;    //
    }
    while(l!='='); 
 printf("%d",a);

	return 0;
}

