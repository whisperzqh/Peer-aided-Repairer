#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<ctype.h>
#include <string.h>
#define N 10000
char a[N],b[N],type[N],ptype[N];
int numb[N],pnumb[N];

int main()
{
	gets(a);
	for(int i=0,j=0;i < strlen(a);i++)
		if(a[i]!=' ')
			b[j++]=a[i];
			
	for (int i=0,k=0,l=0;b[i]!='\0';i++)
	{
		if(b[i]=='+'||b[i]=='-'||b[i]=='*'||b[i]=='/'||b[i] == '=')
            type[k++]=b[i];
        if(b[i]>='0'&&b[i]<='9')
        {
			for(int len=1;len<10;len++)
			{
				if(b[i+len]>='0'&&b[i+len]<='9')
					continue;
				int n=1,num=0;
				for(int w=len;w>0;w--)
				{
					num+=(b[i+w-1]-'0')*n;
					n*=10;
				}	
				numb[l++]=num;
				i+=len-1;
				break;
				if(b[i+len]<'0'||b[i+len]>'9')
					break;
			}	
		}
	}
	
	for(int i=0,j=0;i<=strlen(type);i++)
	{
		if (type[i]=='+'||type[i]=='-'||type[i]=='=')
		{
		 	pnumb[j]=numb[i];
            ptype[j]=type[i];
            j++;	
		}
		if (type[i]=='*') 
            numb[i+1]*=numb[i];
        if (type[i]=='/') 
            numb[i+1]=numb[i]/numb[i+1];
	} 
	int last=pnumb[0];
	for(int i=0;i<strlen(ptype);i++) 
	{
		if (ptype[i]=='+')
            last+=pnumb[i+1];
        if (ptype[i]=='-')
            last-=pnumb[i+1];
	}
	printf("%d",last);
    return 0;
 } 

