#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int a,b,sum=0;
	char a1,b1,c1='+';
	while(1)
	{
		scanf("%d %c",&a,&a1);
		while(a1=='*'||a1=='/')
		{
			scanf("%d %c",&b,&b1);
			if(a1=='*')
			a=a*b;
			else if(a1=='/')
			a=a/b;
			a1=b1;
		}
		if(c1=='+')sum=sum+a;
		else if(c1=='-')sum=sum-a;
		c1=a1;
		if(c1=='=')
		{
		printf("%d",sum);
		break;
		}
	}
	
	return 0;
 } 

