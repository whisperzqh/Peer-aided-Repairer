#include<stdio.h>
#include<string.h>
#include<ctype.h>
char formula[1000], mark[1000];//
int ans[1000],anss[1000];//
int atoi(char formula[], int, int*);//
int main()
{
	int i, j, for_len, ans_len = 0;
	gets(formula);
	for_len = strlen(formula);//
	for(i = 0, j = 0; formula[i]!= '=' && i< for_len; i++) 
	{
		if(isdigit(formula[i]))
		{
			ans[j] = atoi(formula, i, &i);
			j++;
			ans_len++;
		}
    }//
    int k;
    for(i = 0, j = 0, k = 0; formula[i] != '='&& i< for_len; i++ )//
	{//
		switch(formula[i])
		{
			case'*': ans[j+1] *= ans[j]; ans[j] = 0; j++;//
			break;
			case'/': ans[j+1] = ans[j]/ans[j+1]; ans[j] = 0; j++;
			break;
			case'+': mark[k++] = formula[i]; j++;
			break;
			case'-': mark[k++] = formula[i]; j++;
			break;
			
		}
	}
	int anss_len = 0;
	for(i = 0, j = 0; i < ans_len; i++)// 
	{
		if(ans[i]!=0)
		{
			anss[j]=ans[i];
		    j++;
		    anss_len++;
		}
	}
	for(i = 0, j = 0; i < k; i++)
	{
		switch(mark[i])
		{ 
			case'+': anss[j] += anss[j+1]; anss[j+1] = 0; j++;
			break;
			case'-': anss[j] -= anss[j+1]; anss[j+1] = 0; j++;
			break;
		}
		
	}
	int result = 0;
	for(i=0; i < anss_len; i++)
	 result += anss[i];// 
	printf("%d",result);
 } 
 
 int atoi(char formula[1000], int i, int*p)//
 {
 	int number = 0;
 	for(i; '0'-1 < formula[i] && formula[i] < '9'+1; i++)
 	{
 		number = number*10 + formula[i] - '0';
	}
	*p = i-1;
	return number;
 }

