#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
    int x,y,z;
    char x0,y0,z0;
    x=0;
    x0='+';
    while (1)
    {
        scanf("%d%c",&y,&y0);

        while(y0=='*'||y0=='/')
        {
            scanf("%d%c",&z,&z0);
            if(y0=='*')y=y*z;
            else y=y/z;
                 y0=z0;
        }


        if(x0=='+')x=x+y;
        else if(x0=='-')x=x-y;

        x0=y0;

        if(x0=='='){printf("%d\n",x);break;}
    }

    return 0 ;
}

