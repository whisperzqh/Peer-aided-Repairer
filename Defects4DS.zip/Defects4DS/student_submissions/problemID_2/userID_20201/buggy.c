#include <stdio.h>
#include <string.h>
int main()
{
	char sgn[50],str[100],s[100];
	int r[100]={0},re[100]={0},sgn1[50]={0},i=0,j=0,k=0,m=0,n=0,in=0,t=1,result=0;
	gets(str);
	while (str[i]!='\0')
		if (str[i]!=' ')
			s[j++]=str[i++];
				else
					i++;
		s[j]='\0';
	for (i=0,k=strlen(s)-1;i<=k;i++)
		{
			while (s[i]>='0'&&s[i]<='9')
				in=in*10+s[i++]-'0';
					r[m++]=in;
					in=0;
					sgn[n++]=s[i];
		}
		n=0;
		j=0;
		k=0;
	for (i=0;i<m;i++){
		while (sgn[n]=='*'||sgn[n]=='/')
			{
				if (sgn[n]=='*')
					r[i+1]*=r[i];
				if (sgn[n]=='/')
					r[i+1]/=r[i];
					n++;
					i++;
			}
			re[j++]=r[i];
			n++;
					}
					k=1;
					result=re[0];
			for (i=0;i<=n;i++)
					{
				if (sgn[i]=='+')
					result+=re[k++];
				if (sgn[i]=='-')
					result-=re[k++];
				if (sgn[i]=='=')
					result+=re[k++];
				while (sgn[i]=='*'||sgn[i]=='/')
					i++;
					}
				
			printf ("%d",result);
	return 0;
}

