#include<stdio.h>
#include<string.h> 
#include<math.h>
#include<stdlib.h> 
int main()
{
	int a,c,e;
	char b,d,f;
	a=0;
	b='+'; 
	while(b!='=')
	{
		scanf("%d %c",&c,&d);
		while(d=='*' || d=='/')
		{
			scanf("%d %c",&e,&f);
			if(d=='*')
			c=c*e;
			if(d=='/')
			c=c/e;
			d=f;
		}
		if(b=='+')
		a=a+c;
		if(b=='-')
		a=a-c;
		b=d;
	}
	printf("%d",a);
	return 0;
}

