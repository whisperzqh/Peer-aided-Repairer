#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
void clear(char *x)
{
    char *t=x,*k=x;
    while (*t)
    {
        if(*t!=' ') {*x=*t;
           x++;}
        t++;
    }
    *x='\0';
    x=k;

}
int value(char *p)
{
    int re=0;
    for(;isdigit(*p);p++)
        re=re*10+*p-'0';
    return re;
}
int main()
{
    char fml[100]={0};int i=0,k=0,re,j;
    gets(fml);
    clear(fml);
    int a[50][3]={0};//
    for(i=0;i<strlen(fml);i++)
    {
        if(fml[i]=='+')
        {
                a[k][2]=value(fml+i+1) ;
                for(j=i+1;fml[j]!='+'&&fml[j]!='-'&&fml[j]!='=';j++)
                {

                  switch(fml[j])
                {
                    case '*':a[k][2]*=value(fml+j+1);break;
                    case '/':a[k][2]/=value(fml+j+1);break;
                }
                }
                a[k][1]=1;
                k++;



        }
        if(fml[i]=='-')
        {
                a[k][2]=value(fml+i+1) ;
                for(j=i+1;fml[j]!='+'&&fml[j]!='-'&&fml[j]!='=';j++)
                {

                  switch(fml[j])
                {
                    case '*':a[k][2]*=value(fml+j+1);break;
                    case '/':a[k][2]/=value(fml+j+1);break;
                }
                }
                a[k][2]=0-a[k][2];
                a[k][1]=1;
                k++;



        }
    }
    re=value(fml);
    for(i=0;a[i][1]==1;i++)
        re+=a[i][2];
        printf("%d",re);









    return 0;

}

