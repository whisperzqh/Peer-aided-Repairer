#include<stdio.h>
#include<string.h>
#define MAX 300
int atoi1(char *px);
char *change(char *px);
char s1[MAX];
char s2[MAX];
int main()
{
	char sign1,sign2;
	int sum=0,temp1=0,temp2=0;
	int i,j;
	char *pi;
	gets(s1);
	for(i=0,j=0;i<strlen(s1);i++){
		if(s1[i]!=' ')
		s2[j++] = s1[i];
	}
	s2[j] = '\0';
	pi = s2;
	sign1 = '+';
	while(sign1!='='){
		temp1 = atoi1(pi);
		pi = change(pi);
		sign2 = *pi;
		while(sign2=='*' || sign2=='/'){
			temp2 = atoi1((++pi));
			pi = change(pi);
			if(temp2=='/')
			temp1 /= temp2;
			else
			temp1 *= temp2;
			sign2 = *pi;
		}
		if(sign1=='+')
		sum += temp1;
		else
		sum -= temp1;
		sign1 = sign2;
		pi++;  
	}
	printf("%d",sum);
	return 0;
}
int atoi1(char *px)
{
	int ans=0;
	while(*px<='9' && *px>='0'){
		ans = 10*ans + *px - '0';
		px++;
	}
	return ans;
}
char *change(char *px)
{
	while(*px<='9' && *px>='0'){
		px++;
	}
	return px;
}

