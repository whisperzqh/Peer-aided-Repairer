#include<stdio.h>
#include<string.h>
#include<ctype.h>

char shuru[1100]={0},shizi[1100]={0};
int shuzi[1100]={0},nshuzi[1100]={0};
char fuhao[1100]={0},nfuhao[1100]={0};
int i=0,j=0,num=0,sum=0,p=0,q=0,flag=0;

int main()
{
    fgets(shuru,1024,stdin);
    for(i=0,j=1;i<strlen(shuru);i++)
    {
        if(shuru[i]!=' ')
        {
            shizi[j++]=shuru[i];
        }
    }
    shizi[0]='x';
    for(i=1,j=0;i<strlen(shizi);i++)
    {
        if(isdigit(shizi[i]))
        {
            if(!isdigit(shizi[i-1]))
            {
                num=shizi[i]-'0';
            }
            else if(isdigit(shizi[i-1]))
            {
                num=num*10+shizi[i]-'0';
            }
            if(!isdigit(shizi[i+1]))
            {
                shuzi[j++]=num;
            }
        }
    }
    for(i=0,j=0;i<strlen(shizi);i++)
    {
        if(shizi[i]=='+'||shizi[i]=='-'||shizi[i]=='*'||shizi[i]=='/')
        {
            fuhao[j++]=shizi[i];
            flag=1;
        }
    }
    for(i=0,p=0;i<strlen(fuhao);i++)
    {
        if((fuhao[i]=='+'||fuhao[i]=='-')&&(fuhao[i-1]!='*'||fuhao[i-1]!='/'))
        {
            nshuzi[p++]=shuzi[i];
        }
        else if(fuhao[i]=='*'||fuhao[i]=='/')
        {
            num=shuzi[i];
            for(j=i;fuhao[j]=='*'||fuhao[j]=='/';j++)
            {
                if(fuhao[j]=='*')
                {
                    num=shuzi[j+1]*num;
                }
                else if(fuhao[j]=='/')
                {
                    num=num/shuzi[j+1];
                }
            }
            nshuzi[p++]=num;
            i=j;
        }
    }
    for(i=0,j=0;i<strlen(fuhao);i++)
    {
        if(fuhao[i]=='+'||fuhao[i]=='-')
        {
            nfuhao[j++]=fuhao[i];
        }
    }
    num=nshuzi[0];
    for(i=0;i<strlen(nfuhao);i++)
    {
        if(nfuhao[i]=='+')
        {
            num+=nshuzi[i+1];
        }
        else if(nfuhao[i]=='-')
        {
            num-=nshuzi[i+1];
        }
    }
    if(flag==0)
    {
        printf("%d",shuzi[0]);
        return 0;
    }
    for(i=0;i<strlen(nshuzi);i++)
    {
        printf("%d",nshuzi[i]);
    }
    puts(nfuhao);
    printf("%d",num);
    return 0;
}



