#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
 
int main()
{
    int a1,a2,a3;
    char b1,b2,b3;
    a1 = 0;
    b1 = '+';
    while(b1!='=')
    {
        scanf("%d%c",&a2,&b2);
        while(b2=='*' || b2=='/')
        {
            scanf("%d%c",&a3,&b3);
            if(b2=='*')
			{
			    a2 *= a3;
			} 
            else if(b2=='/')
			{
			    a2 /= a3;
			}     
            b2 = b3;    
        }  
        if(b1=='+')
        { 
		    a1 += a2;
    	}
        else
		{
		    a1 -= a2;
		}
        b1 = b2; 
    }
 
    printf("%d",a1);
 
 return 0;
}

