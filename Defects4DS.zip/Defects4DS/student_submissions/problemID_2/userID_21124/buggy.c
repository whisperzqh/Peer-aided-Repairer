#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char seq[100], times[60], plus[60], sub;
void deletewhite(char seq[]){
	int i, j;
	for(i = 0; i < strlen(seq); ++i){
		if(seq[i]== ' '){
			for(j = i;j < strlen(seq); ++j)
				seq[j]=seq[j+1];
		}
	}
}
int num[50];
char cut[10], counter[50];
int main(){
	gets(seq);
	int i, j = 0, loc = 0;
	deletewhite(seq);
	for(i = 0; i <strlen(seq); ++i){
		if(seq[i] == '+' || seq[i] == '-' || seq[i] == '*' || seq[i] == '/' || seq[i] == '='){
			if(loc == 0){
				strncpy(cut,seq, i );
			}
			else
			strncpy(cut, seq+(loc+1), i - loc - 1);
			num[j] = atoi(cut);
			counter[j] = seq[i];
			j++;
			loc = i;
		}
	}
	for(i = 0; i < strlen(counter); ++i){
		if(counter[i] == '*'){
			num[i+1] = num[i] * num[i+1];
		}
		else if(counter[i] == '/'){
			num[i+1] == num[i] / num[i+1];
		}
	}
	for(i = 0; i < strlen(counter); ++i){
		if(counter[i] == '+'){
			for(j = i+1; counter[j] != '+' && counter[j] != '-' && counter[j] != '='; j++);
			--j;
			num[j] = num[i] + num[j];
		}
		else if(counter[i] == '-'){
			for(j = i+1; counter[j] != '+' && counter[j] != '-' && counter[j] != '='; j++);
			--j;
			num[j] = num[i] - num[j];
		}
	}
	printf("%d", num[strlen(counter)-1]);
}

