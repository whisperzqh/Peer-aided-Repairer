#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
char arr[1000];
char s[1000];
int num[1000]={0};
char op[1000];
int calc(int a,int b,char op)
{
	switch(op)
	{
		case'+':return a+b;
		case'-':return a-b;
		case'*':return a*b;
		case'/':return a/b;
		default:return 0;
	}
}
int main()
{

	int i=0,j=0,result=0;
	gets(arr);
	for(;arr[j]!='\0';j++)
	{
		if(arr[j]!=' ')
		{
			s[i++]=arr[j];
		}
		s[i]='\0';
	}
	i=0;j=0;
	while(s[i]!='\0')
	{
		while(s[i]>='0'&&s[i]<='9')
		{
			num[j]=num[j]*10+s[i]-'0';
			i++;
		}
		if(s[i]=='=')
		{
			j++;
			break;
		}
		op[j]=s[i];
		j++;i++;
	}
	for(i=0;i<j-1;i++)
	{
		if(op[i]=='*'||op[i]=='/')
		{
			num[i+1]=calc(num[i],num[i+1],op[i]);
			num[i]=0;op[i]='+';
		}
		else continue;
	}
	result=num[0];
	for(i=1;i<j;i++)
	{
		result=calc(result,num[i],op[i-1]);	
	}
	printf("%d",result);
	return 0;
}

