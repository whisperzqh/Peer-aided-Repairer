#include<stdio.h>
#include<string.h> 
#define N 100
int count(int x, char op, int y);
int main()
{
    char s1[N]={'\0'};
	char s2[N]={'\0'};
	char op[100]={'\0'};
	char u;
 	int i,j,k=0;
	int sum=0,m=0,n=0;
	int middle[100]={0};
 	gets(s1);
    for(j=0,i=0;i<strlen(s1);i++)
    {
  		if(s1[i]!=' ')
  			s2[j++]=s1[i];
 	}
 	s2[j]='\0';
 	for(j=0;j<strlen(s2);j++)
 	{
        while(j<strlen(s2)&&s2[j]>='0'&&s2[j]<='9')
        {
         	middle[n]=middle[n]*10+s2[j]-'0';
         	j++;
  		}
  		if(j!=strlen(s2))
  		op[n++]=s2[j];
	}
 	op[n]='\0';
 	for(i=0;i<n; )
 	{
  		m=middle[i];
  		while(op[i]=='*'||op[i]=='/')
	{
  		m=count(m,op[i],middle[i+1]);
  		i++;
 	}
     sum=count(sum,u,m);
     u=op[i++];
 }
 printf("%d\n",sum);
 return 0;
 
}

int count(int x, char op, int y)
{
 	switch(op)
 	{
  		case'+': return x+y;
  		case'-': return x-y;
  		case'*': return x*y;
  		case'/': return x/y;
  		default:return x;
	}
}

