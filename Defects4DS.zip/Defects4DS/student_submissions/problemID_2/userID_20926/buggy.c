#include<stdlib.h>
#include<stdio.h>
#include<ctype.h>
int main() {
	int i,j=1,k=0,a[104]= {0},p,b[104]= {0};
	char c;
	scanf("%d",&a[0]);
	for(i=1;;) {
		scanf("%c",&c);
		if(c=='=')break;
		if(c=='*') {
			scanf("%d",&p);
			a[i-1]*=p;
		} else if(c=='/') {
			scanf("%d",&p);
			a[i-1]/=p;
		} else {
			scanf("%d",&a[i]);
			if(c=='-') {
				a[i]*=(-1);
				i++;
			}
			//else if(c=='=')break;
			else i++;
		}
	}
	for(j=0; j<=i; j++) {
		k+=a[j];
	}
	printf("%d",k);
	return 0;
}
