#include <stdio.h>
#include <string.h>
int main()
{  char a[100],b[100];
   char *c;  c=a;
   int d[100]={0};
   int i=0,k=0,t=0,ok=1,sum=0;
   gets(a);
      a[strlen(a)-1]='\0'; 
	while(*c)
	{if(*c!=' ')
		{a[i]=*c;i++;}
		c++;		
	}	
   a[i]='\0';
   for(i=0;i<strlen(a);i++)
   {    if(a[i]=='+'||a[i]=='-'||a[i]=='*'||a[i]=='/')
        {      b[k]=a[i]; 
                k++;  ok=0;
		 } 
        if(ok==1)
        d[k]=10*d[k]+a[i]-'0';
		ok=1;
   }
   for(i=0;i<k;i++)
   {    if(b[i]=='*'||b[i]=='/')
         {   if(b[i]=='*')
              d[i]=d[i]*d[i+1];
		  else     d[i]=d[i]/d[i+1];
	
		  for(t=i+1;t<k;t++)
		  {   d[t]=d[t+1];
		      b[t-1]=b[t];
		  }
		  k--;
       }
   }
   for(i=0;i<k;i++)
   {   if(b[i]=='-')
        d[i+1]=d[i]-d[i+1];
        else   d[i+1]=d[i]+d[i+1];
   }
     printf("%d",d[k]);
    return 0;
}

