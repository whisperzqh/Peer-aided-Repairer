#include<stdio.h>
#include<string.h>

int  calculate(int a,int b,char c){
	switch(c){
		case '+':
		return a+b;
		break;
		case '-':
		return a-b;
		break;
		case '*':
		return a*b;
		break;
		case '/':
		return a/b;
		break;
	}
}
void fun(char *s){
	int begin=0,end=0;
	while(s[end]!='\0'){
		if(s[end]!=' '){
			s[begin++]=s[end++];
		}
		else end++;
	}
	s[begin]='\0';
}
int main()
{
	char a[10000],y[10000];
	int k=1,i,x[10000];
	gets(a);
	fun(a);
	x[1]=0;
	for(i=0;a[i]!='\0';i++){
		if(a[i]>='0'&&a[i]<='9'){
			x[k]=10*x[k]+a[i]-'0';
		}
		else {
			y[k]=a[i];
			k=k+1;
			x[k]=0; 
		}
	} 
	k=1;
	while(y[k]!='='){
		if(y[k]=='*' || y[k]=='/'){
		x[k]=calculate(x[k],x[k+1],y[k]);
		i=1;
		y[k]=y[k+1];
		while(y[k+i]!='='){
		x[k+i]=x[(k+i)+1];
		y[k+i]=y[k+i+1];
		i++;	
		}
	}
	else k++;
	}
	while(y[1]!='='){
		x[1]=calculate(x[1],x[2],y[1]);
		i=1;
		y[1]=y[2];
		while(y[i+1]!='='){
		x[i+1]=x[i+2];
		y[i+1]=y[i+2];
		i++;	
		}
	}
	printf("%d",x[1]);
	return 0;
}

