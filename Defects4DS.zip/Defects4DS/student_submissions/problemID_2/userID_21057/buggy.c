#include <stdio.h>
#include <string.h>
#include <ctype.h>


int is_right(char c)
{
    if(c=='/'||c=='*'||c=='+'||c=='-'||c=='=')return 1;
    return 0;
}

int main()
{
    char arr[2000]="";
    gets(arr);
    int num_1[200]={0},num_2[200]={1} ; //
    int i;
    int j=0;
    int turenum=0;
    for(i=0;i<strlen(arr);i++){
            if(isdigit(arr[i])){
                turenum=turenum*10+arr[i]-'0';
            }
            if(!is_right(arr[i]))continue;

            else {
                num_1[j]=turenum;
                j++;
                turenum=0;
                num_1[j]=arr[i]-400;
                j++;
            }
    }
    for(i=0;i<=200;i++)num_2[i]=1;
    i=0;
    while(num_1[i]!=('='-400))i++;  //
    int q=0;
    turenum=0;
    for(j=0;j<=i;j++)
    {
        if(num_1[j]>=0)turenum=num_1[j];
        else if(num_1[j]=='*'-400)turenum=turenum*num_1[++j];
        else if(num_1[j]=='/'-400)turenum=turenum/num_1[++j];
        else if(num_1[j]=='+'-400||num_1[j]=='='-400){
            num_2[q]=turenum*num_2[q];
            q++;
            turenum=0;
        }
        else if(num_1[j]=='-'-400){
            num_2[q]=turenum*num_2[q];
            num_2[++q]=-1;
            turenum=0;
        }
    }

    int sum=0;
    for(i=0;i<q;i++)sum+=num_2[i];
    return sum;
}

