#include<stdio.h>
#include<string.h>
int num(char p,int a,int b)
{
	if(p=='*') return a*b;
	if(p=='-') return a-b;
	if(p=='+') return a+b;
	if(p=='/') return a/b;
}
int main()
{
	char s[100000],line[100000];	
	int i=0,j=0,k,p,lenl,a1=0,a2=0,a3=0;
	gets(s);
	for(;s[i]!='\0';i++)
		if(s[i]!=32)
			line[j++]=s[i];
	lenl=strlen(line);
	for(i=0;i<lenl;i++)
	{
		if(line[i]>'9' || line[i]<'0')
		{
			break;
		}
	}
	for(k=0;k<i;k++)
	{
		a1*=10;
		a1+=line[k]-'0';
	}
	for(j=i+1;j<lenl;j++)
	{
		if(line[j]>'9' || line[j]<'0')
		{
			for(k=i+1;k<j;k++)
			{
				a2*=10;
				a2+=line[k]-'0';
			}
			if(line[i]=='*' || line[i]=='/')
			{
				a1=num(line[i],a1,a2);
				a2=0;
				i=j;
			}
			else if(line[j]!='*' && line[j]!='/')
			{
				a1=num(line[i],a1,a2);
				a2=0;
				i=j;
			}
			else if(line[j]=='*' || line[j]=='/')
			{
				for(p=j+1;p<lenl;p++)
				{
					if(line[p]>'9' || line[p]<'0')
					{
						for(k=j+1;k<p;k++)
						{
							a3*=10;
							a3+=line[k]-'0';
						}
						a2=num(line[j],a2,a3);
						j=p;
						a3=0;
						if(line[j]!='*' && line[j]!='/')
						{
							a1=num(line[i],a1,a2);
							a2=0;
							i=j;
							break;
						}
					}
				}
			}
		}
	}
	if(a2!=0)
		printf("%d",num(line[i],a1,a2));
	else
		printf("%d",a1);
	return 0;
} 

