#include <stdio.h>

int main(){
	int n,i,k,j,ch;
	int a[10];
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		a[i] = i;
	}
	while(1){
		k = 0;
		for(i = n-1;i>=1;i--){
			if(a[i] < a[i+1]){
				k = i;
				break;}
		}
		if(k == 0){
			break;
		}
		for(i =1;i<=n;i++)
			printf("%d",a[i]);
		printf("\n");
		for(i = n;i>=k;i--){
			if(a[i]>a[k]){
				j = i;
				break;
			}
		}
		ch = a[k];
		a[k] = a[i];
		a[i] = ch;
		for(i = k+1,j=n;i<j;i++,j--){
			ch = a[i];
			a[i] = a[j];
			a[j] = ch;
		}
	}
	for(i =1;i<=n;i++)
			printf("%d",a[i]);
	return 0;
} 

