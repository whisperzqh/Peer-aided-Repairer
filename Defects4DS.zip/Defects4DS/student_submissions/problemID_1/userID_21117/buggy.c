#include <stdio.h>
#define MAX 10

int main ()
{
	int n;
	scanf ("%d", &n);
	int init=n;	
	int temp;
	int last;
	int a[10]={0};
	int i;
	for(i=0;i<n;i++)
	{
		a[i]=i+1;
	}
	printarray(a,n);
	while(init!=0)
	{
		printarray(a,n);
		init=getinit(a,n);
		last=getlast(a,init,n);
		temp=a[init-1];
		a[init-1]=a[last-1];
		a[last-1]=temp;
		reverse(a+init,a+n-1);
		
	}	
	return 0;
}


int getinit(int*dest,int n)
{
	int i;
	for(i=n-1;i>=1;i--)
	{
		if(*(dest+i)>*(dest+i-1))
			break;
	}
	return i;
}//

int getlast(int*dest,int init,int n)
{
	int i;
	for(i=init-1;i<n;i++)
	{
		if(dest[i]<dest[init-1])
			break;
	}
	return i;
}//

void printarray(int*dest,int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d ",dest[i]);
	}
	printf("\n");
	return ;
}

void reverse(int*st,int*ed)
{
	int temp;
	while(st<ed)
	{
		temp=*st;
		*st=*ed;
		*ed=temp;
		st++;ed--;
	}
}

