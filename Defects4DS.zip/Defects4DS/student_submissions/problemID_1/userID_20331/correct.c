#include<stdio.h>
#include<string.h>
char s[20],t[20]; 
void rank(int,int,int); 				  
int main ()
{
	int n;
	scanf("%d",&n);	
	rank(0,n,n);	
	return 0;
}
void rank(int a, int b,int n)
{
	int i,j;
	if(b==0){ 
		for(j=0;j<strlen(t);j++)
			printf("%c ",t[j]);
			printf("\n");
	}
	for(i=1;i<=n;i++)
		if(s[i]==0){
			s[i]=1; 	
			t[a]='0'+i;  
			rank(a+1,b-1,n); 	
			s[i]=0;
		}
		
}


