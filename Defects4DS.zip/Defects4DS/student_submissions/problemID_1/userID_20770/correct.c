#include <stdio.h>
#include <string.h>
#define maxn 1000

int n;
int a[maxn];
int test[maxn];

int dfs(int len)
{
    int i, j;
    if (len == n)
    {
        for (i = 0; i < n; i++)
            printf("%d ", a[i]);
        printf("\n");
    }

    for (j = 1; j <= n; j++)
    {
        if (test[j] == 0)
        {
            a[len++] = j;
            test[j] = 1;
            dfs(len);
            len--;
            test[j] = 0;
        }
    }
}

int main()
{
    scanf("%d", &n);
    dfs(0);
    return 0;
}

