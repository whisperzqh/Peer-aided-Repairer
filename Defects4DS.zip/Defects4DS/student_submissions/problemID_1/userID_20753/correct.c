#include<stdio.h>
int wuhu(int*p,int n)
{
	int i=n-1,min=10,j=0,k=0,q;
	for(i=n-1;i>0;i--)
	{
		if(*(p+i)>*(p+i-1))
		{
			k=1;break;
		}
	}
    for(q=n-1;q>i-1;q--)
	{
		if(*(p+q)<min&&*(p+q)>*(p+i-1))
		{
		    min=*(p+q);
		    j=q;}
	}
	if(k==1){
	    *(p+j)=*(p+i-1);
	    *(p+i-1)=min;
	    for(j=n-1;i<j;i++,j--)
	    {
	    	min=*(p+i);
	    	*(p+i)=*(p+j);
	    	*(p+j)=min;
		}
		return 1;
	}
	else if(k==0)
	return 0;
}
int main()
{
	int n,i;
	scanf("%d",&n);
	int line[10]={1,2,3,4,5,6,7,8,9,10};
	int*p=line;
	for(i=0;i<n;i++)
	    printf("%d ",line[i]);
	printf("\n");
	while(wuhu(p,n)==1)
	{
		for(i=0;i<n;i++)
		printf("%d ",line[i]);
		printf("\n");
	}
	return 0;
}

