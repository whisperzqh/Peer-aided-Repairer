#include <stdio.h>
int flag[11]={0};
int ans[11];
void func(int index, int n){
	int i, j;
	if(index==n){
		for(j=0;j<n;j++)
			printf("%d ",ans[j]);
		printf("\n");
		return;
	}
	for(i=1;i<=n;i++){
		if(flag[i]==0){
			flag[i] = 1;
			ans[index] = i;
			func(index+1,n);
			flag[i] = 0;
			ans[index] = 0;
		}
	}
	return;
}

int main()
{
	int n;
	scanf("%d",&n);
	func(0,n);
	return 0;
}

