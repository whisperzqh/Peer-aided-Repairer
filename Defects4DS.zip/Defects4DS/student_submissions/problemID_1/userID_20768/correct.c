#include<stdio.h>
#include<string.h>
void pailie(int i);
int o[1000]={0};int oo[1000]={0};int a;
int main()                             //
{
	
	scanf("%d",&a);
	pailie(1);
	
}

void pailie(int i)          // 
{
	int m=0,n=1;
	if(i>a)
	{
		for(m=1;m<=a;m++)
		{
			printf("%d ",o[m]);
		}
		printf("\n");
	}
	
	for(m=1;m<=a;m++)
	{
		if(oo[m]==0)
		{
			o[i]=m;
			oo[m]++;
			pailie(i+1);
			oo[m]=0;
		}
	}
}

