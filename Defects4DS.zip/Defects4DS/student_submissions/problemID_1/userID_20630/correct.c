#include<stdio.h>
#include<string.h>
int ans[11];
int flag[11];
int pos;
void fun(int n,int pos)
{
	int i;
	if(pos==n)
	{
		pri(ans,n);
	}
	for(i=1;i<=n;i++)
	{
		if(flag[i-1]==0)
		{
			ans[pos]=i;
			flag[i-1]=-1;
			fun(n,pos+1);
			flag[i-1]=0;
			ans[pos]=0;
		}
	}
}
void pri(int ans[],int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d ",ans[i]);
	}
	printf("\n");
}
int main()
{
	int n;
	scanf("%d",&n);
	fun(n,pos);
	return 0;
}

