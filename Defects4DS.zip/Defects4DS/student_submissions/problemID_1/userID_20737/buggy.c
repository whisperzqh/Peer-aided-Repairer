#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define _fl float
#define _db double
#define _ll long long
#define _udb unsigned double
#define _ull unsigned long long

#define _fr(i, a, b) for(i = a; i <= b; i++)
#define _fr2(i, a, b) for(i = a; i >= b; i--)

#define MaxUnsignedInt 4294967295
#define MaxInt 2147483647
#define MinInt -2147483648
#define MaxUnsignedLong 4294967295
#define MaxLong 2147483647
#define MinLong -2147483648
#define MaxLongLong 9223372036854775807
#define MinLongLong -9223372036854775808
#define MaxUnsignedLongLong 18446744073709551615
#define PI 3.1415926
#define eps 1e-6
void zuoyong(int index,int n);
int flag[11],ans[11];
int main(){
	int n;
	scanf("%d",&n);
	memset(flag,0,sizeof(flag));
	zuoyong(0,n);
	return 0; 
}


void zuoyong(int index,int n){
	int q,i;
	if(index==n){
		for(q=0;q<n;q++){
			printf("%d",ans[q]);}
		printf("\n");
		
		return;
	}
	for(i=1;i<=n;i++){
		if(flag[i]==0){
			ans[index]=i ;
			flag[i]=1;
			zuoyong(index+1,n);
			flag[i]=0;
			ans[index]=0;
		}
	}
	return;
}

