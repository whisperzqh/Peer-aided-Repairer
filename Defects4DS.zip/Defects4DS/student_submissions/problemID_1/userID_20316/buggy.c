#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int n,a[30],b[30];
void sk(int j)
{
    int i;
    if(j>n)
    {
    for(j=1;j<=n;j++)
        printf("%d",a[j]);
    printf("\n");
    return;
    }
    
   for(i=1;i<=n;i++)
    {if(b[i]==0)
        {
            a[j]=i;b[i]=1;
            sk(j+1);
            b[i]=0;}
    }
  return;
}
int main()
{
    scanf("%d",&n);
    sk(1);
    return 0;
}

