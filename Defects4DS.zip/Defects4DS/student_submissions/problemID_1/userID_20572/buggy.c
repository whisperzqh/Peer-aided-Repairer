#include <stdio.h>
#include <stdlib.h>
void giao(int a[],int A);
void md(int a[],int i,int A);
int main()
{   
    int A,i,a[15];
    scanf("%d",&A);
    if(A==1)
    {  printf("1");
       return 0;
	}
	for(i=1;i<=A;i++)
	{a[i]=i;
	 printf("%d",a[i]);
	}
	printf("\n");
	giao(a,A);
	return 0;
} 
void giao(int a[],int A)
{   int i=A-1;
    while(a[i]>a[i+1])
    { i--;
       if(i==0)
        break;
	}
    if(i==0)
    {return ;
	}
    else {  md(a,i,A);
            giao(a,A);
	     }
   
}
void md(int a[],int i,int A)
{   int t=i+1,min=a[t],j;
    for(;t<=A;t++)
    {  
       if(a[t]>a[i])	
	   {if(a[t]<min)
        min=a[t];
	   }
	}
	for(t=i+1;t<=A;t++)
	{   if(a[t]==min)
	    break;
	}
	a[t]=a[i];
	a[i]=min;
	for(i=i+1,j=A;i<j;i++,j--)
	{  min=a[i];
	   a[i]=a[j];
	   a[j]=min;
	}
		for(i=1;i<=A;i++)
	printf("%d",a[i]);
	printf("\n");

     
}

