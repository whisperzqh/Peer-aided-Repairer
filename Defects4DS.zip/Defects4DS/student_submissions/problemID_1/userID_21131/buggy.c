#include<stdio.h>
int n;
int t[10]={1,2,3,4,5,6,7,8,9,10};
void out()
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d",t[i]);
	}
	printf("\n");
	return;
}
void swap(int a,int b)
{
	int c;
	c=t[a];
	t[a]=t[b];
	t[b]=c;
}
void s(int start)
{
	int i;
	if(start==n)
	{
		out();
		return;
	}
	s(start+1);
	for(i=0;i+start<n;i++)
	{
		swap(start+i,start-1);
		s(start+1);
	} 
	for(i=n-start-1;i>=0;i--)
	{
		swap(start+i,start-1);
	}
}
int main()
{
	scanf("%d",&n);
	int j;
	s(1);
	return 0;
}




