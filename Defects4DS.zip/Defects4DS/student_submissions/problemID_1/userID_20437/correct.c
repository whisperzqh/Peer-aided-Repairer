#include<stdio.h>
#include<math.h>
#include<string.h>
int jc(int a)
{
    int i,b=1;
    for(i=a;i>=1;i--)
        b=b*i;
    return b;
}
int main()
{int i,sum=1,n,j,x,y,k,a[11],l,b[11],m,c[11];
scanf("%d",&n);
sum =jc(n);
for(i=0;i<=sum-1;i++)
{
    for(j=1;j<=n;j++)
    {
        a[j]=0;
        b[j]=j;
    }
    x=i;
    for(j=1;j<=n;j++)
    {
        y=x/jc(n-j)+1;
        x=x%jc(n-j);
        for(l=1;l<=j-1;l++)
             b[a[l]]=0;
        for(l=1,m=1;l<=n;l++)
        {
            if(b[l]!=0)
                c[m++]=b[l];
        }
        a[j]=c[y];
        printf("%d ",a[j]);
    }
    printf("\n");
}
return 0;
}

