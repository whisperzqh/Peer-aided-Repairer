#include<stdio.h>
void pro(int x,int y);
int st[15],ju[15]={0};
int main()
{
	int n;
	scanf("%d",&n);
	pro(1,n);
	return 0;
}
void pro(int x,int y)
{
	int i;
	if(x>y)
	{
		for(i=1;i<=y;i++)
			printf("%d ",st[i]);
		printf("\n");
	}
	else
	{
		for(i=1;i<=y;i++)
		{		
			if(ju[x]==0)
			{
				ju[i]=1;
				st[x]=i;
				pro(x+1,y);
				ju[i]=0;	}
		}
	}
	return ;
}

