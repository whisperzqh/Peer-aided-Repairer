#include<stdio.h>
#include<string.h>

int N,num[12]={0};

void Puts(int *p)
{
	while(*p!=0)
	{
		printf("%d ",*p);
		p++;
	}
	printf("\n");
}
void exchange(int *p1,int *p2)
{
	int temp;
	temp = *p1;
	*p1 = *p2;
	*p2 = temp;
}
void Per(int k)
{
/*	if(k == 2)
	{
		exchange(num[3],nunm[4]);
		Puts(num);
		exchange(num[3],nunm[4]);
		Puts(num);
	}
	else
	{
		exchange(num[k-1],num[k-2]);
		
		Per(k-1);
		Puts(num);
	}*/
	int i,j;
	if(k == 2)
	{
		Puts(num);
		exchange(&num[N-1],&num[N-2]);
		Puts(num);
		exchange(&num[N-1],&num[N-2]);
		return;
	}
	else 
	{
		for(j = N-k;j<N;j++)
		{
			for(i = j; i>N-k;i--)
			{
				exchange(&num[i],&num[i-1]);
			}
			Per(k-1);
			for(i = N-k;i<j;i++)
			{
				exchange(&num[i],&num[i+1]);
			}
		}
		
	}
	
}
int main()
{
	int i;
	scanf("%d",&N);
	
	for(i = 0;i <N ;i++)
	{
		num[i] = i+1;
	}
	if(N == 1)
	{
		printf("1\n");
	}
	else
	{
		Per(N);
	}
	return 0;
}

