#include<stdio.h>
int s[20]={0,1,2,3,4,5,6,7,8,9,10};
int main()
{
    int n,i;
    scanf("%d",&n);
    f(1,n);
    if(n==1)
        printf("1\n");
}
void f(int a,int b)
{
    int i,tmp,j;
    if(a+1==b)
    {
        print(b);
        swap(&s[b-1],&s[b]);
        print(b);
        swap(&s[b-1],&s[b]);
    }
    else
    {
        for(i=a;i<=b;i++)
        {
            tmp=s[i];
            for(j=i;j>a;j--)
            {
                s[j]=s[j-1];
            }
            s[a]=tmp;
            f(a+1,b);
            tmp=s[a];
            for(j=a;j<i;j++)
            {
                s[j]=s[j+1];
            }
            s[i]=tmp;
        }
    }


}
void swap(int*a,int*b)
{
    int tmp;
    tmp=*a;
    *a=*b;
    *b=tmp;
}
void print(int b)
{
    int i;
    for(i=1;i<=b;i++)
    {
        printf("%d ",s[i]);
    }
    printf("\n");
}

