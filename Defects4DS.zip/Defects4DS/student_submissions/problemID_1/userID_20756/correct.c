#include <stdio.h>
#include <string.h> 
#include <math.h>
int a[11]={0},flag[11]={0},n;
void pai(int num)
{
	int i;
	if(num==n+1)
	{
		for(i=1;i<=n;i++)
		{
			printf("%d ",a[i]);
		}
		printf("\n");
	}
	for(i=1;i<=n;i++)
	{
		if(flag[i]==0)
		{
			a[num]=i;
			flag[i]=1;
			pai(num+1);
			flag[i]=0;
		}
	}
}
int main()
{
    scanf("%d",&n);
	pai(1);	
	
}

