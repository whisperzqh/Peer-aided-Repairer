#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#define N 100000
#define ULL unsigned LL
#define LL long long
#define INF 0x7f7f7f7f
int n=10, top;
int a[16],b[16];
void dfsp(int x)
{
	int i;
	if(x==n)
	{
		for(i=0;i<n;i++)
		printf("%d ", a[i]);
		printf("\n");
		return;
	}
	else
	{
		for(i=0;i<n;i++)
		{
			if(b[i]==0)
			{
				a[top++]=i+1;
				b[i]=1;
				dfsp(x+1);
				b[i]=0;
				top--;
			}
		}
	}
	
}
int main()
{
    scanf("%d", &n);
    dfsp(0);
    return 0;
}


