#include<stdio.h>
void allper(int);
int number[100],a[100],n;
int main()
{
	scanf("%d",&n);
	allper(1);
	return 0;
}
void allper(int step)
{
	int i;
	if(step==n+1)
	{
		for(i=1;i<=n;i++)
		printf("%d ",a[i]);
		printf("\n");
		return;
	}
	for(i=1;i<=n;i++)
	{
		if(number[i]==1)
		{
			a[step]=i;
			number[i]=0;
			allper(step+1);
			number[i]=1;
		}
	}
	return;
}

