#include <stdio.h>
int a[15];
int b[15];
int n;
void fprint();
int count(int);
int findsmall();
void invert(int);
void findsmallest(int);

int main() 
{
	int i,small;
	scanf("%d",&n);
	count(n);
	for(i=0;i<n;i++) a[i] = i + 1;
	fprint();
	
	for(i=0;i<b[n]-1;i++)
	{
		small = findsmall();
	    
		findsmallest(small);
		
		invert(small);
		fprint();
	}
	return 0;
}
void fprint()
{
	int i;
	for(i=0;i<n-1;i++)
	printf("%d ",a[i]);
	printf("%d\n",a[i]);
}
int count(int n)
{
	int i;
	b[0] = 1;
	for(i=1;i<=n;i++)
	b[i] = b[i-1]*i;
	return b[n];
}
int findsmall()
{
	int i,temp;
	for(i=n-2;i>=0;i--)
	{
		if(a[i]<a[i+1])
		{
			
			return i+1; 
	}
	}
}
void invert(int s)
{
	int i,j,temp;
	for(i=s,j=n-1;i<j;i++,j--)
	{
		temp = a[i];
		a[i] = a[j];
		a[j] = temp;
	}
}
void findsmallest(int s)
{
	int i,min=500,temp,smallest;
	for(i=s;i<n;i++)
	{   
		if((a[i]<min)&&(a[i]>a[s-1]))
		{
			min = a[i];
			smallest = i;
			
		}
	}
	temp = a[s-1];
	a[s-1] = a[smallest];
	a[smallest] = temp;
}

