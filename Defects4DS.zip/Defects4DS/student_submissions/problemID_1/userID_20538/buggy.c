#include<stdio.h>
int plus(int a[], int n)
{
	int i;
	a[n]++;
	for(i = n ; i >= 1 ; i--){
		if(a[i] > n){
			a[i] = 0; a[i-1] ++;
		}
	}
	int flag = 0;
	for(i = 1 ; i <= n ; i++)
	{
		if(a[i] != 0){
			flag = 1;
			break;
		}
	}
	if(flag == 1)  return 1;
	else return 0;
}
int judge( int a[] , int n)
{
	int flag[12] = {0,0,0,0,0,0,0,0,0,0,0,0}, i;
	for(i = 1 ; i<= n ; i ++)
	{
		if(a[i] == 0) 	return 0;
		else if(flag[a[i]] == 0)
			flag[a[i]] ++;
		else return 0;
	}
	return 1;
}
int main()
{
	int n ,i ,a[55];
	scanf("%d",&n);
	for(i=1 ; i<= n ; i++)	
		a[i] = 0;
	
	while( plus(a , n) ){
	//	printf("jinwhile\n");
		if( judge(a , n) ){
	//		printf("jinjudge\n");
			for(i = 1 ; i <= n ; i++)	
				printf("%d",a[i]);
				
			printf("\n");
		}	
	}
	return 0;	
}


