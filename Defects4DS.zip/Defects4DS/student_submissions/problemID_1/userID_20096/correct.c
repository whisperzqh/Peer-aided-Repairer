#include <stdio.h>

int a[10], book[10];
int N; 

void dfs(int step)
{
	int i;
	
	if(step == N + 1)
	{
		for(i = 1; i <= N; i++)
			printf("%d ", a[i]);
		printf("\n");
		
		return;
	}
	for(i = 1; i <= N; i++)
	{
		if(book[i] == 0)
		{
			a[step] = i;
			book[i] = 1;
			
			dfs(step + 1);
			book[i] = 0;
		}
	}
	
	return;
}
int main()
{
	scanf("%d", &N);
	dfs(1);
	
	return 0;
}

