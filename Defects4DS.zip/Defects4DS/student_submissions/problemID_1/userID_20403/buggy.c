#include<stdio.h>
int a[20],cnt,vis[20];
int N;
void dfs(int num)
{
    int j;
    if(num==N)
    {
        for(j=0;j<N;j++)
            printf("%d ",a[j]);
        printf("\n");
        return;
    }
    else
    {
        for(j=1;j<=N;j++)
        {
            if(!vis[j])
            {a[cnt++]=j;
            vis[j]=1;
            dfs(num+1);
            vis[j]=0;}
        }
    }
}
int main()
{
    int i,k;
    scanf("%d",&N);
    for(i=1;i<=N;i++)
    {
        for(k=1;k<=10;k++)
            vis[k]=0;
            cnt=0;
        a[cnt++]=i;
        vis[i]=1;
        dfs(1);
        vis[i]=0;
    }
return 0;

 }

