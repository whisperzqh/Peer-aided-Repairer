#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>

void move(int s[], int lg, int bf, int af)
{
	int res[lg + 20], i, j;
	for (i = 0, j = 0; i < lg; i++, j++)
	{
		if(i == bf)
		{
			j--;
			continue;
		}
		else if(j == af)
		{
			res[j] = s[bf];
			i--;
			continue;
		}
		res[j] = s[i];
	}
	res[af] = s[bf];
	memcpy(s, res, lg * sizeof(int));
}

void arr(int gr[], int l, int r)
{
	int i, j;
	if(l == r)
	{
		for (j = 0; j <= r; j++)
		{
			printf("%d ", gr[j]);
		}
		printf("\n");
	}
	else
	{
		for (i = l; i <= r; i++)
		{
			move (gr, r + 1, i, l);
			arr(gr, l + 1, r);
			move (gr, r + 1, l, i);
		}
	}
}

int main()
{
	int s[]= {1, 2, 3, 4, 5};
	arr(s, 0, 4);
    return 0;
}


