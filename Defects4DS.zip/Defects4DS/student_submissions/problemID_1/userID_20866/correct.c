#include <stdio.h>
#include <string.h>
//
 
char array[20];
int mark[20]={0};
int N;

void rank(int a,int b);

int main(){
	scanf("%d",&N);
	rank(0,N);
	
	return 0;	
}

void rank(int a,int b){
	if(!b){
		array[a]='\0';
		for(int j=0;j<N-1;j++){
			printf("%c",array[j]);
			printf(" ");
			}
		printf("%c\n",array[N-1]);
		return;
	}
	for(int i=1;i<=N;i++){
		if(!mark[i]){
			mark[i] = 1;
			array[a]=i+'0';
			rank(a+1,b-1);
			mark[i]=0;
		}
	}
}

