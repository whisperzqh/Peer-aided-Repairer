#include<stdio.h>
#include<string.h>
int N;
char sort[15];
int use[15] = {0};
void fun_sort(int pos,int left);
int main()
{
	scanf("%d",&N);
	fun_sort(0,N);
	return 0;
}
void fun_sort(int pos,int left){
	int i,j;
	j = pos + 1;
	if(left == 0){
		sort[2*N] = '\0';
		puts(sort);
		return ;
	}
	for(i = 1;i <= N;i++){
		if(use[i] == 0){
			sort[pos] = i + '0';
			sort[j] = ' '; 
			use[i] = 1;
			fun_sort(pos + 2,left - 1);
			use[i] = 0;
		}
	}
	
}



