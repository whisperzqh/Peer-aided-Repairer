#include<stdio.h>
#include<string.h>
int N;
char sort[15];
int use[15] = {0};
void fun_sort(int pos,int left);
int main()
{
	int i,j,k;
	scanf("%d",&N);
	fun_sort(0,N);
	return 0;
}
void fun_sort(int pos,int left){
	int i,j,k;
	if(left == 0){
		sort[N] = '\0';
		puts(sort);
		return ;
	}
	for(i = 1;i <= N;i++){
		if(use[i] == 0){
			sort[pos] = i + '0';
			use[i] = 1;
			fun_sort(pos + 1,left - 1);
			use[i] = 0;
		}
	}
	
}



