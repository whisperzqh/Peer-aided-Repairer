#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void*a,const void*b){
	return *((int*)a)-*((int*)b);
}
void swap(int *a,int *b){
	int tem;
	tem=*a;
	*a=*b;*b=tem;
}
void printN(int a[],int l){
	int i;
	for(i=0;i<l-1;i++)
		printf("%d ",a[i]);
	printf("%d\n",a[l-1]);
}
void quan(int a[],int i,int j){
	int k;
	if(i==j)
	printN(a,j+1);
	else{
		for(k=i;k<=j;k++){
			swap(&a[i],&a[k]);
			qsort(&a[i+1],j-i+1,sizeof(int),comp);
			quan(a,i+1,j);
			qsort(&a[i+1],j-i+1,sizeof(int),comp);
			swap(&a[i],&a[k]);
		}
	}
}
int main()
{
	int N,i,a[10]={1,2,3,4,5,6,7,8,9,10};
	scanf("%d",&N);
	quan(a,0,N-1);
	return 0;
}

