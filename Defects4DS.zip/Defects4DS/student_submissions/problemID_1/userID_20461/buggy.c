#include<stdio.h>
int bj_ini=0;
int find_next(int *a,int len);
int main()
{
	int n,i,a[12];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		a[i]=i+1;
	}
	find_next(a,n);
}
int find_next(int *a, int len)
{
    int pos,i,j,bj=0,tmp,x,k;
	if(bj_ini==0){
		for(i=0;i<len;i++){
			printf("%d",a[i]);
		}
		bj_ini=1;
		printf("\n");
		find_next(a,len);
	}else{
		for(i=len-1;i>0;i--){
			if(a[i]>a[i-1]){
				pos=i-1;
				for(j=len-1;j>=i;j--){
					if(a[j]>a[pos]){
					    tmp=a[j];
						a[j]=a[pos];
						a[pos]=tmp;
						for(x=0;x<(len-i)/2;x++){
							tmp=a[i+x];
							a[i+x]=a[len-1-x];
							a[len-x-1]=tmp;
						}
						for(k=0;k<len;k++){
							printf("%d",a[k]);
						}
						bj=1;
						break;
					}
				}
				if(bj==1){
					break;
				}  
			}
		}
		printf("\n");
		if(bj==0){
			return 0;
		}else{
			find_next(a,len);
		}
	}
}

