#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>





int jie_cheng(int sum_)
{
	int j, moti = sum_;
	for(j = sum_ - 1; j >= 1 ; j--)
	{
		moti = moti * j;
	}
	return moti;
}

void output(int a1[] , int malti , int sum)
{
	int flag = 1;
  while(flag < malti)
  {
  	int i = sum;
  	int j = 0;
  	for(i = sum ; i >= 1 ; i--)
  	
	{
		if(a1[i - 1] < a1[i])
		{
			j = i - 1;
			break;
		}
	}
	int n = j + 1;
	int min = a1[j + 1] ;
	int t = 0;
	
	for(i = j + 1 ; i <= sum ; i++)
	{
		if((a1[i] > a1[j])&&(a1[i] < min))
		{
			min = a1[i];
			n = i;
		}
	}
	int temp;
	temp = a1[j];
	a1[j] = a1[n];
	a1[n] = temp;
	if(sum - j != 1)
	{
		for(i = 1; i <= (sum - j)/2 ;i++)
      {
    	temp = a1[i + j];
    	a1[i + j]  = a1[sum + 1 - i];
    	a1[sum + 1 - i] = temp;
	  }
	}
	else if(sum - j == 1)
	{
		temp = a1[j + 1];
		a1[j + 1] = a1[sum];
		a1[sum] = temp;
	}
	for(i = 1 ; i <= sum ; i ++)
	{
		printf("%d ",a1[i]);
		if((i == sum)&&(flag!= malti))
		{
			printf("\n");
		}
	}
	flag ++;
  }
	
	
}



int main()
{
	int sum,a[100] = {0}; 
	int i =1;
	scanf("%d" , &sum);// 
	for(i = 1;i <= sum ; i ++)
	{
		a[i] = i;
		printf("%d ",a[i]);
		if(i == sum)
		printf("\n");
	}
	int malti;
	malti = jie_cheng(sum);
	output(a , malti ,sum);
	
	
	
	
	
	
	
	
	
}

