#include <stdio.h>
#include <string.h>
int number[10]={1,2,3,4,5,6,7,8,9,10};
int s;
void swap(int* a,int* b)
{
	int t;
	t=*a;
	*a = *b;
	*b = t;
}

void full(int a[],int n)
{
	int i,k;
	if(n==1)
	{
		for(i=0;i<s;i++)
		{
			printf("%d ",number[i]);
		}
		printf("\n");
	}else{
		for(i=0;i<n;i++){
			swap(&a[0],&a[i]);
			full(a+1,n-1);
		}
		k=a[0];
		for(i=0;i<n-1;i++)
		{
			a[i] = a[i+1];
		}
		a[i]=k;
	}
}

int main()
{
	scanf("%d",&s);
	full(number,s);
	return 0;
}


