#include<stdio.h>
#include<string.h>
int team[10]={1,2,3,4,5,6,7,8,9,10};
void swap(int team[],int a,int b)
{
	int c=team[b];
	for(b;b>a;b--)
	team[b]=team[b-1];
	team[a]=c;
}
void print(int team[],int n)
{
	int i;
	for(i=0;i<n;i++)
	printf("%d ",team[i]);
	printf("\n");
}
void back(int team[],int i,int j)
{
	int c;
	c=team[i];
	for(i;i<j;i++)
	team[i]=team[i+1];
	team[j]=c;
}
void huan(int team[],int l,int r)
{
	if(l==r)
	print(team,r+1);
	else
	{
		int i;
		for(i=l;i<=r;i++)
		{
			swap(team,l,i);
			huan(team,l+1,r);
			back(team,l,i);
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	huan(team,0,n-1);
	return 0;
 } 

