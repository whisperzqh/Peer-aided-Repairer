#include<stdio.h>
#include<stdlib.h>

int used[11]={0};
int num[11]={0};
int max;

void full_sort(int n){
	int i;
	if (n==0){
		for (i=1;i<=max;i++){
			printf("%d",num[i]);	
		}
		printf("\n");
		return ;
	}
	for (i=1;i<=max;i++){
		if (used[i]==0){
			used[i]=1;
			num[max+1-n]=i;
			full_sort(n-1);
			used[i]=0;
		}
	}
}
int main(){
	int n;
	scanf("%d",&n);
	max=n;
	full_sort(n);
	return 0;
}

