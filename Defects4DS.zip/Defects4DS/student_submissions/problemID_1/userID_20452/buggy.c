#include<stdio.h>
int a[10],mark[10]={0};
int n,i;
void f(int step) {
    if(step==n){
        for(i=0;i<n;i++){
            printf("%d ",a[i]);
        }
        printf("\n");
        return;
    }
    for(i=0;i<n;i++){
        if(mark[i]==0){
            a[step]=i+1;
            mark[i]=1;
            f(step+1);
            mark[i]=0;
        }
    }
}
int main(){
    scanf("%d",&n);
    f(0);
    return 0;
}

