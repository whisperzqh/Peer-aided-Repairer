#include<stdio.h>
int biao[11],num[10];
void pai(int n,int N){
	int i,j;
	if(n==N){
		for(i=1;i<=N-1;i++)
			printf("%d",num[i]);
		for(i=1;i<=N-1;i++)
			biao[num[i]]=1;
		for(i=1;i<=N;i++)
			if(biao[i]==0)
				printf("%d",i);
		printf("\n");
		return;
	}
	for(i=1;i<=N;i++){
		//printf("i:%d n:%d ",i,n);
		for(j=1;j<=n-1;j++)
			biao[num[j]]=1;
		if(biao[i]==0){
			biao[i]=1;
			num[n]=i;
			pai(n+1,N);
			//printf("yes\n");
			for(j=1;j<=N;j++)
				biao[j]=0;
		}
	}
	return;
}
int main(){
	int N;
	scanf("%d",&N);
	pai(1,N);
	return 0;
}

