#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
int cun[10]={0},flag[10]={0};
int N; 
print(int n,int cun[]){
	int i,j;
	if(n==N+1)
	{
		for(i=1;i<=N;i++)
		{
			printf("%d",cun[i]);
		}
		printf("\n");
		return;
	}
	else
	{
		for(j=1;j<=N;j++)
		{
			if(flag[j]==0)
			{
				cun[n]=j;
				flag[j]=1;
				print(n+1,cun);
				flag[j]=0;
			}
		}
	}
}
int main()
{
	int i;
	for(i=1;i<=N;i++)
	{
		flag[i]=0;
	}
	scanf("%d",&N);
	print(1,cun);
	return 0;
}

