//
#include<stdio.h>
int flag[11]={0},ans[11]={0};
void func(int index,int n);
void print();
int main()
{
	int n;
	scanf("%d",&n);
	func(0,n);
	return 0;
}
void func(int index,int n)
{
	int i,j;
	if(index==n)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",ans[j]);
		}
		printf("\n");
		return;
	}
	for(i=1;i<=n;i++)
	{
		if(flag[i]==0)
		{
			ans[index]=i;
			flag[i]=1;
			func(index+1,n);
			flag[i]=0;
			ans[index]=0;
		}
	}
	return;
}


