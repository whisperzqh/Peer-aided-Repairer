#include<stdio.h>
#include<string.h>
int a[10], flag[10], n;
void search(d){
	if(d==n+1)
	{
		for(int i=1;i<=n;i++)
		{
			printf("%d", a[i]);
		}
		printf("\n");
		return;
	}
	int j;
	for(j=1;j<=n;j++)
	{
		if(flag[j]==0)
		{
			a[d]=j;
			flag[j]=1;
			search(d+1);
			flag[j]=0;			 
		}
	}
}
int main()
{
	scanf("%d", &n);
	search(1);
	return 0;
}

