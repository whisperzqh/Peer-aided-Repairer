#include <stdio.h>
void qpl(int m);
int a[12],b[12],m,N;

int main()
{
   scanf("%d",&N);
   qpl(1);
   return 0;
}

void qpl(int m)
{
    int i;
    if(m>N)
    {
      for(i=1;i<=N;i++)
        printf("%d ",b[i]);
        printf("\n");
      return;
    }
    for(i=1;i<=N;i++)
    {
      if(a[i]==0)
      {
         a[i]=1;
          b[m]=i;
          qpl(m+1);
          a[i]=0;
      }
    }
}

