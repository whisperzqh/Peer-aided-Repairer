#include<stdio.h>
#include<string.h>
int a[15];
int b[15];
int N; 
void f(int k);
int main()
{
	scanf("%d",&N);
	f(N);
	return 0;
}
void f(int k)
{
	int m;
	if(k==0)
	{
		for(m=1;m<=N;m++)
			printf("%d",b[m]);
		printf("\n");
	}
	for(m=1;m<=N;m++)
	{
		if(a[m]==0)
		{
			b[N-k+1]=m;
			a[m]=1;
			f(k-1);
			a[m]=0;
		}
	}
	return;
}

