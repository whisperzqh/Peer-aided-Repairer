#include<stdio.h>
//
void swap(int *a,int j,int k)
{
	int temp=*(a+j);
	*(a+j)=*(a+k);
	*(a+k)=temp;
}
//
void invert(int *a,int i,int j)
{
	int temp;
	for(;i<j;i++,j--)
	{
		temp=*(a+i);
		*(a+i)=*(a+j);
		*(a+j)=temp;
	}
 } 
int main()
{
	int i,n,j,k,a[15];
	scanf("%d",&n);
	//
	for(i=0;i<n;i++)
	{
		a[i]=i+1;
	}
	for(i=0;i<n-1;i++)
		printf("%d",a[i]);
		printf("%d\n",a[i]);
	//
	int f=1;
	for(i=1;i<=n;i++)
	{
		f*=i;
	}
	
	for(;f>1;f--)
	{
		//
		for(i=n-2;i>=0;i--)
		{
			if(a[i]<a[i+1])
			{
				j=i;
				break;
			}
		}
		for(i=n-1;i>j;i--)
		{
			if(a[i]>a[j])
			{
				k=i;
				break;
			}
		}
		swap(a,j,k);
		invert(a,j+1,n-1);
		for(i=0;i<n-1;i++)
		printf("%d",a[i]);
		printf("%d\n",a[i]);
	}
}

