#include<stdio.h>
#include<string.h> 
int t[20]={0};
void pai(int m,int n);
int n0;
char s[15];

int main()
{
	
	scanf("%d",&n0);
	pai(0,n0);
	
	return 0;
}
void pai(int m,int n)
{
	int i;
    if(n==0)
	{   s[m]=='\0';
		puts(s);
		return;
	}
	for(i=1;i<=n0;i++)
	{if(t[i]==0)
	{
		t[i]=1;
		s[m]=i+'0';
		pai(m+1,n-1);
		t[i]=0;
	}	
	} 
	
}

