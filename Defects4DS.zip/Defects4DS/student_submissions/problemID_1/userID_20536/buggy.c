#include<stdio.h>
int pmt[15],amt=0,n;
int i;
int check(int k) {
	for(i=1;i<k;i++)if(pmt[k]==pmt[i])return 0;
	return 1;
}
void output(){
	for(i=1;i<=n;i++)printf("%d",pmt[i]);
	puts("");
}
int backdate(){
	int k;
	pmt[0]=0;
	k=0;
	while(k>=0){
		pmt[k]++;
		while((pmt[k]<=n)&&(check(k)==0))pmt[k]++;
		if(pmt[k]<=n){
			if(k==n){
				output();
				amt++;
				int flag=1;
				for(i=1;i<=n;i++){
					if(pmt[i]!=n+1-i){
						flag=0;
						break;
					}
				}
				if(flag)break;
			}
			else{
				k++;
				pmt[k]=0;
			}
		}
		else k--;
	}
	return 0;
}
int main(){
	scanf("%d",&n);
	backdate();

}

