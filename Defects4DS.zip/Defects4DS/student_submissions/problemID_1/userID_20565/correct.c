#include<stdio.h>
#include<stdlib.h>
int main(){
	int n,a[12],b[12],i,j;
	int k,kk,t,tt=12;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		a[i]=i;
	} 
	do{
		k=0,kk=0,tt=12,t=0;
		for(i=1;i<=n;i++){
	    printf("%d ",a[i]);
	    } 
	    printf("\n");
		for(i=n-1;i>0;i--){
			if(a[i]<a[i+1]){
				k=i;//
				kk=a[i];
				//printf("k %d kk %d\n",k,kk);
				break;
		    }
		}
		for(i=k+1;i<=n;i++){
				if(a[i]>kk&&a[i]<tt) {
					t=i;//
					tt=a[i];
				//	printf("t %d tt %d\n",t,tt);
				}
			}
		a[k]=tt;
		a[t]=kk;
		for(i=k+1,j=1;i<=n;i++,j++){
			b[j]=a[i];
		}
		j--;
		for(i=k+1;j>0;j--,i++){
			a[i]=b[j];
			//printf("a[%d] %d\n",i,a[i]);
		}
		//printf(" a[%d] %d t  a[%d] %d\n",k ,a[k],t,a[t]);
		//system("pause");
	}while(k!=0);

}

