#include<stdio.h>
int flag[11],ans[11];
int t;
void allarange(int n){
    //printf("hi");
    for (int i = 1; i < t+1; i++)
    {
        if(flag[i]==0){
            flag[i]=1;
            ans[t-n]=i;
            if(n==1){
                for(int k=0;ans[k]!=0;k++)
                printf("%d ",ans[k]);
                putchar(10);
            }
            allarange(n-1);
            flag[i]=0;
        }
    }
    
}
int main(){
    int n,i;
    scanf("%d",&n);
    t=n;
    allarange(n);
    return 0;
}
