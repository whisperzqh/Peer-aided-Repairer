#include <stdio.h>
#include <string.h>

int chazhao(int k);
void output();
int run();
int s[15],m=0,n;

int main()
{
	scanf("%d",&n);
	run();
}

int chazhao(int k)
{
	for (int i=1;i<k;i++)
		if (s[k]==s[i])
			return 1;
	return 0;
}
void output()
{
	for (int i=1;i<=n;i++)
		printf("%d",s[i]);
	puts(" ");
}
int run()
{
	int k=0;
	s[0]=0;
	while(k>=0)
	{
		s[k]++;
		while (s[k]<=n&&chazhao(k)==1)
			s[k]++;
		if (s[k]<=n)
		{
			if (k==n)
			{
				output();
				m++;
				int arm=1;
				for (int i=1;i<=n;i++)
				{
					if (s[i]!=n+1-i)
					{
						arm=0;
						break;
					}
				}
			if (arm!=0) break;
			}
			else
			{
				k++;
				s[k]=0;
			}
		}
		else k--;
	}
	return 0;
}

