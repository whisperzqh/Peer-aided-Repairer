#include<stdio.h>

int box[10]={0};
int flag[11]={0};
 
int N=0;

int main()
{
	scanf("%d",&N);
	func(1);
	
	return 0;
}

void func(int step)
{
	int i=0;
	if(step==N+1)
	{
		for(i=1;i<=N;i++)
			printf("%d ",box[i]);
		printf("\n");
	}
	for(i=1;i<=N;i++)
	{
		if(flag[i]==0)
		{
			box[step]=i;
			flag[i]=1;
			func(step+1);
			flag[i]=0;//
		}
	}
}	
	
	
	
	



