#include<stdio.h>
int n;
int a[12],v[12];
void print()
{
	int i;
	for(i=1;i<=n;i++)
	{
		printf("%d",a[i]);
	}
	printf("\n");
}
void dfs(int num)
{
	int i;
	if(num==n+1)
	{
	print();
	return;
	}
	for(i=1;i<=n;i++)
	{
		if(!v[i])
		{
			a[num]=i;
			v[i]=1;
			dfs(num+1);
			v[i]=0;
		}
	}
}
int main()
{
    scanf("%d",&n);
    dfs(1);
	return 0;
}

