#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
int a[10], b[100], n;
void d(int c)
{
    int i;
    if (c == n + 1)
    {   
        for (i = 1; i <= n; i++)
        {
            printf("%d", a[i]);
        }
        printf("\n");
        return;
    }
    for (i = 1; i <= n; i++)
    {
        if (b[i] == 0) 
        {
            a[c] = i;  
            b[i] = 1;
            d(c + 1);
            b[i] = 0;
        }
    }
    return;
}
int main()
{
    scanf("%d", &n);
    d(1);
    return 0;
}

