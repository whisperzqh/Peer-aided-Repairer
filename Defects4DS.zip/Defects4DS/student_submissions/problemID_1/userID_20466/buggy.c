#include <stdio.h>
void get_all_listing(int n,int *p,int m);
void exchange(int *a,int *b);
void bubble_sort(int n, int *p);
int main()
{
    int n;
    scanf("%d", &n);
    int a[11] = {1,2,3,4,5,6,7,8,9,10};
    int *p = a;
    get_all_listing(n,p,n); 
    return 0;
}
void get_all_listing(int n,int *p,int m)
{
    if(n==1)
    {
        for(int i=0;i<m;i++)
        {
            printf("%d ",p[-m+1+i]);    
        }
        puts("");
    }
    for(int i=0;i<n;i++)
    {
        exchange(&p[0],&p[i]);
        bubble_sort(n-1,p+1);
        get_all_listing(n - 1, p+1,m);
        exchange(&p[0], &p[i]);
    }
}
void exchange(int *a,int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

void bubble_sort(int n, int *p)
{
    int flag = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (p[j] > p[j + 1])
            {
                flag = 1;
                exchange(&p[j], &p[j + 1]);
            }
        }
        if (flag == 0)
            break;
    }
}
