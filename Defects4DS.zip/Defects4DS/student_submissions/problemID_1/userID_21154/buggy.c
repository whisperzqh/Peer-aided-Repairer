#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int flag[11],ans[11];
void func(int index,int n);
int main()
{
    int n;
    scanf("%d",&n);
    func(0,n);
    return 0;
}
void func(int index,int n)
{
    if(index==n)
    {
        for(int i=0;ans[i]>0;i++)
            printf("%d ",ans[i]);
        printf("\n");
        return;
    }
    for(int i;i<=n;i++)
    {
        if(flag[i]==0)
        {
            ans[index]=i;
            flag[i]=1;
            func(index+1,n);
            flag[i]=0;
            ans[index]=0;
        }
    }
    return;
}
