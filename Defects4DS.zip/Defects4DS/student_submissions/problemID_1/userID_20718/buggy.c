#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define ULL unsigned long long

#define MaxUnsignedInt 4294967295
#define MaxInt 2147483647
#define MinInt -2147483648
#define MaxUnsignedLong 4294967295
#define MaxLong 2147483647
#define MinLong -2147483648
#define MaxLongLong 9223372036854775807
#define MinLongLong -9223372036854775808
#define MaxUnsignedLongLong 18446744073709551615
#define PI 3.1415926
#define eps 1e-6

#define _max(x,y) (x)>(y)?(x):(y)
#define _min(x,y) (x)<(y)?(x):(y)
#define _swap(x,y) x^=y,y^=x,x^=y
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <string.h>

#define ULL unsigned long long

#define MaxUnsignedInt 4294967295
#define MaxInt 2147483647
#define MinInt -2147483648
#define MaxUnsignedLong 4294967295
#define MaxLong 2147483647
#define MinLong -2147483648
#define MaxLongLong 9223372036854775807
#define MinLongLong -9223372036854775808
#define MaxUnsignedLongLong 18446744073709551615
#define PI 3.1415926
#define eps 1e-6

#define _max(x,y) (x)>(y)?(x):(y)
#define _min(x,y) (x)<(y)?(x):(y)
#define _swap(x,y) x^=y,y^=x,x^=y

int a[20];
int b[20];
int N;

void qpl( int m );

int main()
{
 	scanf("%d",&N);
    qpl( 0 );

	return 0;
}

void qpl( int m )
{
	int i;
	if( m!=N )
	{
		for( i=1;i<=N;i++ )
		{
			if( b[i]==0 )
			{
				b[i]=1;
				a[m]=i;
				qpl(m+1);
				b[i]=0;
			}
		}
	}
	else
	{
		for( i=0;i<N;i++ )
		{
			printf("%d",a[i]);
		}
		printf("\n");
		return ;
	}
	return ;
}



























