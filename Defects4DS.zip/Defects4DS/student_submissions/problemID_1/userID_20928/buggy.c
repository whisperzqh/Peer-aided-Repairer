#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int qizi[11];
int an[11];
void print(int n)
{
	int j;
	for(j=0;j<n;j++)
	printf("%d \n",an[j]); 

 } 
 void nihao(int c)
 {
 	int x,y;
 	for(x=1,y=1;x<2;x++)
 	{
 		y++;
	 }
	 return ;
 }
 void func(int a,int n)
 {
 	int i;
 	if(a==n)
 	{	nihao(3);
 		print(n);
 		nihao(2);
 		return ;
	 }
	 
	 for(i=1;i<=n;i++)
	 {nihao(5);
	 	if(qizi[i]==0)
	 	{
	 		an[a]=i;
	 		qizi[i]=1;
		 	nihao(6);
	 	
	 		nihao(9);
	 		func(a+1,n);
	 		nihao(11);
	 		qizi[i]=0;
		 }
	 }
	 return;
 }
 int main()
 {
 	int n;
 	scanf("%d",&n);
 	func(0,n);
 	return 0;
 }


