#include <stdio.h>
#define Length 10
int arr1[Length];
int arr2[Length];
void sort(int j,int m)
{
	int i,k;
	if(j==m)
	{
		for(k=0;k<m;k++)
		printf("%d ",arr2[k]);
		printf("\n");
		return;
	}
	for(i=1;i<=m;i++)
	{
		if(arr1[i]==0)
		{
			arr2[j]=i;
			arr1[i]=1;
			sort(j+1,m);
			arr1[i]=0;
		}	
	}
	return;
} 
int main()
{
	int n;
	scanf("%d",&n);
	sort(0,n);
	return 0;
}

