#include<stdio.h>
#include<string.h>
#include<math.h>
#include<ctype.h>
int mark=1;
int num[200+1]={0};
int s[20]={0};
void pailie(int mark,int n);
int main()
{ int n;
  int i=0;
  
  scanf("%d",&n); 
  for(i=1;i<=n;i++)
  {  num[i]=1;
  }
  pailie(mark,n);
return 0;
 } 
 
void pailie(int mark,int n)
{  if(mark<=n)
     {for(int j=1;j<=n;j++)
      {if(num[j]==1)
	      { s[mark]=j;
	        num[j]=0;
	   
	        pailie(mark+1,n);
	        num[j]=1;
		   } 
      }
	 
     }
    else
    { int k=0;
      for(k=1;k<=n;k++)
        { printf("%d",s[k]);
		}
	  printf("\n");
	
	}
   
   return;
}

