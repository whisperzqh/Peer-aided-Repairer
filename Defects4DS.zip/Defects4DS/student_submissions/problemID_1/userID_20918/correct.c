/**/ 
#include<stdio.h>
#include<string.h>
void swap(int *a,int *b)
{
	/**/ 
	int tmp;
	tmp=*a;
	*a=*b;
	*b=tmp;
}
int comp(const void* a,const void *b)
{
	return (*(int*)a-*(int*)b);
}
void array(int arr[],int head,int len);
/**/ 
int main()
{
	int n,i;
	scanf("%d",&n);
	int num[20]={0};
	/**/ 
	for(i=1;i<=n;i++){
		num[i]=i;
	}
	array(num,1,n);
	return 0;
}
void array(int arr[],int head,int len)
{
	int j,k;
	int arr1[20]={0};
	if(head==len){
		for(k=1;k<=len;k++){
			printf("%d ",arr[k]);
		}
		printf("\n");
	}
	else{
		for(j=head;j<=len;j++){
		if(head!=j){
			for(k=head;k<=len;k++){
				arr1[k]=arr[k];
			}
			swap(&arr[head],&arr[j]);

			qsort(arr+head+1,len-head,sizeof(int),comp);
		}
		array(arr,head+1,len);
		if(head!=j){
			for(k=head;k<=len;k++){
				arr[k]=arr1[k];
			}
		}
	}
	}
}

