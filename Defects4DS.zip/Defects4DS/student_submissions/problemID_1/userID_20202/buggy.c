#include <stdio.h>
#include <string.h>


void permutation(int *a,int n, int k)
{
	if(n==k) print(a, n);
	
	else
	{
		int i=k, j=n;
		for(i=k; i<=n; i++)
		{
			swap(a+i, a+k);
			permutation(a, n, k+1);
			swap(a+i, a+k);
		}
	}
}

void swap(int *a, int *b)
{
	int temp;
	temp=*a;
	*a=*b;
	*b=temp;
}

void print(int *a, int n)
{
	int i=1;
		for(i=1; i<=n; i++)
	 {
		printf("%d ", a[i]);
	 }
	 printf("\n");
 } 

int main()

{
	int n, i=0;
	scanf("%d", &n);
	int a[12];
	for(i=1; i<=n; i++)
	{
		a[i]=i;
	}
	permutation(a, n, 1);
	return 0;
}

