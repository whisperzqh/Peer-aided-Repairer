#include<stdio.h>
#define swap(a,b) temp=a;a=b;b=temp; 
void arrange(int *a, int m, int n)
{
	int temp, i, j;
	if(m==n)
	{
		for(j=1;j<=n;j++) printf("%d ", a[j]);
		printf("\n");
	}
	for(i=m;i<=n;i++)
	{
		swap(a[m], a[i]);
		arrange(a, m+1, n);
		swap(a[m], a[i]);
	}
}
int main()
{
	int i, n, a[15];
	while(scanf("%d", &n)!=EOF)
	{
		for(i=1;i<=n;i++) a[i]=i;
		arrange(a, 1, n);
	}
	return 0;	
} 

