#include <stdio.h>
int ans[12],book[12],n;
void Pailie(int step)
{
	int i;
	if(step==n+1)
	{
		for(i=1;i<=n;i++)
			printf("%d ",ans[i]);
		printf("\n");
		return;
	}
	for(i=1;i<=n;i++)
	{
		if(book[i]==0)
		{
			ans[step]=i;
			book[i]=1;
			Pailie(step+1);
			book[i]=0;
		}
	}
	return;
}

int main()
{
	scanf("%d",&n);
	Pailie(1);
	return 0;
}

