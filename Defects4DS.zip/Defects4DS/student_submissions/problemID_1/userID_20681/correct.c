#include<stdio.h>
#include<string.h>
#include<ctype.h>
int use[11];
char shu[11];
int N;
void rank(int m,int n)
{
	int i,j;
	if(n==0)
	{
		shu[m]='\0';
		for(j=0;j<N;j++)
		printf("%d ",shu[j]);
		printf("\n");
		return; 
	}
	for(i=1;i<=N;i++)
	if(use[i]==0)
	{
		use[i]=1;
		shu[m]=i;
		rank(m+1,n-1);
		use[i]=0;
	}
}
int main()
{
	int i,j;
	scanf("%d",&N);
	rank(0,N);
	return 0;
}

