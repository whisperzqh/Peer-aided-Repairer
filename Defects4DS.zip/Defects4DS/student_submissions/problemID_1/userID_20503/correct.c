#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int flag[11]={0};
int answer[11]={0};
int n;

void print(){
int i=0;
for(i=0;i<n-1;i++){
    printf("%d ",answer[i]);
}
printf("%d\n",answer[i]);
}

void get_answer(int j,int n){

int index=j;
int i;

if(index==n){
    print();
    return;
}

for(i=1;i<=n;i++){
    if(flag[i]==0){
        answer[index]=i;
        flag[i]=1;
        get_answer(index+1,n);
        flag[i]=0;

    }
}
return;
}

int main()
{scanf("%d",&n);
get_answer(0,n);
return 0;
}

