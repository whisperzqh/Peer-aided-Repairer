#include <stdio.h>
#include <stdlib.h>
int array[]={1,2,3,4,5,6,7,8,9};
int queue[9]={0};
int flag[9]={0};
void perm(int s,int n)
{
	int i;
	if(s>n)
	{return ;
	}
	if(s==n)
	{
		for(i=0;i<n;i++)
		printf("%d ",queue[i]);
	printf("\n");
	return ;
	}
	for(i=0;i<n;i++)
	{
		if(flag[i]==0)
		{
			flag[i]=1;
			queue[s]=array[i];
			perm(s+1,n);
			flag[i]=0;
		}
	}
	
}
int main()
{
	int n;
	scanf("%d",&n);
	perm(0,n);
	return 0;
}

