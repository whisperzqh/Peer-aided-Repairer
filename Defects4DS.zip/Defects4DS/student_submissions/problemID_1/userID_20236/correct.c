#include <stdio.h>
#include <math.h>
#include <string.h>
int flag[11];
int ans[11];
void print();
void func(int,int);

void func(int index,int n){
	int i;
	if(index == n){
		print();
		return;
	}
	for(i=1;i<=n;i++){
		if(flag[i] == 0){
			ans[index]=i;
			flag[i]=1;
			func(index+1,n);
			flag[i]=0;
			ans[index]=0;
		}
	}
	return;
}

void print(){
	int i;
	for(i=0;ans[i]!=0;i++){
		printf("%d ",ans[i]);
	}
	printf("%c",'\n');
}

int main(){
	int n;
	scanf("%d",&n);
	func(0,n);
	return 0;
}



