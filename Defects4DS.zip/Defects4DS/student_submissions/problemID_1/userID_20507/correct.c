#include<stdio.h>
int flag[11];
int ans[11];
void func(int index,int n);
void print(int n); 
int main()
{
	int n,i;
	scanf("%d",&n);
	func(0,n);
	return 0;
}
void func(int index,int n)
{
	int i;
	if(index==n)
	{
		print(n);
		return;
	}
	for(i=1;i<n+1;i++)
	{
		if(flag[i]==0)
		{
			ans[index]=i;
			flag[i]=1;
			func(index+1,n);
			flag[i]=0;
			ans[index]=0;
		}
	}
	return;
}
void print(int n)
{
	int i;
	for(i=0;i<n;i++)
	{
		printf("%d ",ans[i]);
	}
	printf("\n");
	return;
}

