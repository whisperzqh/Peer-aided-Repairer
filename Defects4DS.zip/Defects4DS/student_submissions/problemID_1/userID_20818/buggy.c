#include <stdio.h>
int main(){
    int n,i;
    scanf("%d",&n);
int s[n+5];
for(i=0;i<n+5;i++){
    s[i]=i+1;
}
pl(0,n-1,n,s);
return 0;
}
void pl(int a,int b,int n,int s[]){
   if(a<b){
      int i;
      for(i=a;i<=b;i++){
        bk(a,i,s);
        pl(a+1,b,n,s);
        cg(a,i,s);
      }
   }
   else{
        int i;
    for(i=0;i<n;i++){
        printf("%d",s[i]);
    }
    printf("\n");
   }
}
void cg(int l,int r,int s[]){
    int t,m;
    m=s[l];
    for(t=l;t<r;t++){
        s[t]=s[t+1];
    }
    s[r]=m;

}
void bk(int l,int r,int s[]){
    int t,m;
    m=s[r];
    for(t=r;t>l;t--){
        s[t]=s[t-1];
    }
    s[l]=m;

}

