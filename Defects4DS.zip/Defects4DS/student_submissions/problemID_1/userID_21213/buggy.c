#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int travelled[10] = { 0 };
int a[10] = { 0 };
int n;

void printt() {
	for (int i = 0; i < n; i++) {
		printf("%d", a[i]);
	}
	printf("\n");
}

void rank(int i) {
	if (i >= n) printt();
	else {
		for (int j = 0; j < n; j++) {
			if (travelled[j] == 0) {
				travelled[j] = 1;
				a[i] = j + 1;
				rank(i + 1);
				travelled[j] = 0;
			}
		}
	}
}

int main() {
	scanf("%d ", &n);
	rank(0);
	return 0;
}

