#include<stdio.h>
void swap(int *a,int *b)
{
	int temp;
	temp=*a;*a=*b;*b=temp;
}
void quanpai(int s[],int a,int n)
{
	int i,j;
	
	if(a==n)
	{
		for(i=0;i<n;i++)
	    {
		    printf("%d",s[i]);
	    }
	    puts("");
	}
	else
	{
		for(i=a;i<n;i++)
		{
			for(j=i;j>a;j--)
			{
				swap(&s[j],&s[j-1]);
			}
			quanpai(s,a+1,n);
			for(j=a;j<i;j++)
			{
				swap(&s[j],&s[j+1]);
			}
		}
	}
}
int main()
{
	int i,n,shu[100]={0};
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		shu[i]=i+1;
	}
	quanpai(shu,0,n);
	return 0;
}

