#include<stdio.h>
#include<string.h>
int flag[11];
int ans[11];
void func(int index, int n);
int main()
{
	int N;
	scanf("%d", &N);
	func(0, N);
	return 0;
}
void func(int index, int n)
{
	if (index == n) {
		for (int i = 0; i < 11; i++) {
			if (ans[i] != 0)
				printf("%d", ans[i]);
		}
		printf("\n");
	}
	for (int i = 1; i <= n; i++) {
		if (flag[i] == 0) {
			ans[index] = i;
			flag[i] = 1;
			func(index + 1, n);
			flag[i] = 0;
			ans[index] = 0;
		}
	}
}

