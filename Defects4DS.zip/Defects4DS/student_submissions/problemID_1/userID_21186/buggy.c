#include<stdio.h> 
#include<string.h> 
int n;
int fl[20],num[20];
int qpl(int pan)
{
	int i,j;
	
	for(i=1;i<=n;i++)
	{
		
		if(fl[i]==0&&pan<n)
		{
			num[pan+1]=i;
			fl[i]=1;
			if(pan+1==n)
	        {
	        	for(j=1;j<=n;j++)
	        	printf("%d",num[j]);
	        	printf("\n");
	        	fl[i]=0;
	    	    break;
         	}
         	else
		    qpl(pan+1);
	        fl[i]=0;
		}
		
		
		
	}	
}

int main()
{
	int i,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	    num[1]=i;
	    fl[i]=1;
	    qpl(1);
	    fl[i]=0;
	}
}


