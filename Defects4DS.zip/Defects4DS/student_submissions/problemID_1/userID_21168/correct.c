//
//
//
//
//
//

#include <stdio.h>
int a[10],b[10]={0};
int n,i;
void arr(int t){
    int i;
    if(t==n){
        i=0;
        while(i<n){
            printf("%d ",a[i]);
            i++;
        }
        printf("\n");
        return;
    }
    for(i=0;i<n;i++){
        if(b[i]==0){
            a[t]=i+1;
            b[i]=1;
            arr(t+1);
            b[i]=0;
        }
    }
}
int main(void) {
    scanf("%d",&n);
    arr(0);
}

