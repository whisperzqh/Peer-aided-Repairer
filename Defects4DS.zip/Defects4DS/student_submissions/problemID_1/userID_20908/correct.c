/**/
#include<stdio.h>
	char num[11]={0};
	int flag[11]={0};
	int N;
void fun(int n,int m)
{
		int i,j;
		if(n==0)
		{
			for(j=0;j<N;j++)
			{
				printf("%c",num[j]);
				if(j!=N-1)
				printf(" ");
				else
				printf("\n");
			}
			return;
		}
	for(i=0;i<N;i++)
 {
		if(flag[i]==0)
		{
			flag[i]=1;
			num[m]=i+1+'0';
			fun(n-1,m+1);
			flag[i]=0;
			
		}
 }

}
int  main()
{

	scanf("%d",&N);
	fun(N,0);
	return 0;
}


