#include <stdio.h>


int arr[15] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

void Swap(int* x, int* y) {
    int temp;
    temp = *x;
    *x = *y;
    *y = temp;
}


void PrintArr(int pos) {
    for (int i = 1; i <= pos; i++) {
        printf("%d ", arr[i]);
    }
    putchar('\n');
} 



void GetArr(int nowPos, int targetPos) {    
    int elem = arr[nowPos];
    for (int i = nowPos; i >= targetPos; i--) {
        arr[i] = arr[i - 1];
    }
    arr[targetPos] = elem;
} 

void BackArr(int nowPos, int targetPos) {   
    int elem = arr[nowPos];
    for (int i = nowPos; i < targetPos; i++) {
        arr[i] = arr[i + 1];
    }
    arr[targetPos] = elem;
} 


void Perm(int ground, int sky) {
    if (ground + 1 == sky) {    
        PrintArr(sky);
        Swap(&arr[ground], &arr[sky]);
        PrintArr(sky);
        Swap(&arr[ground], &arr[sky]);
    } else {                    
        for (int i = ground; i <= sky; i++) {
            GetArr(i, ground);
            Perm(ground + 1, sky); 
            BackArr(ground, i);
        }
    }
} 


int main() {
    int n;

    scanf("%d", &n);
    if(n==1)
    {
    	printf("1 ");
	}
	else {
    Perm(1, n);
}

    return 0;
} 



