#include <stdio.h>

void f(int a[],int n,int spot,int flag[],int b[])
{
    int i;
    if(spot==n+1)
    {
        for(i=1;i<=n;i++)
        {
            printf("%d ",b[i]);
        }
        printf("\n");
        return ;
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            if(flag[i]==0)
            {
                b[spot]=a[i];
                flag[i]=1;
                f(a,n,spot+1,flag,b);
                flag[i]=0;
            }
        }

    }

}
int main()
{
    int i,n,a[15];
    int flag[15]={0},b[15]={0};
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        a[i]=i;
    }
    f(a,n,1,flag,b);

return 0;
}

