#include<stdio.h>
#include<string.h>
int card[11],n,box[11];
void put(int step);
int main()
{
	scanf("%d",&n);
	put(1);
	return 0;
}
void put(int step)
{
	int i;
	if(step==n+1)
	{
		for(i=1;i<=n;i++)
			printf("%d ",box[i]);
		printf("\n");
		return;
	}
	for(i=1;i<=n;i++)
	{
		if(card[i]==0)
		{
			box[step]=i;
			card[i]=1;
			put(step+1);
			card[i]=0;
		}
	}
	return 0;
}

