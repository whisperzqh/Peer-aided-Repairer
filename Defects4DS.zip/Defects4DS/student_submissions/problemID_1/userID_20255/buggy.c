#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n=0,sum=1,left=0,right=0,temp=0;
	scanf("%d",&n);
	int *a = (int *)malloc(sizeof(int)*n);
	int i,j,k;
	for(i=1;i<=n;i++){
		sum *= i;
	}
	for(i=0;i<n;i++){
		a[i] = i+1;
		printf("%d",a[i]);
	}
	printf("\n");
	for(i=1;i<sum;i++){
		for(j=n-1;j>=1;j--){
			if(a[j]>a[j-1])
			{
				for(k=j;k<n;k++){
					if(k==n-1 && a[k]>a[j-1])
					{
						temp = a[j-1];
						a[j-1] = a[k];
						a[k] = temp;
						break;
					}
					else if(a[k]>a[j-1] && a[k+1]<a[j-1])
					{
						temp = a[j-1];
						a[j-1] = a[k];
						a[k] = temp;
						break;
					}
				}
				for(left=j;left<n;left++){
					for(right=n-1;right>left;right--){
						if(a[right]<a[right-1]){
							temp = a[right];
							a[right] = a[right-1];
							a[right-1] = temp;
						}
					}
				}
				break;
			}
		}
		for(j=0;j<n;j++){
			printf("%d",a[j]);
		}
		printf("\n");
	}
	free(a);
	return 0;
 } 

