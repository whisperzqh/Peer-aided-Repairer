#include<stdio.h>
#define max 11
int mark[max];
int num[max];
void print();
void fun(int,int);
int main()
{
	int n;
	scanf("%d",&n);
	fun(0,n);
	return 0;
	
}

void print(int n)
{
	int i;
	for(i=0;i<n;i++)
		printf("%d ",num[i]);
	printf("\n");
}
void fun(int index,int n)
{
	int i;
	for(i=1;i<n+1;i++)
	{
		if(mark[i]==0)
		{
			num[index]=i;
			mark[i]=1;
			if(index==n-1)
			{
				print(n);
				mark[i]=0;
				return;
			}
			fun(index+1,n);
			mark[i]=0;
		}
	}
	return;
}


