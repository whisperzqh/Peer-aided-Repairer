#include<stdio.h>
#include<string.h>
#include<stdlib.h> 
int flag[11];
int ans[11];
void print(int n)
{
	int i;
	for(i = 0;i<n;i++)
	{
		printf("%d ",ans[i]);
	}
	printf("\n");
}
void func(int index, int n)
{
	int j;
	if(index == n)
	{
		print(n);
		return 0;
	}
	for(j = 1;j <= n;j++)
	{
		if(flag[j]==0)
		{
			ans[index]=j;
			flag[j]=1;
			func(index+1, n);
			flag[j]=0;
			ans[index]=0;
		}
	}
	return 0;
}
int main()
{
	int n;
	scanf("%d",&n);
	func(0,n);
	return 0;
}

