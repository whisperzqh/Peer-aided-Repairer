#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int cmp(const void*a,const void*b)
{
    if(*(int*)a>*(int*)b)
        return 1;
    if(*(int*)a<*(int*)b)
        return -1;
}

int main()
{
    int n,i,k,flag=0,temp=0,first,second;
    int a[20]= {0};

    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        a[i]=i;
        printf("%d ",i);
    }
    printf("\n");
    for(i=n;;)
    {
        flag=0;
        for(i=n;i>1; i--)
        {
            if(a[i]>a[i-1])
            {
                first=i-1;
                flag=1;
                for(k=n;; k--)
                {
                    if(a[k]>a[first])
                    {
                        second=k;
                        temp=a[first];
                        a[first]=a[second];
                        a[second]=temp;

                        qsort(&a[first+1],n-first,4,cmp);
                        break;
                    }
                }
            }
            if(flag==1)
				break;
        }
        if(flag==0)
            break;
        for(k=1; k<=n; k++)
        {
            printf("%d ",a[k]);
        }
        printf("\n");
    }
    return 0;
}

