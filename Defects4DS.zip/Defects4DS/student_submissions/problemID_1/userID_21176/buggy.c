#include <stdio.h>

int a[12] = {0,1,2,3,4,5,6,7,8,9,10,11};
void out(int a[], int n) {
	int i;

	for (i = 1; i <= n; i++) {
		printf ("%d ", a[i]);
	}
	printf ("\n");
	return;
}
void sort(int a[], int start, int end) {
	int i, j;
	int tem;
	for (i = start; i <= end; i++) {
		for (j = start; j <= end; j++) {
			if (a[j] > a[j + 1]) {
				tem = a[j];
				a[j] = a[j + 1];
				a[j + 1] = tem;
			}
		}
	}
	return;
}
void Whole_arrangement(int n) {
	int i;
	int l = -1, r = 0, tem;
	out(a,n);
	while (l != 0) {
		for (i = n - 1; i >= 1; i--) {
			if (a[i] < a[i + 1]) {
				l = i;
				break;
			}
			l = 0;
		}//
		if (l == 0) {
			break;
		}
		for (i = n; i >= 1; i--) {
			if (a[i] > a[l]) {
				r = i;
				break;
			}
		}//
		tem = a[l];
		a[l] = a[r];
		a[r] = tem;//
		sort(a, l + 1, r);//
		out(a, n);//
	}
	return;

}
int main() {
	int n;
	scanf ("%d", &n);
	if (n == 1) {
		printf ("1");
		return 0;
	}
	Whole_arrangement(n);
	return 0;
}

