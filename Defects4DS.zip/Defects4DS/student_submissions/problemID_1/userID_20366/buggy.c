#include<stdio.h>
#define MAX 10
int M[MAX]={0};
char s[MAX+1];
void rank(int m,int n);
int N;
int main(){

scanf("%d",&N);
rank(0,N);
return 0;


}
void rank(int m,int n)
{

    int i;
    if(n==0){
        s[m]='\0';
        puts(s);
        return;
    }
    for(i=1;i<=N;i++)
    if(M[i]==0){
        M[i]=1;
        s[m]='0'+i;
        rank(m+1,n-1);
        M[i]=0;
    }
}

