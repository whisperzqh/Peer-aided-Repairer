#include<stdio.h>
#include<string.h>
void track(int a,int b);
int N,f[11]={0},finall[1000],j;
int main()
{
	scanf("%d",&N);
	track (0,N);
	return 0;
}
void track(int a,int b)
{
	int i=0;
	if(b==0)
	{
	    for(j=0;j<N;j++)
	    printf("%d ",finall[j]);
	    printf("\n");
		return;
	}
	for(i=1;i<=N;i++)
	{
		if(f[i]==0)
			{
				f[i]=1;
				finall[a]=i;
				track(a+1,b-1);
				f[i]=0;
			}
	
	}
	
}

