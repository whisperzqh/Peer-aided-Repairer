#include <stdio.h>
int a[10]={0};
char s[11];
int x;
void f(int m,int n)
{
	int i;
	if(n==0)
	{
		s[m]='\0';
		for(int j=0;j<x;j++)
		{
			printf("%c ",s[j]);
			if(j==x-1)
			printf("\n");
		}
		return;
	}
	for(i=1;i<=x;i++)
	{
		if(a[i]==0)
		{
			a[i]=1;
			s[m]='0'+i;
			f(m+1,n-1);
			a[i]=0;
		}
	}
}
int main()
{
	scanf("%d",&x);
	f(0,x);
	return 0;
}

