#include <stdio.h>
#include <math.h>
#include <string.h>
int a[10000],b[10000],n;
int main()
{

	scanf("%d",&n);
	dfs(1);
	system("pause");}
	void dfs(int t)
	{;
	if(t==n+1)
	{
for(int i=1;i<n+1;i++)
	{
	printf("%d ",a[i]);
	}
	printf("\n");
	return;
		}
	for(int i=1;i<n+1;i++)
	{if(b[i]==0)
	{
	 a[t]=i;
	 b[i]=1;
	 dfs(t+1);
	 b[i]=0; 
	}	
}
	
	return ;
 } 

