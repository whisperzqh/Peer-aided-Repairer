#include<stdio.h>
int flag[12],num[12],n;
int main()
{
	scanf("%d",&n);
	search(1);
}

void search(int a)
{
	if(a>n)
	{
		for(int i=1;i<=n;i++)  printf("%d",num[i]);
		printf("\n");
	}
	for(int i=1;i<=n;i++)
	{
		if(flag[i]!=1) {
			flag[i]=1;
			num[a]=i;
			search(a+1);
			flag[i]=0;
		}
	}
}

