#include <stdio.h>
int a[15];
void pl(int a[],int );
void sort(int a[],int ,int );
int main()
{
	int n,i;
	scanf("%d",&n);
	for(i=0;i<n;i++) a[i]=i+1;
	pl(a,n);
	return 0;
}
 
 void pl(int a[],int n)
{
	int i;
 	int N=1,x=0,y=0;
 	for(i=n;i>0;i--) N*=i;
 	while(N--)
 	{
 		for(i=0;i<n;i++)
 		    printf("%d ",a[i]);
 		printf("\n");
 		
 		for(i=n-1;i>0;i--)
 		    if(a[i-1]<a[i])
 			{
 				x=i-1;
 				break;
			}
		for(i=n-1;i>0;i--)
		    if(a[i]>a[x])
		    {
		    	y=i;
		    	break;
			}
		int temp=0;
		temp=a[x];
		a[x]=a[y];
		a[y]=temp;
		
		sort(a,x,n);
	}
 	return;
} 

void sort(int a[],int x,int n)
{
	int i,j;
	int temp=0;
	for(i=1;i<n-x;i++)
	{
		for(j=x+1;j<n-1-i;j++)
		{
			if(a[j]>a[j+1])
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	return;
} 

