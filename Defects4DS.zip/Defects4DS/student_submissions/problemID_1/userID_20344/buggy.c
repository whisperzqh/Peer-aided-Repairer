#include<stdio.h>
#include<string.h>
#include<math.h>
int n,pl[100],tag[100];
void dfs(int k);
void print();
int main()
{
	scanf("%d",&n);
	dfs(0);	
	return 0;
} 
void print()
{ 
int i;
for(i=1;i<=n;i++)
printf("%d",pl[i]);
printf("\n");
return ;
}
 void dfs(int k)
{
 	int i;
 	if(k==n)
 	{
 		print();
 		return ;
	 }
	 for(i=1;i<=n;i++)
	 {
	 	if(tag[i]==0)
	 	{
	 		pl[k+1]=i;
	 		tag[i]=1;
	 		dfs(k+1);
	 		tag[i]=0;
		 }
	 }
	 return;
}

