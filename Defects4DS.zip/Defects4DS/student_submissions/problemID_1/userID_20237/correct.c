#include<stdio.h>
int all();
int a[20];
int i,j,k,n,temp,m;
int main(){
	scanf("%d",&n);
	for(i=1;i<=n;i++)a[i]=i;
	for(i=1;i<=n;i++)printf("%d ",a[i]);
	printf("\n");
	while(all()){
		for(i=1;i<=n;i++)printf("%d ",a[i]);
		printf("\n");
	}
	return 0;
}
int all(){
	for(k=n;k>1;k--){
		if(a[k]>a[k-1]){
			m=k;
			for(j=n;j>k;j--)if(a[j]>a[k-1]&&a[j]<a[k]){
				m=j;
				break;
			}
				temp=a[m];
				a[m]=a[k-1];
				a[k-1]=temp;
			for(i=n;k<i;k++,i--){
				temp=a[k];
				a[k]=a[i];
				a[i]=temp;
			}
			return 1;
		}
	}
		return 0;
}

