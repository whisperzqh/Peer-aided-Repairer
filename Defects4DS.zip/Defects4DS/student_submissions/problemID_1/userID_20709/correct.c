#include<stdio.h>
void func(int k);
int n,s[11],flag[11];
int main()
{
	scanf("%d",&n);
	func(1);
	 return 0;
}
 void func(int k)
 {
 	int i;
 	if(k==n+1)
 	{

 		for(i=1;i<=n;i++)
 		printf("%d ",s[i]);
 		printf("\n");
 		return ;
	 }
	 for(i=1;i<=n;i++)
	 {
	 	if(flag[i]==0)
	 	{
	 		flag[i]=1;
	 		s[k]=i;
			func(k+1);
			flag[i]=0;
		 }
	 }
 }

