#include<stdio.h> 
int a[10];
void change(int x,int y)
{
	int i,j,k,m;
	if(x==y)
	{
	for(i=0;i<y;i++)
	printf("%d ",a[i]);
	printf("\n");
	}
	else
	{
	for(j=1;j<=x;j++)
	{
		m=1;
	for( k=0;k<y;k++)
	{
		if(a[k]==j)
	 	m=0;
			}
	if(m!=0)
	{
	a[y]=j;
	change(x,y+1);
		}
	}
	}
}
int main()
{
	int i,j;
	int m=1,n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	m=(i+1)*m;
//	printf("%d",m);
	
	for(i=0;i<n;i++)
	{
			a[i]=i+1;	
			}
	change(n,0);
}

