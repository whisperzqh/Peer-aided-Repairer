#include <stdio.h>

int a[15] = {0};
char b[20];
void rank(int m, int n);

int N;
int main ()
{
	scanf ("%d", &N);
	rank(0,N);
	return 0;
}
void rank(int m, int n)
{
	int i;

	if( n == 0)
    {
		b[m] = '\0';
		puts(b);
		return;
	}
	for(i=1; i<=N; i++)
		if(a[i] == 0 )
		{
			a[i] = 1;
			b[m] = '0'+i;
			rank(m+1,n-1);
			a[i] = 0;
		}
}


