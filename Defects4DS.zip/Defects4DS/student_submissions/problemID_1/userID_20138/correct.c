#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
char ch[22];
int num[10],N;
void pailie(int w,int s);
int main()
{
	scanf("%d",&N);
	pailie(0,N);
 	return 0;
}
void pailie(int w,int s)
{
	int i;
	if(s==0){
		ch[strlen(ch)] = '\0';
		printf("%s\n",ch);
		return;
	}
	for(i=1;i<=N;i++){
		if(num[i]==0){
			ch[w] = '0'+i;
			ch[w+1] = ' ';
			num[i] = 1;
			pailie(w+2,s-1);
			num[i] = 0;
		}
	}
	return;	
}


