#include<stdio.h>
#include<ctype.h>
#include<string.h>
long long used[15];
long long a[15];
void print(long long n){
	long long i;
	for(i=1;i<n;i++)
	{
	    printf("%d",a[i]);
	    putchar(' ');
	    printf("%d",a[n]);
	}
	}
	void dfs(long long fu,long long aim)
	{
		if(fu==aim)
		{
			print(aim);
			return;
		}
		long long i;
		for(i=1;i<=aim;i++)
		{
			if(used[i]) continue;
			a[fu+1]=i;used[i]=1;dfs(fu+1,aim);used[i]=0;
		 } 
	}
	int main()
	{
		long long n;
	    scanf("%lld",&n);
		dfs(0,n);
		return 0;
		
	}
 

