#include <stdio.h>
#include <math.h>
#include <string.h>
int a[11],num[11]={0},N;
void place (int x){
    int i;
    for(i=1;i<=N;i++){
        if(num[i]==0){
            a[x]=i;
            num[i]=1;
            place(x+1);
            num[i]=0;
        }
    }
    if(x>N){
        for(i=1;i<=N;i++){
            printf("%d",a[i]);
        }
        printf("\n");
    }
}
int main()
{
    int x;
scanf("%d",&N);
place(1);
}


