#include <stdio.h>
#include <string.h>
void dfs(int step);
int n,put[20],mark[20]={};
int main(){
	scanf("%d",&n);
	dfs(1);
	return 0;
} 
void dfs(int step){
	int i;
	if(step==n+1){
		for(i=1;i<=n;i++)
			printf("%d ",put[i]);
		printf("\n");
		return;
	}
	for(i=1;i<=n;i++){
		if(mark[i]==0){
			put[step]=i;
			mark[i]=1;
			dfs(step+1);
			mark[i]=0;
		}
	}
	return;
}

