#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#define max 50005
int a[max],b[max];
int n;
void fun(int i){
    int j;
    if(i==n+1)
    {
        for(i=1;i<=n;i++)
        printf("%d ",a[i]);
        printf("\n");
        return;
    }
    for(j=1;j<=n;j++){
        if(b[j]==0)
        {
            a[i]=j;
            b[j]=1;
            fun(i+1);
            b[j]=0;
        }
    }
    return;
}
int main()
{
    scanf("%d",&n);
    fun(1);
    return 0;
}

