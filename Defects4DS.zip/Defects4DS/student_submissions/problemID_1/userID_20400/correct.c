#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
int flag[20];
int ans[20];
void pailie(int m,int n)
{
	int i;
	if(m==n)
	{
		for(i=0;i<n;i++)
		printf("%d ",ans[i]);
		printf("\n");
		return ;
	}
	for(i=1;i<=n;i++)
	{
		if(flag[i]==0)
		{
			ans[m]=i;
			flag[i]=1;
			pailie(m+1,n);
			flag[i]=0;
			ans[m]=0;
		}
	}
	return ;
}

int main()
   {
    int n;
    scanf("%d",&n);
    pailie(0,n);
    return 0;
   }




