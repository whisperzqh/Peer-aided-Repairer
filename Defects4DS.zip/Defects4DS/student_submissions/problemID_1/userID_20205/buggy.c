#include<stdio.h>
#include<string.h>
void permutations(int *a,int *b,int n,int len);


int main()
{
	int n;
	scanf("%d",&n);
	int a[10];
	
	int i,j;
	
	for(i=0;i<n;i++){
		a[i]=i+1;
	} 
	
	int len;
	len=n;
	int b[10]={0};
	permutations(a,b,n,len);
	
	
	
	return 0;
}

//
void permutations(int *a,int *b,int n,int len){
	int i,j,k,t;
	if(n==0){
		for(t=0;t<len;t++){
			printf("%d",b[t]);
		}
		printf("\n");
		return;
	}
	for(i=0;i<n;i++){
		b[len-n]=a[i];
		//
		int c[10];
			for(j=0,k=0;j<(n-1);k++){
				if(a[k]==a[i]){
					continue;	
				}else{
					c[j]=a[k];
					j++;
				}		
			}
			int m;
			m=n-1;
			permutations(c,b,m,len); 
			continue;
		}	
	
}

