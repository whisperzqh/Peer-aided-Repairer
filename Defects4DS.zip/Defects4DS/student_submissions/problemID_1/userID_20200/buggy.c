#include<stdio.h>
int flag[11]={0};
int ans[11]={0};
void print(int n)
{
	int i=0;
	for(i=0;i<n;i++)
	printf("%d",ans[i]);
	printf("\n");
}
void qpl(int index,int n)
{
	if(index==n)
	{
		print(n);
		return;
	}
	int i=1;
	for(i=1;i<=n;i++)
	{
		if(flag[i]==0)
		{
			ans[index]=i;
			flag[i]=1;
			qpl(index+1,n);
			flag[ans[index]]=0;ans[index]=0;
		}
	}
}
int main()
{
	int n;
	scanf("%d",&n);
	qpl(0,n);
	return 0;
}

