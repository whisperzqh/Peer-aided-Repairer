#include<stdio.h>
int xunzhao(int a[],int n);
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	int a[100]={0};
	for(i=0;i<n;i++)
	{
		a[i]=i+1;
		printf("%d",a[i]);
	}
	printf("\n");
	xunzhao(a,n);
	return 0;
}
int xunzhao(int a[],int n)
{
	int j,b=0,x,c,i;
	for(j=n-1;j>0;j--)
	{
		if(a[j]>a[j-1])
		{
			b=a[j-1];
			x=j-1;
			break;
		}
	}
	if(b==0)
	return 0;
	for(j=n-1;j>0;j--)
	{
		if(a[j]>b)
		{
			a[x]=a[j];
			a[j]=b;
			break;
		}
	}
	for(j=x+1,i=1;j<n-i;j++,i++)
	{
		c=a[j];
		a[j]=a[n-i];
		a[n-i]=c;
	}
	for(j=0;j<n;j++)
	printf("%d",a[j]);
	printf("\n");
	xunzhao(a,n);
}


