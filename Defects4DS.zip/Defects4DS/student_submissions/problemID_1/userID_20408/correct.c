#include<stdio.h>
#include<string.h>
int book[100],a[100];
int fds(int step,int n)
{
if(step==n+1)//
{
{
for(int i=1;i<=n;i++)
{
printf("%d ",a[i]);
}
printf("\n");
}
return 0;//
}
for(int i=1;i<=n;i++)//
{
if(book[i]==0)//
{
a[step]=i;//
book[i]=1;//
fds(step+1,n);//
book[i]=0;//
}
}
}
int main()
{
    int i;
    scanf("%d",&i);
fds(1,i);
return 0;
}
