#include<stdio.h>
#include<string.h>
void swap(int s[],int a,int b) {
	int tpr;
	tpr = s[a],s[a]=s[b],s[b]=tpr;
	return;
}
void reverse(int s[],int a,int b) {
	int i;
	for(i=a; i<=(b+a)/2; i++)swap(s,i,a+b-i);
	return;
}
int research(int s[],int a,int n)
{
	int i,min = 50;
	for(i=a+1;i<=n;i++)
	{
		if(s[i]>s[a]&&s[i]<min)
		min = s[i];
	}
	for(i=a+1;i<=n;i++)
	{
		if(min==s[i])return i;
	}
	return -1;
}
int main() {
	int n,i,j,f;
	int a[50]= {0};
	scanf("%d",&n);
	for(i=1; i<=n; i++){
	a[i]=i;
	printf("%d ",a[i]);
	}
	printf("\n");
	for(i=n-1; i>0;) {
		if(a[i]<a[i+1]) {
			f=research(a,i,n);
			//printf("f = %d i = %d\n",f,i);
			swap(a,i,f);
			reverse(a,i+1,n);
			for(j=1; j<=n; j++) {
				printf("%d ",a[j]);
			}
			printf("\n");
			i=n-1;
		}
		else i--;
	}
	return 0;
}
