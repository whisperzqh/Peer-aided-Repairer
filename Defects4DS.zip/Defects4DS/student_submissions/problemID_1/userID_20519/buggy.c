#include<stdio.h>

int flag[10] = {0};
char stack[11];
void rank(int m , int n);
int N;

int main()
{
	scanf("%d" , &N);
	rank(0 , N);
	return 0;	
}

void rank(int m , int n)
{
	int i;
	if(n == 0){
		stack[m] = '\0';
		puts(stack);
		return;
	}
	for(i = 1;i <= N;i++){
		if(flag[i] == 0){
			flag[i] = 1;
			stack[m] = i + '0';
			rank(m+1,n-1);
			flag[i] = 0;
		}
	}
}

