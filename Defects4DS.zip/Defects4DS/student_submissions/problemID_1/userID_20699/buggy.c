#include<stdio.h>
int a[10];
void fun(int*,int );
void reverse(int*,int,int);
int main()
{
	int i,n;
	for(i=0;i<10;i++)
		a[i]=i+1;
	scanf("%d",&n);
	fun(a,n);
	return 0;
}
void fun(int *a,int n)
{
	int i,j,k,m,temp;
	for(i=0;i<n;i++)
		printf("%d",a[i]);
	printf("\n");
	for(i=n-2;i>=0;i--)
	{
		if(a[i]<a[i+1])
		{
			j=i;
			k= j+1;
			for(m=j+2;m<n;m++)
			{
				if(a[m]>a[j] &&a[m]<a[k])
					k = m;
			}
			temp = a[k];
			a[k]=a[j];
			a[j]=temp;
			reverse(a,j+1,n-1);
			fun(a,n);
		}
		
	}
	
}
void reverse(int *a,int j,int k)
{
	int temp,i;
	for(;j<k;j++,k--)
	{
		temp=a[j];
		a[j]=a[k];
		a[k]=temp;
	}
}

