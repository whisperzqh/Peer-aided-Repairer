#include <stdio.h>

void allarrange(int );


int main()
{
	int n=0;
	scanf("%d",&n);
	allarrange(n);
	
	return 0;
 } 
 
 void allarrange(int n)
 {
 	int a[11]={0};
 	int i=0,j,k,m,h,temp;

	for(i=0;i<n;i++)
		a[i]=i+1;
	
	while(1)
	{
		for(i=0;i<n;i++)
			printf("%d ",a[i]);
		printf("\n");
		for(j=n-2;a[j]>a[j+1]&&j>=0;j--);
		if(j<0)
			return;
		for(k=n-1;k>j&&a[k]<a[j];k--);    
        temp=a[k];
		a[k]=a[j];
		a[j]=temp;  
        for(m=j+1,h=n-1;m<h;m++,h--)  
        {
			temp=a[m];
			a[m]=a[h];
			a[h]=temp;  
		}	
	}
 	
 }
 


