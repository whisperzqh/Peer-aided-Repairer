#include<stdio.h>
#include<string.h>
void pai(int y[],int x){
	int i=0,j=0,k=0,mmin=10,tem=0,jud=0;
	for(i=x-1;y[i]<y[i-1];i--){
	}
	for(j=i;j<x;j++){
		if(y[j]>y[i-1]&&y[j]<=mmin){
			jud=j;
		}
	}
	tem=y[i-1];
	y[i-1]=y[jud];
	y[jud]=tem;
	for(j=0;j<x-1;j++){
		for(k=i;k<x-1-j;k++)
		if(y[k]>y[k+1]){
			tem=y[k];
			y[k]=y[k+1];
			y[k+1]=tem;
		}
	}
	printf("\n");
	for(i=0;i<x;i++){
		printf("%d ",y[i]);
	}
	for(i=0;i<x;i++){
		if(y[i]!=x-i)
		pai(y,x);
	} ;
	return ;
}
int main(){
	int n,i,j,k,arr[20]={0};
	scanf("%d",&n);
	for(i=n-1;i>=0;i--){
		arr[i]=i+1;
		printf("%d ",n-i);
	} 
	if(n!=1){
		pai(arr,n);
	}
	return 0;
} 

