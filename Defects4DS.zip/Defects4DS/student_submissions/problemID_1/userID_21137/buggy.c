
#include<stdio.h> 
void rankDic(char perm[],int num) 
{ 
 int i,k,j,c;
 
 if (num<1)
  return;
     
 while(1)
 { 
  for (i=num-2;i>=0;--i)
   if (perm[i]<perm[i+1]) //
    break; 
  if (i<0) 
   break;  
   
  for(k=num-1;k>i;--k) 
   if(perm[k]>perm[i]) 
    break; 
    c=perm[i];
    perm[i]=perm[k];
    perm[k]=c;
  for(k=i+1,j=num-1;k<j;k++,j--)
  {
  	c=perm[k];
  	perm[k]=perm[j];
  	perm[j]=c;
  }
        for(i=0;i<num;i++)  
            printf("%c",perm[i]);  
        printf("\n"); 
 
}
}
 
int main() 
{ 
 char perm[100];
int  k=1,num,i;
 scanf("%d",&num);
 for(i=0;i<num;i++)
 {
 	perm[i]=i+1+'0';
 }
 for(i=0;i<num;i++)
 {
 	printf("%c",perm[i]);
 }
 printf("\n");
 rankDic(perm,num); 
}

