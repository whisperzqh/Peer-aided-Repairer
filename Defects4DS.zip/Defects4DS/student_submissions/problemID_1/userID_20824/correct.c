#include<stdio.h>
int a[11],b[11],flag[11];
int quanpailie(int a[],int b[],int k,int n)
{
    int j,m;
    if(k==n)
    {
        for(m=0;m<n;m++)
        {
            printf("%d ",b[m]);
        }
        printf("\n");
    }
    else
    {
        for(j=0;j<n;j++)
        {
            if(flag[j]==0)
            {b[k]=a[j];
            flag[j]=1;
            quanpailie(a,b,k+1,n);
            flag[j]=0;}
        }
    }

}
int main()
{
    int n,i,a[11],b[11],k;
    scanf("%d",&n);
    for(i=0;i<n;i++)
        a[i]=i+1;
        k=0;
    quanpailie(a,b,k,n);
}

