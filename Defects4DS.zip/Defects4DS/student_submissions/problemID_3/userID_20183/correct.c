#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
#include<stdlib.h>
int getindex(int a, int b)
{
	if(a>b)
	return a-b-1;
	else
	return a-b;
}
char in[200];
char out[200];
int len,dot,num,zs;
int main(){
	gets(in);
	len=strlen(in);
	int i=0,j=0;
	for(i=0;i<len;i++){
		if(in[i]=='.')
		{
			dot=i;
			break;
		}
	}
	for(i=0;i<len;i++){
		if(in[i]!='.'&&in[i]!='0')
		{
			num=i;
			break;
		}
	}	
	zs=getindex(dot,num);
//	printf("%d\n",zs);
	for(i=num;i<len;i++)
	{
		if(in[i]=='.')
		continue;
//		i=i+1;
//		++i;
		else if(i==num)
		{
			if(in[i+1]!=0)
			{
				out[j++]=in[i];
				out[j++]='.';
			} else {
				out[j++]=in[i];
			} 	
		} 
		else 
		{
			out[j++]=in[i];
		}
	}
//	out[j]='\0';
	printf("%se%d\n",out,zs);
	return 0;
} 

