#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<ctype.h>
int main()
{
	char s[105];
	gets(s);
	int i=0,j;
	int len=strlen(s);
	if(s[0]>'0')
	{
		for(i;i<len;i++)
		{
			if(s[i]=='.') break;
		}
		printf("%c.",s[0]);
		for(j=1;j<i;j++) printf("%c",s[j]);
		for(j+=1;j<len;j++) printf("%c",s[j]);
		printf("e%d",i-1);
	}
	else if(s[0]=='-'&&s[1]!='0')
	{
		for(i=1;i<len;i++)
		{
			if(s[i]=='.') break;
		}
		printf("-%c.",s[1]);
		for(j=2;j<i;j++) printf("%c",s[j]);
		for(j+=1;j<len;j++) printf("%c",s[j]);
		printf("e%d",i-2);
	}
	else if(s[0]=='0'){
		for(i=2;i<len;i++)
		{
			if(s[i]!='0') break;
		}
		printf("%c.",s[i]);
		for(j=i+1;j<len;j++) printf("%c",s[j]);
		printf("e-%d",i-1);
	}
	else 
	{
		for(i=3;i<len;i++)
		{
			if(s[i]!='0') break;
		}
		printf("-");
		for(j=i;j<len;j++) printf("%c",s[j]);
		printf("e-%d",i-2);
	}
	}
	
	
 

