#include <stdio.h>
int main()
{
	char num[105];
	int i,k=0;
	gets(num);
	if(num[0]!='0')
	{
	for(i=0;i<strlen(num);i++)
	{
		if(num[i]=='.')
		{
			k=i;
		}
	}
	printf("%c.",num[0]);
	for(i=1;i<strlen(num);i++)
	{
		if(num[i]!='.')
		printf("%c",num[i]);
	 } 
	 printf("e%d",k-1);
    }
    else 
    {
    	for(i=2;i<strlen(num);i++)
    	{
    		if(num[i]!='0')
    		k=i;
		}
		printf("%c",num[k]);
		if(k!=strlen(num)-1)
		printf(".");
		for(i=k+1;i<strlen(num);i++)
		printf("%c",num[i]);
		printf("e-%d",k-1);
	}
	return 0;
}

