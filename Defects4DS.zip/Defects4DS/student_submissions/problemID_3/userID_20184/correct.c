#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<math.h>
#include<stdlib.h>
#include<time.h>
int main(){
    char s[200]="\0";
    gets(s);
    int n;
    n=strlen(s);
    int i,k=0,j=0;
    for(i=0;i<n;i++){
    	if(s[i]=='.'){
    		k=i;	
		}
	}
	if(k==0){
		for(i=0;i<n;i++){
			printf("%c",s[i]);
			if(i==0){
				printf(".");
			}
		}
		printf("e%d",n-1);
	}
	else{
		if(k==1){
			if(s[0]!='0'){
				for(i=0;i<n;i++){
					printf("%c",s[i]);
				}
				printf("e0");
			}
			else{
				for(i=0;i<n;i++){
					if(s[i]!='0'&&s[i]!='.'){
						j=i;
						break;
					}
				}
				for(i=j;i<n;i++){
						printf("%c",s[i]);
						if(i==j&&j!=n-1){
							printf(".");
						}
					}
					printf("e-%d",j-1);
			}
		}
		else{
			for(i=0;i<n;i++){
				if(i!=k){
					printf("%c",s[i]);
				}
				if(i==0){
					printf(".");
				}
			}
		    printf("e%d",k-1);
		}
	} 
	return 0;
}


