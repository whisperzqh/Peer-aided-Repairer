#include<stdio.h>
#include<string.h>
int main()
{
    char a[500];
	int i,s1=0,s2=0,n;
	scanf("%s",a);
	s1=strlen(a);
	for(i=0;i<strlen(a);i++)
	{
		if(a[i]=='.')
		{
			s1=i;
		}
    }
    for(i=0;i<strlen(a);i++)
	{
		if(a[i]>'0'&&a[i]<='9')
		{
			s2=i;
			break;
		}
	} 
		if(s1>=s2)
		{
		    n=s1-s2-1;
	    }
	    if(s2>s1)
	    {
	    	n=s1-s2;
		}
		printf("%c",a[s2]);
		s2++;
		printf("."); 
		while(s2<strlen(a))
		{
			if(a[s2]=='.')
			{
				s2++;
			}
			else
			{
			printf("%c",a[s2]);
			s2++;
		    }
		}
		printf("e");
		printf("%d",n);
	
	return 0;	
} 

