#include<stdio.h>
#include<string.h>
int main(){
	char s[1024];
	scanf("%s",s);
	if(s[0]=='0')
	{
		int a,i;
		for(i=2;i<=strlen(s);i++)
		{
			if(s[i]!='0'){
				a=i;
				break;
			}
			
		}
		if(a+1==strlen(s))
		{
			printf("%ce-%d",s[a],a-1);
		}
		else{
			printf("%c.",s[a+1]);
			for(i=a+1;i<strlen(s)-1;i++){
				printf("%c",s[i]);
			}
			printf("e-%d",a+1);
		}
	}
	else{
		int b,j;
		for(j=1;j<strlen(s)-1;j++){
			if(s[j]=='.'){
				b=j-1;
			}}
			printf("%c.",s[0]);
			for(j=1;j<strlen(s);j++){
				if(s[j]!='.'){
					printf("%c",s[j]);
				}
			}
			printf("e%d",b);
	}
}

