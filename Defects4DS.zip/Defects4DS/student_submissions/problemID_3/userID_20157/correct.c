#include <stdio.h>
#include <string.h>
char a[100000];
int main(){
	int n,i,t;
	gets(a);
	n=strlen(a);
	if(a[0]=='0'){
		for(i=2;i<n;i++)
			if(a[i]!='0'){
				t=i;
				break;
			}
		if(t!=n-1)
			printf("%c.",a[t]);
		else
			printf("%c",a[t]);
		for(i=t+1;i<n;i++)
			printf("%c",a[i]);
		printf("e-%d",t-1);
	}
	else{
		for(i=1;i<n;i++)
			if(a[i]=='.')
				t=i;
		printf("%c.",a[0]);
		for(i=1;i<t;i++)
			printf("%c",a[i]);
		for(i=t+1;i<n;i++)
			printf("%c",a[i]);
		printf("e%d",t-1);
	}
	return 0;
} 

