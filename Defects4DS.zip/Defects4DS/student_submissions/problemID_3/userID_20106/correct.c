#include<stdio.h>
#include<string.h>
int main()
{
	char s[105];
	gets(s);
	int i,x=0,j=0,k=0,flag=0;
	if(s[0]!='0')
	{
	if(s[1]=='.')
		{
		for(i=0;i<strlen(s);i++)
		{
		 printf("%c",s[i]);
		}
	     printf("e0");
	    }
	else
	{
	for(i=0;i<strlen(s);i++)
	{
		if(s[i]!='.')
		k++;
		else
		break;
	}
	printf("%c",s[0]);
	for(j=1;j<strlen(s);j++)
		{
			flag=0;
			if(s[j]!='0'&&s[j]!='.')
			flag=1;
		}
	if(flag==1){
	printf(".");
		}
	for(i=1;i<strlen(s);i++)
	{

		for(j=i;j<strlen(s);j++)
		{
			if(s[j]!='0'&&s[j]!='.')
			flag=1;
		}
		if(flag==1&&s[i]!='.'){
		printf("%c",s[i]);
		flag=0;
	}
	}
	printf("e%d",k-1);
		
	}
	}
	
	if(s[0]=='0')
	{
		for(i=0;i<strlen(s);i++)
	{
			if(s[i]=='0')x++;
			else if(s[i]!='0'&&s[i]!='.')
			break;
	}
	for(i=x+1;i<strlen(s);i++)
	{
	if(i==x+1&&(x+1)!=strlen(s)-1)
	printf("%c.",s[i]);
	else
	printf("%c",s[i]);
	}
	printf("e-%d",x);
 } 
 
}

