#include <stdio.h> 
#include <string.h>
#include <ctype.h>
int main ()
{
	char a[100];
	int i,j,l,num,n;
	scanf("%s",a);
	l=strlen(a);
	if(a[0]=='0'){
		if(a[2]=='0') {
		for(i=2;a[i]=='0';i++)
			num=i-2;
			if(num+4<l){
				printf("%c.",a[num+3]);
				for(j=num+4;j<l;j++)
					printf("%c",a[j]);
			}
			else
			printf("%c",a[num+3]);
			printf("e-%d",num+2);
		}
		else {
			printf("%c.",a[2]);
			for(i=3;i<l;i++){
				printf("%c",a[i]);
			}
			printf("e-1");
		}	
	}	


	else if(a[0]!='0'&&a[1]=='.'){
		printf("%se0",a);
	}
	else {
		for(i=0;a[i]!='.';i++){
			n=i+1;
		}
		printf("%c.",a[0]);
		for(i=1;i<n;i++){
			printf("%c",a[i]);
		}
		for(j=n+1;j<l;j++){
			printf("%c",a[j]);
		}
		printf("e%d",n-1);
	}
	return 0;
}

