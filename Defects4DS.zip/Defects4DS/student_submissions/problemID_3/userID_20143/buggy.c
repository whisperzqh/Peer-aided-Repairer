#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	char s[120];
	gets(s);
	int n=strlen(s),i=0,j;int m=0;
	if(s[0]=='-')
	{
	    printf("%c",s[0]);
	    i+=1;
	}
	if(s[i]=='0')
	{
		j=i+2;
		for(;j<n;j++)
		{
			if(s[j]=='0')
			m+=1;
		    else 
			{
			printf("%c",s[j]);
			printf("%c",'.');
			break;
			}
		}
			for(j=j+1;j<n;j++)
		    printf("%c",s[j]);
				
			printf("e-%d",m+1);
		   	
				
					   
				
	}		
		
		
	
	else 
	{
		printf("%c%c",s[i],'.');
		j=i+1;
		for(;j<n;j++)
		{
			if(s[j]!='.')
			   printf("%c",s[j]);
			else m=j-i-1;
		}
		printf("e%d",m);
	}
	
	
}

