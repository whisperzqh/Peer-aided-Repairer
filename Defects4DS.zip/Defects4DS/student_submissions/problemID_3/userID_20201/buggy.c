#include <stdio.h>
#include <string.h>
int main()
{
	char s[150];
	int i=0,j=1,k=0,lo=0;
	gets(s);
	if (s[0]=='0')
	{
	
		for (i=2,k=strlen(s)-1;i<=k;i++)
			{
				if (s[i]=='0')
					lo++;
					if (s[i]!='0')
						break;
			}
			printf ("%c.",s[i]);
			for (i++;i<=k;i++)
				printf ("%c",s[i]);
				printf ("e-%d",lo+1);
	}
	if (s[0]!='0')
	{
		while(s[i++]!='.')
			lo++;
			if (lo==1)
				printf ("%se0",s);
				if (lo>1)
					{
						printf ("%c.",s[0]);
						while (s[j]!='\0')
							if (s[j++]!='.')
								printf ("%c",s[j-1]);
									printf ("e%d",lo-1);
					}
					
						
	}
	return 0;
}

