#include<stdio.h>
#include<string.h>
#include<ctype.h>
#include<stdlib.h>
#include<math.h>
int find_po(char s[]){
	int i=0;
	for(i=0;s[i] != '.';i++);
	return i-1;
}
int find_mi(char s[],int len){
	int i=len,j=0;
	for(i=len;s[i]!='.';i--){
		j++;
	}
	return j-1;
}
int main(){
	char num[200];
	int len,po,mi,i,flag,flag2;
	gets(num);
	len=strlen(num);
	po=find_po(num);
	mi=find_mi(num,len);
	if(po>=0&&num[0]!='0'){
		for(i=0;i<len;i++){
			if(num[i]=='.'){
				continue;
			}
			putchar(num[i]);
			if(i==0){
				putchar('.');
			}
		}
		printf("e%d",po);
	}else{
		flag=0; 
		flag2=0;
		for(i=0;i<len;i++){
			if(!(num[i]>'0'&&num[i]<='9')&&flag==0){
				continue;
			}
			flag=1;
			putchar(num[i]);
			if(flag2==0&&num[i+1] != '\0'){
				putchar('.');
				flag2=1;
			}
			
		}
		printf("e-%d",mi);
	}
	return 0;
}

