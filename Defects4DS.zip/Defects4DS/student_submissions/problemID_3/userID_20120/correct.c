#include<stdio.h>
#include<string.h>
int main()
{char s[200];
int i,j;
gets(s);
if(s[0]=='0'){
	i=0;
	do
	i++;
	while(s[i]=='0'||s[i]=='.');
	if(i==strlen(s)-1)
	printf("%ce-%d",s[i],i-1);
	else{
		printf("%c.",s[i]);
		for(j=i+1;j<strlen(s);j++){
			printf("%c",s[j]);
		}
		printf("e-%d",i-1);
	}
}
else{
	i=-1;
	do
	i++;
	while(s[i]!='.');
	printf("%c.",s[0]);
	for(j=1;j<strlen(s);j++){
		if(s[j]!='.')
		printf("%c",s[j]);
	}
	printf("e%d",i-1);
}
return 0;
}

