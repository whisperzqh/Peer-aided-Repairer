#include<stdio.h>
#include<string.h>
char s[110],a[110];
int main()
{
	int i,j,cnt=0;
	char *p;
	gets(s);
	
	
	if(s[1]=='.' && s[0]=='0'){
		cnt=0;
		for(i=2;s[i]=='0';i++){
			cnt++;
		}
		cnt++;
		printf("%ce-%d",s[i],cnt);
	}
	
	else if(s[1]=='.' && s[0]!='0')
		printf("%se0",s);
		
	else{
		cnt=0;
		for(i=0;s[i+1]!='.';i++){
			cnt++;
		}
		for(i=0,j=0;s[i]!='\0';i++){
			if(s[i]!='.')
				a[j++]=s[i];
		}
	
		strcpy(s,a);
		p=a;
		printf("%c.%se%d",a[0],p+1,cnt);
	}
	
	return 0;	
 } 

