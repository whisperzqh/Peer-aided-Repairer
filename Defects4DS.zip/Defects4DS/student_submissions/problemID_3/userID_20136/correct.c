#include<stdio.h>
int main()
{
	int flag=0,i,t,te,tem,temp;
	char s[150];
	gets(s);
	if(s[0]=='0')
	{
		for(i=2;s[i]!='\0';i++)
		{
			if(s[i]!='0')
			{
				break;
			}	
		}
		t=i;
        for(;s[i]!='\0';i++)
        {
        	printf("%c",s[i]);
        	if(i==t&&s[i+1]!='\0')
        	printf(".");
		}
		printf("e-%d",t-1);	
	}
	else
	{
		for(i=1;s[i]!='\0';i++)
		{
			if(s[i]=='.')
			{
				flag=1;
				break;
			}
		}
		t=i;
		for(te=0;te<t;te++)
		{
			printf("%c",s[te]);
			if(te==0)
			printf(".");
		}
		for(te=t+1;s[te]!='\0';te++)
		printf("%c",s[te]) ;
		printf("e%d",t-1);
	}
	return 0;
} 

