# Comparison with ITSP dataset

We conducted an in-depth comparison of the two datasets to explain the motivation for creating Defects4DS. We believe the proposal of Defects4DS contributes to the diversity and balance of bug types and comprehensive evaluation of APR methods. 

#### 1. grammatical components

We compared the occurrences of some complex grammatical components in the two datasets, such as struct, pointer, and multidimensional array. The table represents the number of programs in which this type of grammatical component appears in the corresponding dataset.

These components occur in **263/682(38.6%)** Defects4DS programs, while never in ITSP used in Verifix. Additionally, the custom functions occur in **291/682(42.7%)** Defects4DS programs, while only 20.5% in ITSP, implying the gap of fix difficulty. 

|                        | Defects4DS | ITSP  |
| ---------------------- | ---------- | ----- |
| struct                 | 194        | 0     |
| multidimensional array | 30         | 0     |
| pointer                | 138        | 0     |
| **total**              | **263**    | **0** |

|                 | Defects4DS | ITSP |
| --------------- | ---------- | ---- |
| custom function | 291        | 70   |

#### 2. bug type

We annotated the bug-type of ITSP, observing that **Defects4DS includes several bug types that are rarely or never found in ITSP**, such as function-definition-missing (F_4), function-return-value-error (F_1), loop-control-flow-error (L_4), loop-missing (L_6), if-else-match-error (B_1), etc. 

| bug type     | Defects4DS | ITSP    |
| ------------ | ---------- | ------- |
| V_1          | 53         | 9       |
| V_2          | 51         | 5       |
| V_3          | 129        | 35      |
| V_4          | 111        | 24      |
| **Variable** | **344**    | **73**  |
| F_1          | 19         | 1       |
| F_2          | 11         | 2       |
| F_3          | 15         | 5       |
| F_4          | 3          | 0       |
| **Function** | **48**     | **8**   |
| L_1          | 58         | 27      |
| L_2          | 104        | 44      |
| L_3          | 16         | 6       |
| L_4          | 23         | 4       |
| L_5          | 2          | 2       |
| L_6          | 23         | 6       |
| **Loop**     | **226**    | **89**  |
| B_1          | 7          | 1       |
| B_2          | 144        | 83      |
| B_3          | 22         | 5       |
| B_4          | 117        | 47      |
| B_5          | 6          | 3       |
| B_6          | 2          | 1       |
| **Branch**   | **298**    | **140** |
| IP_1         | 11         | 14      |
| IP_2         | 15         | 17      |
| IP_3         | 1          | 6       |
| **Input**    | **27**     | **37**  |
| OP_1         | 116        | 104     |
| OP_2         | 120        | 55      |
| OP_3         | 6          | 2       |
| **Output**   | **242**    | **161** |
| O_1          | 58         | 9       |
| O_2          | 3          | 1       |
| O_3          | 2          | 0       |
| O            | 4          | 7       |
| **Other**    | **67**     | **17**  |
| **Total**    | **1252**   | **525** |

#### 3. repair type

| repair type            | Defects4DS | ITSP |
| ---------------------- | ---------- | ---- |
| statement addition     | 272        | 92   |
| statement deletion     | 108        | 25   |
| position modification  | 34         | 11   |
| statement modification | 822        | 391  |

